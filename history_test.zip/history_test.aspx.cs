﻿using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class CF_SPC_history : System.Web.UI.Page
{
    static String connString = "Database=l7bcf_spc;Data Source=tw100043811;Port=3307;User Id=l7b_commit;Password=l7b$commit;CharSet=utf8;SslMode=None;allowPublicKeyRetrieval=true";
    static Color[] color = { Color.Blue, Color.Green, Color.Purple, Color.DarkGray, Color.Brown, Color.Yellow, Color.GreenYellow, Color.Gold, Color.Red, Color.Orange, Color.Green, Color.Blue, Color.Purple, Color.DarkGray, Color.Brown, Color.Yellow, Color.GreenYellow, Color.Gold, Color.Red, Color.Orange, Color.Green, Color.Blue, Color.Purple, Color.DarkGray, Color.Brown, Color.Yellow, Color.GreenYellow, Color.Gold, Color.Red, Color.Orange, Color.Green, Color.Blue, Color.Purple, Color.DarkGray, Color.Brown, Color.Yellow, Color.GreenYellow, Color.Gold, Color.Red };

    String[] line_id_ = { "FDM10", "FDR10", "FDG10", "FDB10", "FDS10", "FDM20", "FDR20", "FDS20", "FDM30", "FCI10", "FCI20", "FCV10", "FDI10" };

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            init_();

            if (!String.IsNullOrEmpty(Request.QueryString["product"]))
            {
                for (int i = 0; i < list_product.Items.Count; i++)
                {
                    list_product.Items[i].Selected = list_product.Items[i].Text == Request.QueryString["product"];
                }
            }

            if (!String.IsNullOrEmpty(Request.QueryString["layer"]))
            {
                list_layer.SelectedIndex = list_layer.Items.IndexOf(list_layer.Items.FindByValue(Request.QueryString["layer"]));
            }

            if (!String.IsNullOrEmpty(Request.QueryString["item_type"]))
            {
                list_chart.SelectedIndex = list_chart.Items.IndexOf(list_chart.Items.FindByValue(Request.QueryString["item_type"]));

            }
            if (!String.IsNullOrEmpty(Request.QueryString["report_time"]))
            {
                tb_endtime.Text = Request.QueryString["report_time"];
                tb_starttime.Text = Request.QueryString["report_time"];

                tb_starttime.Text = DateTime.Now.AddDays(-7).ToString("yyyy/MM/dd");
                tb_endtime.Text = DateTime.Now.ToString("yyyy/MM/dd");

                //tb_starttime.Text = DateTime.Parse(Request.QueryString["report_time"]).AddDays(-1).ToString("yyyy/MM/dd");
            }

            if (!String.IsNullOrEmpty(Request.QueryString["query"]))
            {
                //bt_query_Click(null, null);
            }

        }
    }

    public void init_()
    {
        init_control("product", list_product);
        init_control("chart", list_chart);
        init_control("line", list_line);
        tb_starttime.Text = DateTime.Now.AddDays(-7).ToString("yyyy/MM/dd");
        tb_endtime.Text = DateTime.Now.ToString("yyyy/MM/dd");
        
    }
    public void init_control(String type, DropDownList d)
    {


        String sql = "";

        d.Items.Clear();


        if (type == "product")
        {
            sql += " SELECT product_code as model FROM l7bcf_spc.chart_config order by substring(product_code,2,8) ";

        }
        else if (type == "chart")
        {
            d.Items.Add("ALL");
            sql = " SELECT distinct item_type FROM `l7bcf_spc`.`chart_config` order by item_type";
        }
        else if (type == "line")
        {
            d.Items.Add("ALL");
            foreach (String line in line_id_) 
            {
                d.Items.Add(line);
            }
            return;
        }
        DataTable dt = get_mysql_data(sql);

        foreach (DataRow r in dt.Rows)
        {
            d.Items.Add(r[0].ToString());
        }

    }
    public void init_control(String type, ListBox d)
    {


        String sql = "";

        d.Items.Clear();
        if (type == "product")
        {
            sql += " SELECT product_code as model FROM l7bcf_spc.model_config order by substring(product_code,2,8) ";
        }
        DataTable dt = get_mysql_data(sql);

        foreach (DataRow r in dt.Rows)
        {
            d.Items.Add(r[0].ToString());
        }
        if (dt.Rows.Count > 0)
        {
            d.Items[0].Selected = true;
        }

    }

 
    [System.Web.Services.WebMethod]
    public static String GetChartData(String chartCondition)
    {
        try
        {
            dynamic chartDataObj = JsonConvert.DeserializeObject(chartCondition);
            String sql_datestr = "";
            if (chartDataObj.query_type == "Sheet")
                sql_datestr += " DATE_FORMAT(a.report_time,'%Y/%m/%d %H:%i:%s') as report_time, ";
            else if (chartDataObj.query_type == "Daily")
                sql_datestr += " DATE_FORMAT(subdate(a.report_time, interval 450 minute), '%Y/%m/%d') as report_time, ";
            else if (chartDataObj.query_type == "Weekly")
                sql_datestr += " concat('W', substr(DATE_FORMAT(subdate(a.report_time, interval 450 minute), '%y'),2,1), CONVERT(WEEK(a.report_time, 1), CHAR)) as report_time, ";
            else
                sql_datestr += " DATE_FORMAT(a.report_time,'%Y/%m') as report_time, ";

            String sql_start_time = chartDataObj.starttime + " 07:30:00";
            String sql_end_time = chartDataObj.endtime + " 07:30:00";



            String sql_product = "";
            if (chartDataObj.list_product != "")
                sql_product += " 	and chart_id_product in (" + chartDataObj.list_product + ") ";


            String sql_item_type = "";
            if (chartDataObj.chart == "PSH")
                sql_item_type += " and item_type in ('" + chartDataObj.chart + "','HEIGHT_MAIN') ";
            else if (chartDataObj.chart == "Delta_OLX")
                sql_item_type += " and item_type in ('" + chartDataObj.chart + "','OLX_DELTA') ";
            else if (chartDataObj.chart != "ALL")
                sql_item_type += " and item_type = '" + chartDataObj.chart + "' ";


            String sql_line = "";
            if (chartDataObj.line != "ALL")
                sql_line += " and line_id = '" + chartDataObj.line + "' ";

            String sql_exclude = "";
            if (chartDataObj.exclude == "N")
                sql_exclude += " and `exclude` = 'N' ";


            StringBuilder sql_table = new StringBuilder();
            sql_table.AppendFormat(@"
                            SELECT 
                                DATE_FORMAT(subdate(report_time, interval 450 minute), '%m/%d') as mfg_day, 
                                DATE_FORMAT(report_time,'%Y/%m/%d %H:%i:%s') as report_time, 
                                item_type, 
                                chart_id, 
                                sheet_id, 
                                product_code, 
                                line_id, 
                                layer, 
                                value_AVG, 
                                value_MIN, 
                                value_MAX, 
                                `exclude`, 
                                judge_man, 
                                judge_note 
                            FROM l7bcf_spc.spc_data 
                            where 1=1 
                            and report_time >= '{0}'
                            and report_time <= '{1}' + interval 1 day
                            {2}
                            {3}
                            {4}
                            ", sql_start_time, sql_end_time, sql_product, sql_item_type, sql_line);
            DataTable dt_edit = get_mysql_data(sql_table.ToString());






            StringBuilder sql = new StringBuilder();
            sql.AppendFormat(@"
                    select * from 
                    (
                        select
                                {0}
                                a.chart_id, a.item_type, a.product_code, kpc.line_id, kpc.tool_id, a.layer, a.sheet_id, a.spc_spec_ver, a.user_spec_ver, value_max, value_min, value_avg, value_std,a.rawdata, 
                                bm.logoff_time as bm_logoff_time, ifnull(concat(bm.line_id, '(BM)'),'Nan(BM)') as bm_line_id, bm.tool_id as bm_tool_id, 
                                r.logoff_time as r_logoff_time, ifnull(concat(r.line_id, '(R)'), 'Nan(R)') as r_line_id, r.tool_id as r_tool_id, 
                                g.logoff_time as g_logoff_time, ifnull(concat(g.line_id, '(G)'), 'Nan(G)') as g_line_id, g.tool_id as g_tool_id, 
                                b.logoff_time as b_logoff_time, ifnull(concat(b.line_id, '(B)'), 'Nan(B)') as b_line_id, b.tool_id as b_tool_id, 
                                ps.logoff_time as ps_logoff_time, ifnull(concat(ps.line_id, '(PS)'), 'Nan(PS)') as ps_line_id, ps.tool_id as ps_tool_id, 
                                oc.logoff_time as oc_logoff_time, ifnull(concat(oc.line_id, '(OC)'), 'Nan(OC)') as oc_line_id, oc.tool_id as oc_tool_id, 
                                ito.logoff_time as ito_logoff_time, ifnull(concat(ito.line_id, '(ITO)'), 'Nan(ITO)') as ito_line_id, ito.tool_id as ito_tool_id, 
                                ifnull(concat(ifnull(kpc.line_id,'Nan'),'-',case when kpc.unit_id = '' then kpc.tool_id else kpc.unit_id end ),'Nan') as label_x, 
                                spectype.spec_valuetype, 
                                spec.spec_type, 
                                spec.usl, 
                                spec.ucl, 
                                spec.cl, 
                                spec.lcl, 
                                spec.lsl, 
                                spec.chip_info, 
                                ROW_NUMBER() OVER ( PARTITION BY a.chart_id, a.sheet_id, a.report_time, spectype.spec_valuetype ORDER BY 
                                bm.logoff_time desc, r.logoff_time desc, g.logoff_time desc, b.logoff_time desc, ps.logoff_time desc, oc.logoff_time desc ) as rn 
                            from 
                            ( 
                            SELECT * FROM l7bcf_spc.spc_data 
                            where 1=1 
                            and report_time >= '{1}'
                            and report_time <= '{2}' + interval 1 day
                            and layer = '{3}'
                            {4}
                            {5}
                            {6}
                            {7}
                            ) a
                            left join 
                            ( 
                            SELECT * FROM l7bcf_spc.kpc_data 
                            ) kpc 
                            on 1=1 
                            and a.sheet_id = kpc.glass_id 
                            and a.layer = kpc.op 
                            and a.report_time > kpc.logoff_time 
                            left join 
                            ( 
                            SELECT * FROM l7bcf_spc.kpc_data 
                                where op = 'BM' 
                            ) bm 
                            on 1=1 
                            and a.sheet_id = bm.glass_id 
                            and a.report_time > bm.logoff_time 
                            left join 
                            ( 
                            SELECT * FROM l7bcf_spc.kpc_data 
                                where op = 'R' 
                            ) r 
                            on 1=1 
                            and a.sheet_id = r.glass_id 
                            and a.report_time > r.logoff_time 
                            left join 
                            ( 
                            SELECT * FROM l7bcf_spc.kpc_data 
                                where op = 'G' 
                            ) g 
                            on 1=1 
                            and a.sheet_id = g.glass_id 
                            and a.report_time > g.logoff_time 
                            left join 
                            ( 
                            SELECT * FROM l7bcf_spc.kpc_data 
                                where op = 'B' 
                            ) b 
                            on 1=1 
                            and a.sheet_id = b.glass_id 
                            and a.report_time > b.logoff_time 
                            left join 
                            ( 
                            SELECT * FROM l7bcf_spc.kpc_data 
                                where op = 'PS' 
                            ) ps 
                            on 1=1 
                            and a.sheet_id = ps.glass_id 
                            and a.report_time > ps.logoff_time 
                            left join 
                            ( 
                            SELECT * FROM l7bcf_spc.kpc_data 
                                where op = 'OC' 
                            ) oc 
                            on 1=1 
                            and a.sheet_id = oc.glass_id 
                            and a.report_time > oc.logoff_time 
                            left join 
                            ( 
                            SELECT * FROM l7bcf_spc.kpc_data 
                                where op = 'ITO' 
                            ) ito 
                            on 1=1 
                            and a.sheet_id = ito.glass_id 
                            and a.report_time > ito.logoff_time 
                            left join 
                            (  
                            select 'AVG' as spec_valuetype union select 'MAX' union select 'MIN'  
                            ) spectype 
                            on 1=1 
                            left join 
                            (
                            select 
                                b.`chart_id`,  
                                    case when b.userspec = 'Y' then 'user' else 'spc' end as `spec_type`, 
                                    b.spec_valuetype, 
                                    usl,ucl,cl,lcl,lsl,chip_info
                            from
                            (
                                SELECT
                                    `chart_id`,
                                    spec_valuetype, 
                                    case when max(case when userspec = 'Y' then 1 else 0 end) = 1 then 'Y' else 'N' end as usr_check
                                FROM l7bcf_spc.spc_spec_real
                                group by 
                                    `chart_id`,
                                    spec_valuetype
                            ) a
                            inner join l7bcf_spc.spc_spec_real b
                            on a.chart_id = b.chart_id
                            and a.spec_valuetype = b.spec_valuetype
                            and a.usr_check = b.userspec
                        )  spec
                        on a.chart_id = spec.chart_id and spectype.spec_valuetype = spec.spec_valuetype
                    ) t 
                    where t.rn = 1 
                    order by report_time
                ", sql_datestr, sql_start_time, sql_end_time, chartDataObj.layer,
                        sql_product, sql_item_type, sql_line, sql_exclude);
            DataTable dt = get_mysql_data(sql.ToString());

            
            String layer_list = chartDataObj.layer_list;
            if (layer_list != "") 
            {
                String[] x_list = layer_list.Split(',');
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dt.Rows[i]["label_x"] = "";
                    foreach (String op in x_list)
                    {
                        if (op == "Product")
                            dt.Rows[i]["label_x"] += "-" + dt.Rows[i]["chart_id"].ToString().Split('/')[0];
                        else
                            dt.Rows[i]["label_x"] += "-" + dt.Rows[i][op + "_line_id"].ToString();

                    }
                    dt.Rows[i]["label_x"] = dt.Rows[i]["label_x"].ToString().Trim('-');
                }
            }


            var DataObjs = new Dictionary<string, object>();
            if (dt.Rows.Count > 0)
            {
                string[] item_list = dt.AsEnumerable().Select(row => row.Field<string>("item_type")).Distinct().ToArray();
                DataObjs["item_list"] = item_list.ToArray();
                List<object> charts = new List<object>();
                foreach (String item in item_list)
                {

                    var chartObjs = new Dictionary<string, object>();
                    chartObjs["item_type"] = item;
                    

                    List<object> chart_temp = new List<object>();

                    DataTable dt_filter = (from row in dt.AsEnumerable() where row.Field<string>("item_type") == item select row).CopyToDataTable();
                    string[] chart_id_list = dt_filter.AsEnumerable().Select(row => row.Field<string>("chart_id")).Distinct().ToArray();
                    if (chartDataObj.chart_overlap == "Y")
                    {
                        var chartData = new Dictionary<string, object>();

                        String title = item + " (";
                        foreach (String chart in chart_id_list)
                            title += chart + ",";
                        title = title.Trim(',') + ")";

                        chartData["title"] = title;
                        chartData["chartData"] = get_echart_data(dt_filter, item, "value_avg", true, "AVG", (String)chartDataObj.query_type);
                        chart_temp.Add(chartData);
                    }
                    else
                    {

                        foreach (String chart_id in chart_id_list)
                        {
                            var chartData = new Dictionary<string, object>();
                            DataTable dt_filter_chart = (from row in dt_filter.AsEnumerable() where row.Field<string>("chart_id") == chart_id select row).CopyToDataTable();
                            String title = "";
                            title = item + " (" + chart_id + ") ";
                            title = "<a href=\"" + "trans.aspx?chart=" + chart_id.Split('/')[0] + "&layer=" + chartDataObj.layer + "&start_time=" + chartDataObj.starttime + "&end_time=" + chartDataObj.endtime
                            + "&item_type=" + item + "\" target=\"_blank\" >" + title + "</a>";
                            
                            chartData["title"] = title;
                            chartData["chartData"] = get_echart_data(dt_filter_chart, item, "value_avg", true, "AVG", (String)chartDataObj.query_type);
                            chart_temp.Add(chartData);
                        }


                    }
                    chartObjs["chart_objs"] = chart_temp.ToArray();
                    charts.Add(chartObjs);

                }
                DataObjs["charts"] = charts.ToArray();
            }



            //return TransJsonOBJ(dt_edit);
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            return serializer.Serialize(DataObjs).Replace("NaN", "null");
        }
        catch(Exception ee)
        {
            var obj = new
            {
                err = ee.Message,
                trace = ee.StackTrace
            };
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            return serializer.Serialize(obj).Replace("NaN", "null");
        }
    }


    public class BoxplotStats
    {
        public double Min { get; set; }
        public double Q1 { get; set; }       // 第1四分位數（25%）
        public double Median { get; set; }   // 中位數（50%）
        public double Q3 { get; set; }       // 第3四分位數（75%）
        public double Max { get; set; }
        public double Mean { get; set; }

        public int Count { get; set; }       // 方便除錯/檢視（有效資料點數）
    }

    static public BoxplotStats ComputeBoxplotValue(String valueStr)
    {
        string[] tokens = valueStr.Split(',');
        Double[] data = Array.ConvertAll(tokens, x => double.Parse(x));
        int n = data.Length;
        
        Array.Sort(data);

        double min = data[0];
        double max = data[n - 1];

        // 平均
        double sum = 0.0;
        for (int i = 0; i < n; i++) sum += data[i];
        double mean = sum / n;

        // 四分位數（線性插值）
        Array.Sort(data);
        double q1 = data[(int)(n * 0.25)];
        double median = data[(int)(n * 0.5)];
        double q3 = data[(int)(n * 0.75)];


        return new BoxplotStats
        {
            Min = double.Parse(min.ToString("0.000")),
            Q1 = double.Parse(q1.ToString("0.000")),
            Median = double.Parse(median.ToString("0.000")),
            Q3 = double.Parse(q3.ToString("0.000")),
            Max = double.Parse(max.ToString("0.000")),
            Mean = double.Parse(mean.ToString("0.000")),
            Count = n
        };

    }


    static dynamic get_echart_data(DataTable dt1, String item, String tp, Boolean spec, String value_type, String query_type)
    {

        DataTable dt = (from row in dt1.AsEnumerable() where row.Field<string>("spec_valuetype") == value_type select row).CopyToDataTable();
        DataTable dt_group = new DataTable();

        dt_group.Columns.Add("report_time", typeof(string));
        dt_group.Columns.Add("legend_label", typeof(string));
        dt_group.Columns.Add("sheet_id", typeof(string));
        dt_group.Columns.Add("chip_id", typeof(string));
        dt_group.Columns.Add("avg", typeof(double));
        dt_group.Columns.Add("min", typeof(double));
        dt_group.Columns.Add("q1", typeof(double));
        dt_group.Columns.Add("median", typeof(double));
        dt_group.Columns.Add("q3", typeof(double));
        dt_group.Columns.Add("max", typeof(double));
        dt_group.Columns.Add("url", typeof(string));
        

        double v_max = -999;
        double v_min = 999;

        //每個sheet整理平均值與boxplot所需資料
        foreach (DataRow r in dt.Rows)
        {
            String report_time = r["report_time"].ToString();
            String label_x = r["label_x"].ToString();
            String sheet_id = r["sheet_id"].ToString();
            double value = double.Parse(r[tp].ToString());

            string valuesRaw = r["rawdata"].ToString();
            string chipsRaw = r["chip_info"].ToString();

            // 拆分並清理
            string[] valueTokens = SplitAndTrim(valuesRaw);
            string[] chipTokens = SplitAndTrim(chipsRaw);


            String url = "trans.aspx?chart=" + r["chart_id"].ToString().Split('/')[0] + "&report_time=" + r["report_time"].ToString()
                + "&sheet_id=" + r["sheet_id"].ToString() + "&item_type=" + r["item_type"].ToString() + "&layer=" + r["layer"].ToString();


            //sheet資訊
            BoxplotStats boxsheet = ComputeBoxplotValue(String.Join(",", valueTokens));
            dt_group.Rows.Add(report_time, label_x, sheet_id, "-",
                value, boxsheet.Min, boxsheet.Q1, boxsheet.Median, boxsheet.Q3, boxsheet.Max, url);


            //chip資訊
            int n = Math.Min(valueTokens.Length, chipTokens.Length);
            if (n == 0)
            {
                continue;
            }
            // 維持 chip 首次出現順序
            var seen = new HashSet<string>(StringComparer.Ordinal);

            //整理每個chip資訊
            var dict = new Dictionary<String, String>(StringComparer.Ordinal);
            for (int i = 0; i < n; i++)
            {
                string chip = chipTokens[i];
                string vStr = valueTokens[i];
                if (!seen.Contains(chip))
                {
                    seen.Add(chip);
                    dict[chip] = vStr;
                }
                else
                {
                    dict[chip] += "," + vStr;
                }
            }
            //排序dict
            var order = new List<string>(dict.Keys);
            order.Sort(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < order.Count; i++)
            {
                string chip = order[i];
                string valuestr = dict[chip];
                BoxplotStats temp = new BoxplotStats();
                try
                {
                    temp = ComputeBoxplotValue(valuestr);
                }
                catch (Exception ex)
                {

                    throw new Exception(
                            "ComputeBoxplotValue 失敗。valueStr = '" + valuestr + "'.",
                            ex
                        );
                }
                dt_group.Rows.Add(report_time, label_x, sheet_id, chip,
                temp.Mean, temp.Min, temp.Q1, temp.Median, temp.Q3, temp.Max, url);


                if (temp.Max > v_max)
                    v_max = temp.Max;
                if (temp.Min > v_min)
                    v_min = temp.Min;

            }
        }


        
        string[] series_name = dt_group.AsEnumerable().Select(row => row.Field<string>("legend_label")).Distinct().OrderBy(label_x => label_x).ToArray();
        string[] Xdata = dt_group.AsEnumerable().Select(row => row.Field<string>("report_time")).Distinct().OrderBy(report_time => report_time).ToArray();


        double y_USL = double.NaN;
        double y_UCL = double.NaN;
        double y_LSL = double.NaN;
        double y_LCL = double.NaN;
        double y_target = double.NaN;
        try { y_USL = double.Parse(dt.Rows[0]["USL"].ToString()); } catch { }
        try { y_UCL = double.Parse(dt.Rows[0]["UCL"].ToString()); } catch { }
        try { y_LSL = double.Parse(dt.Rows[0]["LSL"].ToString()); } catch { }
        try { y_LCL = double.Parse(dt.Rows[0]["LCL"].ToString()); } catch { }
        try { y_target = double.Parse(dt.Rows[0]["cl"].ToString()); } catch { }



        double y_upper = double.NaN;
        double y_lower = double.NaN;
        y_upper = Math.Max(v_max, y_USL);
        if (double.IsNaN(y_upper))
            y_upper = Math.Max(v_max, y_UCL);
        if (double.IsNaN(y_upper))
            y_upper = v_max;

        y_lower = Math.Min(v_min, y_LSL);
        if (double.IsNaN(y_lower))
            y_lower = Math.Min(v_min, y_LCL);
        if (double.IsNaN(y_upper))
            y_lower = v_min;
        y_upper += (y_upper - y_lower) * 0.2;
        y_lower -= (y_upper - y_lower) * 0.2;
        y_upper = double.Parse(y_upper.ToString("0.000"));
        y_lower = double.Parse(y_lower.ToString("0.000"));


        String title = item + " " + tp.Replace("value_", "").ToUpper();

        var chips = dt_group
            .AsEnumerable()
            .Select(r => r.Field<string>("chip_id"))
            .Where(s => !string.IsNullOrWhiteSpace(s) && s != "-")
            .Distinct()
            .ToList();


        var jsonData = new
        {

            title = title,
            chartid = Guid.NewGuid().ToString(),
            chips = chips,
            legends = series_name,
            xData = Xdata,
            usl = y_USL,
            ucl = y_UCL,
            lsl = y_LSL,
            lcl = y_LCL,
            upper = y_upper,
            lower = y_lower,
            data = TransJsonOBJ(dt_group)
        };
        return jsonData;
    }

    private static string[] SplitAndTrim(string raw)
    {
        if (string.IsNullOrEmpty(raw)) return new string[0];

        string[] pieces = raw.Split(',');
        for (int i = 0; i < pieces.Length; i++)
        {
            if (pieces[i] != null)
                pieces[i] = pieces[i].Trim();
        }
        return pieces;
    }

    public static String TransJsonOBJ(DataTable dt)
    {
        List<Object> rows = new List<Object>();
        Dictionary<String, String> row;
        foreach (DataRow dr in dt.Rows)
        {
            row = new Dictionary<String, String>();
            foreach (DataColumn col in dt.Columns)
            {
                row.Add(col.ColumnName, dr[col].ToString());
            }
            rows.Add(row);
        }
        JavaScriptSerializer serializer = new JavaScriptSerializer();
        string chartData = serializer.Serialize(rows);
        return chartData;
    }

    static public List<BoxPlotData> GenerateBoxPlotData(DataTable dt)
    {
        var boxPlotDataList = new List<BoxPlotData>();

        // Grouping by series and report_time
        var groupedData = dt.AsEnumerable()
            .GroupBy(row => new {
                Series = row.Field<string>("series"),
                ReportTime = row.Field<string>("report_time")
            });

        foreach (var group in groupedData)
        {
            var data = group.Select(x => x.Field<string>("value_str"))
                .SelectMany(y => y.Split(',').Select(double.Parse)).ToArray();

            // 计算箱线图统计信息
            Array.Sort(data);
            var q1 = data[(int)(data.Length * 0.25)];
            var median = data[(int)(data.Length * 0.5)];
            var q3 = data[(int)(data.Length * 0.75)];

            var boxPlotData = new BoxPlotData
            {
                Series = group.Key.Series,
                ReportTime = group.Key.ReportTime,
                BoxPlotValues = new double[]
                {
                    data.Min(),  // Min
                    q1,          // Q1
                    median,      // Median
                    q3,          // Q3
                    data.Max()   // Max
                }                
            };
            
            boxPlotDataList.Add(boxPlotData);
        }

        return boxPlotDataList;
    }

    public class BoxPlotData
    {
        public string Series { get; set; }
        public string ReportTime { get; set; }
        public double[] BoxPlotValues { get; set; }
    }


    static string ComputeAverage(IEnumerable<string> values)
    {
        // 假設每個值都是以','分隔的浮點數字串
        var numbers = new List<List<double>>();

        foreach (var value in values)
        {
            var nums = value.Split(',').Select(double.Parse).ToList();
            numbers.Add(nums);
        }

        int count = numbers[0].Count;
        int bypass = 0;
        var sums = new double[count];

        // 累計每一列的總和
        foreach (var number in numbers)
        {
            if (number.Count != count)
            {
                bypass += 1;
                continue;
            }

            for (int i = 0; i < count; i++)
                sums[i] += number[i];
        }

        /*
        for (int i = 0; i < count; i++)
        {
            foreach (var number in numbers)
            {
                sums[i] += number[i];
            }
        }
        */

        // 計算平均值
        var averages = sums.Select(s => s / (numbers.Count - bypass)).ToArray();

        // 以','分隔返回
        return string.Join(",", averages);
    }

    public Label addlabel(String t)
    {
        Label lb = new Label();
        lb.Text = t;
        return lb;
    }

    static public DataTable get_mysql_data(String sql)
    {
        DataTable DT = new DataTable();

        try
        {
            MySqlConnection conn = new MySqlConnection(connString);
            conn.Open();
            MySqlDataAdapter DA = new MySqlDataAdapter(sql, conn);
            DA.Fill(DT);
            conn.Close();
        }
        catch(Exception e)
        {
            //Response.Write(e.Message);
            DT = new DataTable();
        }
        return DT;

    }


    protected void bt_query_Click(object sender, EventArgs e)
    {
      
    }

    protected void bt_rawdata_Click(object sender, EventArgs e)
    {
        String sql = "";
        sql += " select ";
        sql += " DATE_FORMAT(a.report_time,'%Y/%m/%d %H:%i:%s') as report_time, a.chart_id, a.item_type, a.product_code, kpc.line_id, kpc.tool_id, a.layer, a.sheet_id, a.spc_spec_ver, a.user_spec_ver, value_max, value_min, value_avg, value_std, ";
        sql += " bm.logoff_time as bm_logoff_time, ifnull(concat(bm.line_id, ''),'Nan') as bm_line_id, bm.tool_id as bm_tool_id,bm.unit_id as bm_unit_id, ";
        sql += " r.logoff_time as r_logoff_time, ifnull(concat(r.line_id, ''), 'Nan') as r_line_id, r.tool_id as r_tool_id,r.unit_id as r_unit_id, ";
        sql += " g.logoff_time as g_logoff_time, ifnull(concat(g.line_id, ''), 'Nan') as g_line_id, g.tool_id as g_tool_id,g.unit_id as g_unit_id, ";
        sql += " b.logoff_time as b_logoff_time, ifnull(concat(b.line_id, ''), 'Nan') as b_line_id, b.tool_id as b_tool_id,b.unit_id as b_unit_id, ";
        sql += " ps.logoff_time as ps_logoff_time, ifnull(concat(ps.line_id, ''), 'Nan') as ps_line_id, ps.tool_id as ps_tool_id,ps.unit_id as ps_unit_id, ";
        sql += " oc.logoff_time as oc_logoff_time, ifnull(concat(oc.line_id, ''), 'Nan') as oc_line_id, oc.tool_id as oc_tool_id,oc.unit_id as oc_unit_id, ";
        sql += " ito.logoff_time as ito_logoff_time, ifnull(concat(ito.line_id, ''), 'Nan') as ito_line_id, ito.tool_id as ito_tool_id,ito.unit_id as ito_unit_id ";
        if (cb_spec.Checked)
        {
            sql += ", spectype.spec_valuetype, ";
            sql += " spec.spec_type, ";
            sql += " spec.spec_ver, ";
            sql += " spec.usl, ";
            sql += " spec.ucl, ";
            sql += " spec.cl, ";
            sql += " spec.lcl, ";
            sql += " spec.lsl ";
        }
        sql += " from ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.spc_data ";
        sql += " 	where 1=1 ";
        sql += " 	and report_time >= '" + tb_starttime.Text + " 07:30:00' ";
        sql += " 	and report_time <= '" + DateTime.Parse(tb_endtime.Text).AddDays(1).ToString("yyyy/MM/dd 07:30:00") + "' ";
        sql += " 	and layer = '" + list_layer.SelectedValue + "' ";

        String prd = "";
        for (int i = 0; i < list_product.Items.Count; i++)
        {
            if (list_product.Items[i].Selected)
                prd += "'" + list_product.Items[i].Text + "',";
        }
        prd = prd.Trim(',');
        if (prd != "") 
            sql += " 	and chart_id_product in (" + prd + ") ";


        if (list_chart.SelectedValue != "ALL")
            sql += " and item_type = '" + list_chart.SelectedValue + "' ";

        sql += " ) a ";

        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += " ) kpc ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = kpc.glass_id ";
        sql += " and a.layer = kpc.op ";
        sql += " and a.report_time > kpc.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'BM' ";
        sql += " ) bm ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = bm.glass_id ";
        sql += " and a.report_time > bm.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'R' ";
        sql += " ) r ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = r.glass_id ";
        sql += " and a.report_time > r.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'G' ";
        sql += " ) g ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = g.glass_id ";
        sql += " and a.report_time > g.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'B' ";
        sql += " ) b ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = b.glass_id ";
        sql += " and a.report_time > b.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'PS' ";
        sql += " ) ps ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = ps.glass_id ";
        sql += " and a.report_time > ps.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'OC' ";
        sql += " ) oc ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = oc.glass_id ";
        sql += " and a.report_time > oc.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'ITO' ";
        sql += " ) ito ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = ito.glass_id ";
        sql += " and a.report_time > ito.logoff_time ";

        if (cb_spec.Checked)
        {
            sql += " left join ";
            sql += " (  ";
            sql += " select 'AVG' as spec_valuetype union select 'MAX' union select 'MIN'  ";
            sql += " ) spectype ";
            sql += " on 1=1 ";
            sql += " left join ";
            sql += " ( ";
            sql += " select  ";
            sql += "     `chart_id`,  ";
            sql += "     case when user_spec_ver <> 0 then 'user' else 'spc' end as `spec_type`, ";
            sql += "     case when user_spec_ver <> 0 then user_spec_ver else spc_spec_ver end as `spec_ver`, ";
            sql += "     spec_valuetype, ";
            sql += "     usl,ucl,cl,lcl,lsl ";
            sql += "     from ";
            sql += "     ( ";
            sql += "         SELECT ";
            sql += "         ROW_NUMBER() OVER ( PARTITION BY chart_id, spec_valuetype   ";
            sql += "                       ORDER BY   ";
            sql += "                         user_spec_ver DESC, spc_spec_ver DESC ";
            sql += "                         ) as rn ";
            sql += "          , t.* ";
            sql += "          FROM l7bcf_spc.spc_spec t ";
            sql += "     ) t ";
            sql += "     where t.rn = 1 ";
            sql += " )  spec ";
            sql += " on a.chart_id = spec.chart_id and spectype.spec_valuetype = spec.spec_valuetype ";
        }
        //Response.Write(sql);

        DataTable dt = get_mysql_data(sql);
        ExportDataTable(dt);
    }

    public void ExportDataTable(DataTable dt, String fil_name = "CF_SPC_Data")
    {

        //DataTable为要导出的数据表
        DataGrid dg = new DataGrid();
        dg.DataSource = dt;
        dg.DataBind();

        //如果文件名称有中文，指定编码
        string fileName = HttpUtility.UrlEncode(fil_name, Encoding.UTF8).ToString();


        //设置编码格式
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.Charset = "UTF-8";// "UTF-8"或者"GB2312"
        HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";//text/csv
        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.UTF8;
        HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment;filename=" + fileName + ".xls");
        //导出excel
        System.IO.StringWriter oSW = new System.IO.StringWriter();
        HtmlTextWriter oHW = new HtmlTextWriter(oSW);
        dg.RenderControl(oHW);



        //输出时加上"<meta http-equiv=\"content-type\" content=\"application/ms-excel; charset=UTF-8\"/>"解决编码问题

        //返回浏览器，
        HttpContext.Current.Response.Write("<meta http-equiv=\"content-type\" content=\"application/ms-excel; charset=UTF-8\"/>" + oSW.ToString());
        HttpContext.Current.Response.End();
    }


    protected void GridView1_RowCreated(Object sender, GridViewRowEventArgs e)
    {
        DataRowView drv = (DataRowView)e.Row.DataItem;

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            try
            {
                String report_time = drv["report_time"].ToString();
                String sheet_id = drv["sheet_id"].ToString();
                String chart_id = drv["chart_id"].ToString();


                string urlToOpen = "judge.aspx?report_time=" + report_time + "&chart_id=" + chart_id + "&sheet_id=" + sheet_id;


                String temp = "<img src=\"http://tw100040017.corpnet.auo.com/L7B/CF_INT/icon/edit.png\" class=\"clickable-image\" onclick=\"OpenWin('" + urlToOpen + "','800','750');\" />";


                ((Label)(e.Row.FindControl("g_judge"))).Text = temp;
            }
            catch { }
        }

    }


}