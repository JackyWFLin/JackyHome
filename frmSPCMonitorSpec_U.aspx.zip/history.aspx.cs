﻿using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class CF_SPC_history : System.Web.UI.Page
{
    static String connString = "Database=l7bcf_spc;Data Source=tw100043811;Port=3307;User Id=l7b_commit;Password=l7b$commit;CharSet=utf8;SslMode=None;allowPublicKeyRetrieval=true";
    Color[] color = { Color.Blue, Color.Green, Color.Purple, Color.DarkGray, Color.Brown, Color.Yellow, Color.GreenYellow, Color.Gold, Color.Red, Color.Orange, Color.Green, Color.Blue, Color.Purple, Color.DarkGray, Color.Brown, Color.Yellow, Color.GreenYellow, Color.Gold, Color.Red, Color.Orange, Color.Green, Color.Blue, Color.Purple, Color.DarkGray, Color.Brown, Color.Yellow, Color.GreenYellow, Color.Gold, Color.Red, Color.Orange, Color.Green, Color.Blue, Color.Purple, Color.DarkGray, Color.Brown, Color.Yellow, Color.GreenYellow, Color.Gold, Color.Red };

    String[] line_id_ = { "FDM10", "FDR10", "FDG10", "FDB10", "FDS10", "FDM20", "FDR20", "FDS20", "FDM30", "FCI10", "FCI20", "FCV10", "FDI10" };

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            init_();

            if (!String.IsNullOrEmpty(Request.QueryString["product"]))
            {
                for (int i = 0; i < list_product.Items.Count; i++)
                {
                    list_product.Items[i].Selected = list_product.Items[i].Text == Request.QueryString["product"];
                }
            }

            if (!String.IsNullOrEmpty(Request.QueryString["layer"]))
            {
                list_layer.SelectedIndex = list_layer.Items.IndexOf(list_layer.Items.FindByValue(Request.QueryString["layer"]));
            }

            if (!String.IsNullOrEmpty(Request.QueryString["item_type"]))
            {
                list_chart.SelectedIndex = list_chart.Items.IndexOf(list_chart.Items.FindByValue(Request.QueryString["item_type"]));

            }
            if (!String.IsNullOrEmpty(Request.QueryString["report_time"]))
            {
                tb_endtime.Text = Request.QueryString["report_time"];
                tb_starttime.Text = Request.QueryString["report_time"];

                tb_starttime.Text = DateTime.Now.AddDays(-7).ToString("yyyy/MM/dd");
                tb_endtime.Text = DateTime.Now.ToString("yyyy/MM/dd");

                //tb_starttime.Text = DateTime.Parse(Request.QueryString["report_time"]).AddDays(-1).ToString("yyyy/MM/dd");
            }

            if (!String.IsNullOrEmpty(Request.QueryString["query"]))
            {
                bt_query_Click(null, null);
            }

        }

        /*
        try
        {
            if ((Session["reflash"] != null) || (Session["reflash"].ToString() == "1"))
            {
                //Response.Write("reflash");
                Session["reflash"] = null;
                plcHolder.Controls.Clear();
                bt_query_Click(null, null);
            }
        }
        catch { }
        */
    }

    public void init_()
    {
        init_control("product", list_product);
        init_control("chart", list_chart);
        init_control("line", list_line);
        tb_starttime.Text = DateTime.Now.AddDays(-7).ToString("yyyy/MM/dd");
        tb_endtime.Text = DateTime.Now.ToString("yyyy/MM/dd");
        
    }
    public void init_control(String type, DropDownList d)
    {


        String sql = "";

        d.Items.Clear();


        if (type == "product")
        {
            sql += " SELECT product_code as model FROM l7bcf_spc.chart_config order by substring(product_code,2,8) ";

        }
        else if (type == "chart")
        {
            d.Items.Add("ALL");
            sql = " SELECT distinct item_type FROM `l7bcf_spc`.`chart_config` order by item_type";
        }
        else if (type == "line")
        {
            d.Items.Add("ALL");
            foreach (String line in line_id_) 
            {
                d.Items.Add(line);
            }
            return;
        }
        DataTable dt = get_mysql_data(sql);

        foreach (DataRow r in dt.Rows)
        {
            d.Items.Add(r[0].ToString());
        }

    }
    public void init_control(String type, ListBox d)
    {


        String sql = "";

        d.Items.Clear();
        if (type == "product")
        {
            sql += " SELECT product_code as model FROM l7bcf_spc.model_config order by substring(product_code,2,8) ";
        }
        DataTable dt = get_mysql_data(sql);

        foreach (DataRow r in dt.Rows)
        {
            d.Items.Add(r[0].ToString());
        }
        if (dt.Rows.Count > 0)
        {
            d.Items[0].Selected = true;
        }

    }

    public void getdata()
    {
        String sql = "";
        sql += " select * from ( ";
        sql += " select ";

        if (rb_query_type.SelectedValue == "Sheet") 
            sql += " DATE_FORMAT(a.report_time,'%Y/%m/%d %H:%i:%s') as report_time, ";
        else if (rb_query_type.SelectedValue == "Daily")
            sql += " DATE_FORMAT(subdate(a.report_time, interval 450 minute), '%m/%d') as report_time, ";
        else if (rb_query_type.SelectedValue == "Weekly")
            sql += " concat('W', substr(DATE_FORMAT(subdate(a.report_time, interval 450 minute), '%y'),2,1), CONVERT(WEEK(a.report_time, 1), CHAR)) as report_time, ";
        else
            sql += " DATE_FORMAT(a.report_time,'%Y/%m') as report_time, ";

        sql += " a.chart_id, a.item_type, a.product_code, kpc.line_id, kpc.tool_id, a.layer, a.sheet_id, a.spc_spec_ver, a.user_spec_ver, value_max, value_min, value_avg, value_std,a.rawdata, ";
        sql += " bm.logoff_time as bm_logoff_time, ifnull(concat(bm.line_id, '(BM)'),'Nan(BM)') as bm_line_id, bm.tool_id as bm_tool_id, ";
        sql += " r.logoff_time as r_logoff_time, ifnull(concat(r.line_id, '(R)'), 'Nan(R)') as r_line_id, r.tool_id as r_tool_id, ";
        sql += " g.logoff_time as g_logoff_time, ifnull(concat(g.line_id, '(G)'), 'Nan(G)') as g_line_id, g.tool_id as g_tool_id, ";
        sql += " b.logoff_time as b_logoff_time, ifnull(concat(b.line_id, '(B)'), 'Nan(B)') as b_line_id, b.tool_id as b_tool_id, ";
        sql += " ps.logoff_time as ps_logoff_time, ifnull(concat(ps.line_id, '(PS)'), 'Nan(PS)') as ps_line_id, ps.tool_id as ps_tool_id, ";
        sql += " oc.logoff_time as oc_logoff_time, ifnull(concat(oc.line_id, '(OC)'), 'Nan(OC)') as oc_line_id, oc.tool_id as oc_tool_id, ";
        sql += " ito.logoff_time as ito_logoff_time, ifnull(concat(ito.line_id, '(ITO)'), 'Nan(ITO)') as ito_line_id, ito.tool_id as ito_tool_id, ";
        sql += " ifnull(concat(ifnull(kpc.line_id,'Nan'),'-',case when kpc.unit_id = '' then kpc.tool_id else kpc.unit_id end ),'Nan') as label_x, ";
        sql += " spectype.spec_valuetype, ";
        sql += " spec.spec_type, ";
        sql += " spec.spec_ver, ";
        sql += " spec.usl, ";
        sql += " spec.ucl, ";
        sql += " spec.cl, ";
        sql += " spec.lcl, ";
        sql += " spec.lsl, ";
        sql += " ROW_NUMBER() OVER ( PARTITION BY a.chart_id, a.sheet_id, a.report_time, spectype.spec_valuetype ORDER BY ";
        sql += " bm.logoff_time desc, r.logoff_time desc, g.logoff_time desc, b.logoff_time desc, ps.logoff_time desc, oc.logoff_time desc ) as rn ";
        sql += " from ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.spc_data ";
        sql += " 	where 1=1 ";
        sql += " 	and report_time >= '" + tb_starttime.Text + " 07:30:00' ";
        sql += " 	and report_time <= '" + DateTime.Parse(tb_endtime.Text).AddDays(1).ToString("yyyy/MM/dd 07:30:00") + "' ";
        sql += " 	and layer = '" + list_layer.SelectedValue + "' ";
        
        

        String prd = "";
        for (int i = 0; i < list_product.Items.Count; i++)
        {
            if (list_product.Items[i].Selected)
                prd += "'" + list_product.Items[i].Text + "',";
        }
        prd = prd.Trim(',');
        if (prd != "") 
            sql += " 	and chart_id_product in (" + prd + ") ";

        if (list_chart.SelectedValue == "PSH")
            sql += " and item_type in ('" + list_chart.SelectedValue + "','HEIGHT_MAIN') ";
        else if (list_chart.SelectedValue == "Delta_OLX")
            sql += " and item_type in ('" + list_chart.SelectedValue + "','OLX_DELTA') ";
        else if (list_chart.SelectedValue != "ALL")
            sql += " and item_type = '" + list_chart.SelectedValue + "' ";

        if (list_line.SelectedValue != "ALL")
            sql += " and line_id = '" + list_line.SelectedValue + "' ";

        if (!cb_exclude.Checked)
            sql += " and `exclude` = 'N' ";

        sql += " ) a ";
        
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += " ) kpc ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = kpc.glass_id ";
        sql += " and a.layer = kpc.op ";
        sql += " and a.report_time > kpc.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'BM' ";
        sql += " ) bm ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = bm.glass_id ";
        sql += " and a.report_time > bm.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'R' ";
        sql += " ) r ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = r.glass_id ";
        sql += " and a.report_time > r.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'G' ";
        sql += " ) g ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = g.glass_id ";
        sql += " and a.report_time > g.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'B' ";
        sql += " ) b ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = b.glass_id ";
        sql += " and a.report_time > b.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'PS' ";
        sql += " ) ps ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = ps.glass_id ";
        sql += " and a.report_time > ps.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'OC' ";
        sql += " ) oc ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = oc.glass_id ";
        sql += " and a.report_time > oc.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'ITO' ";
        sql += " ) ito ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = ito.glass_id ";
        sql += " and a.report_time > ito.logoff_time ";
        sql += " left join ";
        sql += " (  ";
        sql += " select 'AVG' as spec_valuetype union select 'MAX' union select 'MIN'  ";
        sql += " ) spectype ";
        sql += " on 1=1 ";
        sql += " left join ";
        sql += " ( ";
        sql += " select  ";
        sql += "     `chart_id`,  ";
        sql += "     case when user_spec_ver <> 0 then 'user' else 'spc' end as `spec_type`, ";
        sql += "     case when user_spec_ver <> 0 then user_spec_ver else spc_spec_ver end as `spec_ver`, ";
        sql += "     spec_valuetype, ";
        sql += "     usl,ucl,cl,lcl,lsl ";
        sql += "     from ";
        sql += "     ( ";
        sql += "         SELECT ";
        sql += "         ROW_NUMBER() OVER ( PARTITION BY chart_id, spec_valuetype   ";
        sql += "                       ORDER BY   ";
        sql += "                         user_spec_ver DESC, spc_spec_ver DESC ";
        sql += "                         ) as rn ";
        sql += "          , t.* ";
        sql += "          FROM l7bcf_spc.spc_spec t ";
        sql += "     ) t ";
        sql += "     where t.rn = 1 ";
        sql += " )  spec ";
        sql += " on a.chart_id = spec.chart_id and spectype.spec_valuetype = spec.spec_valuetype ";
        sql += " ) t where t.rn = 1 order by report_time ";

        String sql_table = "";
        
        sql_table += " SELECT ";
        sql_table += " DATE_FORMAT(subdate(report_time, interval 450 minute), '%m/%d') as mfg_day, ";
        sql_table += " DATE_FORMAT(report_time,'%Y/%m/%d %H:%i:%s') as report_time, ";
        sql_table += " item_type, ";
        sql_table += " chart_id, ";
        sql_table += " sheet_id, ";
        sql_table += " product_code, ";
        sql_table += " line_id, ";
        sql_table += " layer, ";
        sql_table += " value_AVG, ";
        sql_table += " value_MIN, ";
        sql_table += " value_MAX, ";
        sql_table += " `exclude`, ";
        sql_table += " judge_man, ";
        sql_table += " judge_note ";
        sql_table += " 	FROM l7bcf_spc.spc_data ";
        sql_table += " 	where 1=1 ";
        sql_table += " 	and report_time >= '" + tb_starttime.Text + " 07:30:00' ";
        sql_table += " 	and report_time <= '" + DateTime.Parse(tb_endtime.Text).AddDays(1).ToString("yyyy/MM/dd 07:30:00") + "' ";
        sql_table += " 	and layer = '" + list_layer.SelectedValue + "' ";

        if (prd != "")
            sql_table += " 	and chart_id_product in (" + prd + ") ";

        if (list_chart.SelectedValue != "ALL")
            sql_table += " and item_type = '" + list_chart.SelectedValue + "' ";

        if (list_line.SelectedValue != "ALL")
            sql_table += " and line_id = '" + list_line.SelectedValue + "' ";

        sql_table += " 	order by item_type,report_time ";
        //Response.Write(sql);


        DataTable dt_edit = get_mysql_data(sql_table);
        GridView1.DataSource = dt_edit;
        GridView1.DataBind();



        DataTable dt = get_mysql_data(sql);

        List<String> x_list = new List<string>();
        for (int i = 0; i < CB_layer_list.Items.Count; i++)
        {
            if (CB_layer_list.Items[i].Selected)
                x_list.Add(CB_layer_list.Items[i].Text);
        }
        if (x_list.Count > 0)
        {
            

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                dt.Rows[i]["label_x"] = "";
                foreach (String op in x_list.ToArray())
                {
                    if (op == "Product")
                        dt.Rows[i]["label_x"] += "-" + dt.Rows[i]["chart_id"].ToString().Split('/')[0];
                    else
                        dt.Rows[i]["label_x"] += "-" + dt.Rows[i][op + "_line_id"].ToString();

                }
                dt.Rows[i]["label_x"] = dt.Rows[i]["label_x"].ToString().Trim('-');
            }
        }


        if (dt.Rows.Count > 0)
        {
            lb_error.Text = "";

            string[] item_list = dt.AsEnumerable().Select(row => row.Field<string>("item_type")).Distinct().ToArray();
            
            


            foreach (String item in item_list)
            {




                var div = new HtmlGenericControl("div");
                div.ID = item;
                div.InnerText = "";
                plcHolder.Controls.Add(div);

                List<HyperLink> links = new List<HyperLink>();
                for (int i = 0; i < item_list.Length; i++)
                {
                    HyperLink link = new HyperLink();
                    link.Text = "☆" + item_list[i] + "&nbsp;";
                    link.Attributes["href"] = "#" + item_list[i];
                    link.Attributes["class"] = "scroll-link";
                    links.Add(link);
                }

                foreach (HyperLink v in links.ToArray())
                {
                    plcHolder.Controls.Add(v);
                    plcHolder.Controls.Add(addlabel("&nbsp;"));
                }
                plcHolder.Controls.Add(addlabel("<br>"));


                


                
                try
                {
                    DataTable dt_filter = (from row in dt.AsEnumerable() where row.Field<string>("item_type") == item select row).CopyToDataTable();
                    string[] chart_id_list = dt_filter.AsEnumerable().Select(row => row.Field<string>("chart_id")).Distinct().ToArray();

                    if (cb_chart_overlap.Checked)
                    {
                        Label lb_title = new Label();
                        lb_title.Text = item + " (";
                        foreach (String chart in chart_id_list)
                            lb_title.Text += chart + ",";
                        lb_title.Text = lb_title.Text.Trim(',') + ")";
                        lb_title.Width = 1808;
                        lb_title.BackColor = Color.Gray;
                        lb_title.ForeColor = Color.White;
                        lb_title.Font.Bold = true;
                        plcHolder.Controls.Add(lb_title);
                        plcHolder.Controls.Add(addlabel("<br>"));

                        //line_chart(dt_filter, item, "value_avg", true, "AVG");
                        line_echart(dt_filter, item, "value_avg", true, "AVG");
                        
                        //boxplot(dt_filter, item, "value_avg", true, "AVG");
                        //eboxplot(dt_filter, item, "value_avg", true, "AVG");

                }
                    else
                    {
                        foreach (String chart_id in chart_id_list)
                        {
                            DataTable dt_filter_chart = (from row in dt_filter.AsEnumerable() where row.Field<string>("chart_id") == chart_id select row).CopyToDataTable();

                            Label lb_title = new Label();
                            lb_title.Text = item + " (" + chart_id + ") ";
                            lb_title.Text = "<a href=\"" + "trans.aspx?chart=" + chart_id.Split('/')[0] + "&layer=" + list_layer.SelectedValue + "&start_time=" + tb_starttime.Text + "&end_time=" + tb_endtime.Text
                            + "&item_type=" + list_chart.SelectedValue + "\" target=\"_blank\" >" + lb_title.Text + "</a>";
                            lb_title.Width = 1254;
                            lb_title.BackColor = Color.LightGray;
                            lb_title.ForeColor = Color.White;
                            lb_title.Font.Bold = true;
                            plcHolder.Controls.Add(lb_title);
                            plcHolder.Controls.Add(addlabel("<br>"));
                            //line_chart(dt_filter_chart, item, "value_avg", true, "AVG");
                            line_echart(dt_filter_chart, item, "value_avg", true, "AVG");
                            //boxplot(dt_filter_chart, item, "value_avg", true, "AVG");
                            //eboxplot(dt_filter_chart, item, "value_avg", true, "AVG");
                        }
                    }
                
                }
                catch
                {
                    plcHolder.Controls.Add(addlabel("NoData<br>"));
                    Response.Write("ERROR:" + item + "<br>");
                }
                
                plcHolder.Controls.Add(addlabel("<br>"));
            }

        }
        else
        {
            lb_error.Text = "No data!";
        }
        

        //GridView1.DataSource = dt;
        //GridView1.DataBind();

    }

    public void boxplot(DataTable dt1, String item, String tp, Boolean spec, String value_type, String eqp = "")
    {



        DataTable dt = (from row in dt1.AsEnumerable() where row.Field<string>("spec_valuetype") == value_type select row).CopyToDataTable();


        Chart Chart1 = new Chart();
        Chart1.ChartAreas.Add(new ChartArea());
        Chart1.Width = 650;
        Chart1.Height = 450;


        string[] unit = dt.AsEnumerable().Select(row => row.Field<string>("label_x")).Distinct().OrderBy(tool_str => tool_str).ToArray();


        Font f = new Font("Arial", 9);

        Chart1.BackColor = Color.FromArgb(238, 238, 255);

        //Series[] series = new Series[unit.Length];
        Series[] series = new Series[1];

        for (int i = 0; i < series.Length; i++)
        {
            series[i] = new Series(unit[i], 10000);
            series[i].Color = color[i];
            series[i].ChartType = SeriesChartType.BoxPlot;
            series[i].BorderWidth = 2;
            series[i].ShadowOffset = 0;
            
        }

        List<double> Q0Data = new List<double>();
        List<double> Q1Data = new List<double>();
        List<double> Q2Data = new List<double>();
        List<double> Q3Data = new List<double>();
        List<double> Q4Data = new List<double>();
        List<string> label_x = new List<string>();
        List<string> url_list = new List<string>();


        double LSL = 99999;
        double USL = 99999;
        double UCL = 99999;
        double LCL = 99999;

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            if (i == 0)
            {
                if (dt.Rows[i]["LSL"].ToString() != "")
                    LSL = double.Parse(dt.Rows[i]["LSL"].ToString());
                if (dt.Rows[i]["USL"].ToString() != "")
                    USL = double.Parse(dt.Rows[i]["USL"].ToString());
                if (dt.Rows[i]["UCL"].ToString() != "")
                    UCL = double.Parse(dt.Rows[i]["UCL"].ToString());
                if (dt.Rows[i]["LCL"].ToString() != "")
                    LCL = double.Parse(dt.Rows[i]["LCL"].ToString());
            }
            url_list.Add("trans.aspx?chart=" + dt.Rows[i]["chart_id"].ToString().Split('/')[0] + "&layer=" + list_layer.SelectedValue + "&report_time=" + dt.Rows[i]["report_time"].ToString()
                + "&sheet_id=" + dt.Rows[i]["sheet_id"].ToString() + "&item_type=" + dt.Rows[i]["item_type"].ToString()) ;
            label_x.Add(dt.Rows[i]["report_time"].ToString());
            String[] value = dt.Rows[i]["rawdata"].ToString().Split(',');
            List<double> l_x = new List<double>();
            for (int j = 0; j < value.Length; j++)
            {
                l_x.Add(Convert.ToDouble(value[j]));
            }

            double[] temp_x = l_x.ToArray();
            Array.Sort(temp_x);
            Q0Data.Add(temp_x[0]);
            Q4Data.Add(temp_x[temp_x.Length - 1]);
            int q1_count = Convert.ToInt32(Math.Floor(temp_x.Length * 0.25));
            int q2_count = Convert.ToInt32(Math.Floor(temp_x.Length * 0.5));
            int q3_count = Convert.ToInt32(Math.Floor(temp_x.Length * 0.75));

            Q1Data.Add(temp_x[q1_count]);
            Q2Data.Add(temp_x[q2_count]);
            Q3Data.Add(temp_x[q3_count]);

        }


        List<double> v_list = new List<double>();

        Chart1.BackColor = Color.FromArgb(238, 238, 255);

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            v_list.Add(double.Parse(dt.Rows[i]["value_MAX"].ToString()));
            v_list.Add(double.Parse(dt.Rows[i]["value_MIN"].ToString()));

            int index_s = Array.IndexOf(unit, dt.Rows[i]["label_x"].ToString());

            series[0].Points.AddXY(dt.Rows[i]["report_time"].ToString(), new object[]
                        {
                        double.Parse(dt.Rows[i]["value_min"].ToString()),
                        double.Parse(dt.Rows[i]["value_max"].ToString()),
                        Q1Data[i],
                        Q3Data[i],
                        Q2Data[i],
                        double.Parse(dt.Rows[i]["value_avg"].ToString()) }
                        );

            series[0].Points[series[0].Points.Count - 1].Color = color[index_s];            
            String tooltip = dt.Rows[i]["label_x"].ToString() + "\n " +
                             "SHEET : " + dt.Rows[i]["sheet_id"].ToString();
            series[0].Points[series[0].Points.Count - 1].ToolTip = tooltip;
            
            series[0].Points[series[0].Points.Count - 1].Url = url_list[i];


            /*
            for (int j = 0; j < series.Length; j++)
            {
                //lb_error.Visible = true;
                //lb_error.Text += j.ToString() + " " + index_s.ToString() + " " + (j == index_s).ToString() + "<br>";

                if (j == index_s)
                {
                    series[index_s].Points.AddXY(dt.Rows[i]["report_time"].ToString(), new object[]
                        {
                        double.Parse(dt.Rows[i]["value_min"].ToString()),
                        double.Parse(dt.Rows[i]["value_max"].ToString()),
                        Q1Data[i],
                        Q3Data[i],
                        Q2Data[i],
                        double.Parse(dt.Rows[i]["value_avg"].ToString()) }
                        );

                    series[index_s].Points[series[index_s].Points.Count - 1].Color = color[index_s];
                    series[index_s].Points[series[index_s].Points.Count - 1].MarkerColor = series[series.Length - 1].Color;
                    String tooltip = dt.Rows[i]["label_x"].ToString() + "\n " +
                                     "SHEET : " + dt.Rows[i]["sheet_id"].ToString();
                    series[index_s].Points[series[index_s].Points.Count - 1].ToolTip = tooltip;
                    series[index_s].Points[series[index_s].Points.Count - 1].Url = "trans.aspx?" + url_list[i];

                }
                else
                {
                    
                    /*
                    series[j].Points.AddXY(dt.Rows[i]["report_time"].ToString(), new object[]
                        {
                        double.NaN,
                        double.NaN,
                        double.NaN,
                        double.NaN,
                        double.NaN,
                        double.NaN
                        });
                    
        }

            }

            */
        }





        /*
        Chart1.Legends.Add(new Legend());
        Chart1.Legends[0].BackColor = Color.FromArgb(238, 238, 255);
        Chart1.Legends[0].Docking = Docking.Top;
        Chart1.Legends[0].Alignment = StringAlignment.Near;
        Chart1.Legends[0].Font = new Font("Arial", 9);
        */

        Chart1.ChartAreas[0].AxisX.IntervalAutoMode = IntervalAutoMode.VariableCount;

        Chart1.ChartAreas[0].AxisX.LabelStyle.Angle = 90;
        Chart1.ChartAreas[0].AxisX.MajorGrid.Interval = 1;
        Chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = false;

        Chart1.ChartAreas[0].Position.X = 0;
        Chart1.ChartAreas[0].Position.Y = 60;
        Chart1.ChartAreas[0].Position.Height = 80;
        Chart1.ChartAreas[0].Position.Width = 90;

        Chart1.ChartAreas[0].AxisX.LabelStyle.Font = new Font("Arial", 10, FontStyle.Bold);
        Chart1.ChartAreas[0].AxisY.LabelStyle.Font = new Font("Arial", 10, FontStyle.Bold);
        Chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.LightGray;
        Chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.LightGray;



        double y_max = -99999;
        double y_UCL = -99999;
        try
        {
            y_max = double.Parse(dt.Rows[0]["USL"].ToString());
        }
        catch { }
        try
        {
            y_UCL = double.Parse(dt.Rows[0]["UCL"].ToString());
        }
        catch { }



        double y_min = 99999;
        double y_LCL = 99999;

        try
        {
            y_min = double.Parse(dt.Rows[0]["LSL"].ToString());
        }
        catch { }
        try
        {
            y_LCL = double.Parse(dt.Rows[0]["LCL"].ToString());
        }
        catch { }

        double spec_upper = 9999;
        double spec_lower = -9999;

        try
        {
            if (dt.Rows[0]["UCL"].ToString() != "")
                spec_upper = double.Parse(dt.Rows[0]["UCL"].ToString());
            else
                spec_upper = double.Parse(dt.Rows[0]["USL"].ToString());
        }
        catch { }

        try
        {
            if (dt.Rows[0]["LCL"].ToString() != "")
                spec_lower = double.Parse(dt.Rows[0]["LCL"].ToString());
            else
                spec_lower = double.Parse(dt.Rows[0]["LSL"].ToString());
        }
        catch
        {

        }
        
        for (int i = 0; i < series.Length; i++)
        {
            series[i].MapAreaAttributes = "target=\"_blank\"";
            Chart1.Series.Add(series[i]);
        }
        
        

        

        double[] v = v_list.ToArray();

        try
        {
            y_max = double.Parse(dt.Rows[0]["USL"].ToString());
        }
        catch { }
        try
        {
            y_UCL = double.Parse(dt.Rows[0]["UCL"].ToString());
        }
        catch { }

        try
        {
            y_min = double.Parse(dt.Rows[0]["LSL"].ToString());
        }
        catch { }
        try
        {
            y_LCL = double.Parse(dt.Rows[0]["LCL"].ToString());
        }
        catch { }


        double y_upper = v.Max();
        double y_lower = v.Min();
        if (spec)
        {
            y_upper = Math.Max(y_upper, y_max);
            y_lower = Math.Min(y_lower, y_min);
        }
        y_upper += (y_upper - y_lower) * 0.2;
        y_lower -= (y_upper - y_lower) * 0.2;

        try
        {
            if (dt.Rows[0]["UCL"].ToString() != "")
                spec_upper = double.Parse(dt.Rows[0]["UCL"].ToString());
            else
                spec_upper = double.Parse(dt.Rows[0]["USL"].ToString());
        }
        catch { }

        try
        {
            if (dt.Rows[0]["LCL"].ToString() != "")
                spec_lower = double.Parse(dt.Rows[0]["LCL"].ToString());
            else
                spec_lower = double.Parse(dt.Rows[0]["LSL"].ToString());
        }
        catch
        {

        }



        if (y_upper != y_lower)
        {
            Chart1.ChartAreas[0].AxisY.Maximum = Math.Round(y_upper, 6);
            Chart1.ChartAreas[0].AxisY.Minimum = Math.Round(y_lower, 6);
            Chart1.ChartAreas[0].AxisY.Interval = Math.Round((y_upper - y_lower) * 0.2, 6);
        }



        //Chart1.ChartAreas[0].AxisY.Maximum = Math.Round(v.Max() + (v.Max() - v.Min()) * 0.05, 6);
        //Chart1.ChartAreas[0].AxisY.Minimum = Math.Round(v.Min() - (v.Max() - v.Min()) * 0.05, 6);
        //Chart1.ChartAreas[0].AxisY.Interval = Math.Round((v.Max() - v.Min()) * 0.2, 6);


        
        if (spec)
        {
            double dd = Chart1.ChartAreas[0].AxisY.Interval / 10;
            //if (dd < 0.08)
            //    dd = 0.08;
            if (dt.Rows[0]["USL"].ToString() != "")
            {
                StripLine sl1 = new StripLine();

                sl1.BackColor = System.Drawing.Color.Red;
                sl1.IntervalOffset = y_max;
                sl1.StripWidth = dd;
                sl1.Font = new Font("Mabry Pro", 10, FontStyle.Bold);
                sl1.ForeColor = Color.Red;
                sl1.Text = y_max.ToString();
                sl1.TextAlignment = StringAlignment.Far;
                sl1.TextLineAlignment = StringAlignment.Far;
                Chart1.ChartAreas[0].AxisY.StripLines.Add(sl1);
            }
            if (dt.Rows[0]["LSL"].ToString() != "")
            {
                StripLine sl1 = new StripLine();

                sl1.BackColor = System.Drawing.Color.Red;
                sl1.IntervalOffset = y_min;
                sl1.StripWidth = dd;
                sl1.Font = new Font("Mabry Pro", 10, FontStyle.Bold);
                sl1.ForeColor = Color.Red;
                sl1.Text = y_min.ToString();

                sl1.TextAlignment = StringAlignment.Far;
                sl1.TextLineAlignment = StringAlignment.Near;
                Chart1.ChartAreas[0].AxisY.StripLines.Add(sl1);
            }
            if (dt.Rows[0]["LCL"].ToString() != "")
            {
                StripLine sl1 = new StripLine();

                sl1.BackColor = System.Drawing.Color.Orange;
                sl1.IntervalOffset = y_LCL;
                sl1.StripWidth = dd;
                sl1.Font = new Font("Mabry Pro", 10, FontStyle.Bold);
                sl1.ForeColor = Color.Orange;
                sl1.TextAlignment = StringAlignment.Far;
                sl1.TextLineAlignment = StringAlignment.Near;
                sl1.Text = "LCL";
                Chart1.ChartAreas[0].AxisY.StripLines.Add(sl1);
            }
            if (dt.Rows[0]["UCL"].ToString() != "")
            {
                StripLine sl1 = new StripLine();

                sl1.BackColor = System.Drawing.Color.Orange;
                sl1.IntervalOffset = y_UCL;
                sl1.StripWidth = dd;
                sl1.Font = new Font("Mabry Pro", 10, FontStyle.Bold);
                sl1.ForeColor = Color.Orange;
                sl1.TextAlignment = StringAlignment.Far;
                sl1.TextLineAlignment = StringAlignment.Near;
                sl1.Text = "UCL";
                Chart1.ChartAreas[0].AxisY.StripLines.Add(sl1);
            }


        }
        
        Title title = new Title();
        title.Font = new Font("Arial", 15, FontStyle.Bold);
        title.Text = item + " " + tp.Replace("value_", "").ToUpper();
        if (eqp != "")
            title.Text = eqp + " " + title.Text;
        Chart1.Titles.Add(title);

        //Chart1.Titles[0].PostBackValue = dt1.Rows[0]["chart_id_product"].ToString() + "^" + value_type;
        Chart1.DataBind();

        //Chart1.Click += new ImageMapEventHandler(Chart1_Click);

        plcHolder.Controls.Add(Chart1);

    }
    public List<BoxPlotData> GenerateBoxPlotData(DataTable dt)
    {
        var boxPlotDataList = new List<BoxPlotData>();

        // Grouping by series and report_time
        var groupedData = dt.AsEnumerable()
            .GroupBy(row => new {
                Series = row.Field<string>("series"),
                ReportTime = row.Field<string>("report_time")
            });

        foreach (var group in groupedData)
        {
            var data = group.Select(x => x.Field<string>("value_str"))
                .SelectMany(y => y.Split(',').Select(double.Parse)).ToArray();

            // 计算箱线图统计信息
            Array.Sort(data);
            var q1 = data[(int)(data.Length * 0.25)];
            var median = data[(int)(data.Length * 0.5)];
            var q3 = data[(int)(data.Length * 0.75)];

            var boxPlotData = new BoxPlotData
            {
                Series = group.Key.Series,
                ReportTime = group.Key.ReportTime,
                BoxPlotValues = new double[]
                {
                    data.Min(),  // Min
                    q1,          // Q1
                    median,      // Median
                    q3,          // Q3
                    data.Max()   // Max
                }                
            };
            
            boxPlotDataList.Add(boxPlotData);
        }

        return boxPlotDataList;
    }
    public class BoxPlotData
    {
        public string Series { get; set; }
        public string ReportTime { get; set; }
        public double[] BoxPlotValues { get; set; }
    }


    public void line_chart(DataTable dt1, String item, String tp, Boolean spec, String value_type, String eqp = "")
    {



        DataTable dt = (from row in dt1.AsEnumerable() where row.Field<string>("spec_valuetype") == value_type select row).CopyToDataTable();


        DataTable dt_group = new DataTable();
        dt_group.Columns.Add("report_time", typeof(string));
        dt_group.Columns.Add("label_x", typeof(string));
        dt_group.Columns.Add("value", typeof(double));

        if (rb_query_type.SelectedValue != "Sheet")
        {
            var result = from row in dt.AsEnumerable()
                         group row by new
                         {
                             report_time = row.Field<string>("report_time"),
                             label_x = row.Field<string>("label_x")
                             
                         } into g
                         select new
                         {
                             report_time = g.Key.report_time,
                             label_x = g.Key.label_x,
                             value = g.Average(x => x.Field<double>(tp))
                         };

            // 創建一個新的 DataTable
            foreach (var it in result)
            {
                dt_group.Rows.Add(it.report_time, it.label_x, it.value);
            }
        }



        Chart Chart1 = new Chart();
        Chart1.ChartAreas.Add(new ChartArea());
        Chart1.Width = 600;
        Chart1.Height = 450;


        List<string> unit_temp = new List<string>();
        List<double> v_list = new List<double>();

        if (dt_group.Rows.Count > 0)
        {
            foreach (DataRow r in dt_group.Rows)
            {
                v_list.Add(double.Parse(r["value"].ToString()));
            }
        }
        else
        {
            foreach (DataRow r in dt.Rows)
            {
                v_list.Add(double.Parse(r[tp].ToString()));
            }
        }


        double[] v = v_list.ToArray();
        string[] unit = dt.AsEnumerable().Select(row => row.Field<string>("label_x")).Distinct().OrderBy(tool_str => tool_str).ToArray();


        Font f = new Font("Arial", 9);

        Chart1.BackColor = Color.FromArgb(238, 238, 255);
        //Series[] series = new Series[unit.Length + 1];
        Series[] series = new Series[unit.Length];

        for (int i = 0; i < series.Length; i++)
        {
            series[i] = new Series(unit[i], 10000);
            series[i].Color = color[i];
            series[i].ChartType = SeriesChartType.Point;
            series[i].MarkerStyle = MarkerStyle.Circle;
            series[i].MarkerSize = 8;
            series[i].ShadowOffset = 0;
        }



        Chart1.Legends.Add(new Legend());
        Chart1.Legends[0].BackColor = Color.FromArgb(238, 238, 255);
        Chart1.Legends[0].Docking = Docking.Top;
        Chart1.Legends[0].Alignment = StringAlignment.Near;
        Chart1.Legends[0].Font = new Font("Arial", 9);


        Chart1.ChartAreas[0].AxisX.IntervalAutoMode = IntervalAutoMode.VariableCount;

        Chart1.ChartAreas[0].AxisX.LabelStyle.Angle = 90;
        Chart1.ChartAreas[0].AxisX.MajorGrid.Interval = 1;
        Chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = false;

        Chart1.ChartAreas[0].Position.X = 0;
        Chart1.ChartAreas[0].Position.Y = 60;
        Chart1.ChartAreas[0].Position.Height = 80;
        Chart1.ChartAreas[0].Position.Width = 100;




        double y_max = -99999;
        double y_UCL = -99999;
        try
        {
            y_max = double.Parse(dt.Rows[0]["USL"].ToString());
        }
        catch { }
        try
        {
            y_UCL = double.Parse(dt.Rows[0]["UCL"].ToString());
        }
        catch { }



        double y_min = 99999;
        double y_LCL = 99999;

        try
        {
            y_min = double.Parse(dt.Rows[0]["LSL"].ToString());
        }
        catch { }
        try
        {
            y_LCL = double.Parse(dt.Rows[0]["LCL"].ToString());
        }
        catch { }


        double y_upper = v.Max();
        double y_lower = v.Min();
        if (spec)
        {
            y_upper = Math.Max(y_upper, y_max);
            y_lower = Math.Min(y_lower, y_min);
        }
        y_upper += (y_upper - y_lower) * 0.2;
        y_lower -= (y_upper - y_lower) * 0.2;


        double spec_upper = 9999;
        double spec_lower = -9999;

        try
        {
            if (dt.Rows[0]["UCL"].ToString() != "")
                spec_upper = double.Parse(dt.Rows[0]["UCL"].ToString());
            else
                spec_upper = double.Parse(dt.Rows[0]["USL"].ToString());
        }
        catch { }

        try
        {
            if (dt.Rows[0]["LCL"].ToString() != "")
                spec_lower = double.Parse(dt.Rows[0]["LCL"].ToString());
            else
                spec_lower = double.Parse(dt.Rows[0]["LSL"].ToString());
        }
        catch
        {

        }



        if (y_upper != y_lower)
        {
            Chart1.ChartAreas[0].AxisY.Maximum = Math.Round(y_upper, 6);
            Chart1.ChartAreas[0].AxisY.Minimum = Math.Round(y_lower, 6);
            Chart1.ChartAreas[0].AxisY.Interval = Math.Round((y_upper - y_lower) * 0.2, 6);
        }

        Chart1.ChartAreas[0].AxisX.LabelStyle.Font = new Font("Arial", 10, FontStyle.Bold);
        Chart1.ChartAreas[0].AxisY.LabelStyle.Font = new Font("Arial", 10, FontStyle.Bold);
        Chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.LightGray;
        Chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.LightGray;


        if (dt_group.Rows.Count > 0)
        {
            for (int i = 0; i < dt_group.Rows.Count; i++)
            {
                int index_s = Array.IndexOf(unit, dt_group.Rows[i]["label_x"].ToString());
                series[series.Length - 1].Points.AddXY(dt_group.Rows[i]["report_time"].ToString(), dt_group.Rows[i]["value"].ToString());
                series[series.Length - 1].Points[i].MarkerColor = color[index_s];
                double v_temp = double.Parse(dt_group.Rows[i]["value"].ToString());
                if (spec)
                {
                    if ((v_temp > spec_upper) || (v_temp < spec_lower))
                    {
                        series[series.Length - 1].Points[i].MarkerBorderColor = Color.Red;
                        series[series.Length - 1].Points[i].MarkerBorderWidth = 2;
                        series[series.Length - 1].Points[i].MarkerSize = 10;
                    }

                }
                String tooltip = dt_group.Rows[i]["label_x"].ToString() + "\n "
                                 + tp + " : " + dt_group.Rows[i]["value"].ToString() + "\n ";
                series[series.Length - 1].Points[i].ToolTip = tooltip;
            }
        }
        else
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                int index_s = Array.IndexOf(unit, dt.Rows[i]["label_x"].ToString());
                series[series.Length - 1].Points.AddXY(dt.Rows[i]["report_time"].ToString(), dt.Rows[i][tp].ToString());
                series[series.Length - 1].Points[i].MarkerColor = color[index_s];
                double v_temp = double.Parse(dt.Rows[i][tp].ToString());
                if (spec)
                {
                    if ((v_temp > spec_upper) || (v_temp < spec_lower))
                    {
                        series[series.Length - 1].Points[i].MarkerBorderColor = Color.Red;
                        series[series.Length - 1].Points[i].MarkerBorderWidth = 2;
                        series[series.Length - 1].Points[i].MarkerSize = 10;
                    }

                }
                String tooltip = dt.Rows[i]["label_x"].ToString() + "\n " +
                                 "SHEET : " + dt.Rows[i]["sheet_id"].ToString() + "\n "
                                 + tp + " : " + dt.Rows[i][tp].ToString() + "\n ";

                series[series.Length - 1].Points[i].ToolTip = tooltip;
                series[series.Length - 1].Points[i].Url = "trans.aspx?chart=" + dt.Rows[i]["chart_id"].ToString().Split('/')[0] + "&report_time=" + dt.Rows[i]["report_time"].ToString()
                    + "&sheet_id=" + dt.Rows[i]["sheet_id"].ToString() + "&item_type=" + dt.Rows[i]["item_type"].ToString() + "&layer=" + dt.Rows[i]["layer"].ToString();
            }
        }


        for (int i = 0; i < series.Length; i++)
        {
            series[i].MapAreaAttributes = "target=\"_blank\"";
            Chart1.Series.Add(series[i]);
        }

        /*
        String txt = "";
        string[] tool_str_list = dt.AsEnumerable().Select(row => row.Field<string>("label_x")).Distinct().OrderBy(tool_str => tool_str).ToArray();
        foreach (String tool_str in tool_str_list)
        {
            txt += tool_str + "\n";
            DataTable dt_filter = dt.AsEnumerable().Where(row => row.Field<string>("label_x") == tool_str).OrderByDescending(row => row.Field<string>("report_time")).CopyToDataTable();

            for (int i = 0; i < dt_filter.Rows.Count; i++)
            {
                txt += dt_filter.Rows[i]["report_time"].ToString() + " = " + Math.Round(double.Parse(dt_filter.Rows[i][tp].ToString()), 2).ToString("0.00") + " - " + dt_filter.Rows[i]["sheet_id"].ToString() + " - " + dt_filter.Rows[i]["product_code"].ToString() + "\n";
                if (i >= 2)
                    break;
            }
            txt += "\n";
        }
        // 創建和添加文本標註
        TextAnnotation textAnnotation = new TextAnnotation();
        textAnnotation.X = 67;  // 文本的X坐標位置
        textAnnotation.Y = 20;  // 文本的Y坐標位置
        textAnnotation.Text = txt;     // 要顯示的自定義文本
        textAnnotation.ForeColor = Color.Black;  // 文字顏色
        textAnnotation.Font = new Font("Arial", 8, FontStyle.Bold);
        textAnnotation.Alignment = ContentAlignment.TopLeft;
        Chart1.Annotations.Add(textAnnotation);
        */


        if (spec)
        {
            double dd = Chart1.ChartAreas[0].AxisY.Interval / 10;
            //if (dd < 0.08)
            //    dd = 0.08;
            if (dt.Rows[0]["USL"].ToString() != "")
            {
                StripLine sl1 = new StripLine();

                sl1.BackColor = System.Drawing.Color.Red;
                sl1.IntervalOffset = y_max;
                sl1.StripWidth = dd;
                sl1.Font = new Font("Mabry Pro", 10, FontStyle.Bold);
                sl1.ForeColor = Color.Red;
                sl1.Text = y_max.ToString();
                sl1.TextAlignment = StringAlignment.Far;
                sl1.TextLineAlignment = StringAlignment.Far;
                Chart1.ChartAreas[0].AxisY.StripLines.Add(sl1);
            }
            if (dt.Rows[0]["LSL"].ToString() != "")
            {
                StripLine sl1 = new StripLine();

                sl1.BackColor = System.Drawing.Color.Red;
                sl1.IntervalOffset = y_min;
                sl1.StripWidth = dd;
                sl1.Font = new Font("Mabry Pro", 10, FontStyle.Bold);
                sl1.ForeColor = Color.Red;
                sl1.Text = y_min.ToString();

                sl1.TextAlignment = StringAlignment.Far;
                sl1.TextLineAlignment = StringAlignment.Near;
                Chart1.ChartAreas[0].AxisY.StripLines.Add(sl1);
            }
            if (dt.Rows[0]["LCL"].ToString() != "")
            {
                StripLine sl1 = new StripLine();

                sl1.BackColor = System.Drawing.Color.Orange;
                sl1.IntervalOffset = y_LCL;
                sl1.StripWidth = dd;
                sl1.Font = new Font("Mabry Pro", 10, FontStyle.Bold);
                sl1.ForeColor = Color.Orange;
                sl1.TextAlignment = StringAlignment.Far;
                sl1.TextLineAlignment = StringAlignment.Near;
                sl1.Text = "LCL";
                Chart1.ChartAreas[0].AxisY.StripLines.Add(sl1);
            }
            if (dt.Rows[0]["UCL"].ToString() != "")
            {
                StripLine sl1 = new StripLine();

                sl1.BackColor = System.Drawing.Color.Orange;
                sl1.IntervalOffset = y_UCL;
                sl1.StripWidth = dd;
                sl1.Font = new Font("Mabry Pro", 10, FontStyle.Bold);
                sl1.ForeColor = Color.Orange;
                sl1.TextAlignment = StringAlignment.Far;
                sl1.TextLineAlignment = StringAlignment.Near;
                sl1.Text = "UCL";
                Chart1.ChartAreas[0].AxisY.StripLines.Add(sl1);
            }


        }
        Title title = new Title();
        title.Font = new Font("Arial", 15, FontStyle.Bold);
        title.Text = item + " " + tp.Replace("value_", "").ToUpper();
        if (eqp != "")
            title.Text = eqp + " " + title.Text;
        Chart1.Titles.Add(title);

        //Chart1.Titles[0].PostBackValue = dt1.Rows[0]["chart_id_product"].ToString() + "^" + value_type;
        Chart1.DataBind();

        //Chart1.Click += new ImageMapEventHandler(Chart1_Click);

        plcHolder.Controls.Add(Chart1);

    }

    public void line_echart(DataTable dt1, String item, String tp, Boolean spec, String value_type, String eqp = "")
    {


        String control_result = "<table cellpadding=\"10\"><tr>";

        DataTable dt = (from row in dt1.AsEnumerable() where row.Field<string>("spec_valuetype") == value_type select row).CopyToDataTable();


        DataTable dt_group = new DataTable();
        dt_group.Columns.Add("report_time", typeof(string));
        dt_group.Columns.Add("label_x", typeof(string));
        dt_group.Columns.Add(tp, typeof(double));
        dt_group.Columns.Add("tooltip", typeof(string));
        dt_group.Columns.Add("url", typeof(string));


        if (rb_query_type.SelectedValue != "Sheet")
        {
            var result = from row in dt.AsEnumerable()
                         group row by new
                         {
                             report_time = row.Field<string>("report_time"),
                             item_type = row.Field<string>("item_type"),
                             chart_id = row.Field<string>("chart_id"),
                             layer = row.Field<string>("layer"),
                             label_x = row.Field<string>("label_x")

                         } into g
                         select new
                         {
                             report_time = g.Key.report_time,
                             item_type = g.Key.item_type,
                             chart_id = g.Key.chart_id,
                             label_x = g.Key.label_x,
                             layer = g.Key.layer,
                             value = g.Average(x => x.Field<double>(tp))
                         };

            // 創建一個新的 DataTable
            foreach (var it in result)
            {
                String url = "trans.aspx?chart=" + it.chart_id.Split('/')[0] + "&report_time=" + it.report_time.ToString()
                   + "&item_type=" + it.item_type + "&layer=" + it.layer;

                dt_group.Rows.Add(it.report_time, it.label_x, it.value, it.label_x + "<br>" + it.report_time + "<br>" + it.value, url);
            }
        }
        else
        {

            foreach (DataRow r in dt.Rows)
            {
           
                String url = "trans.aspx?chart=" + r["chart_id"].ToString().Split('/')[0] + "&report_time=" + r["report_time"].ToString()
                    + "&sheet_id=" + r["sheet_id"].ToString() + "&item_type=" + r["item_type"].ToString() + "&layer=" + r["layer"].ToString();

                dt_group.Rows.Add(r["report_time"].ToString(), r["label_x"].ToString(), double.Parse(r[tp].ToString())
                    , r["label_x"].ToString() + "<br>" + r["report_time"].ToString() + "<br>" + r["sheet_id"].ToString() + "<br>" + r[tp].ToString(), url);
            }
        }


        List<double> v_list = new List<double>();

        
        

        string[] series_name = dt_group.AsEnumerable().Select(row => row.Field<string>("label_x")).Distinct().OrderBy(label_x => label_x).ToArray();
        string[] Xdata = dt_group.AsEnumerable().Select(row => row.Field<string>("report_time")).Distinct().OrderBy(report_time => report_time).ToArray();

        DataTable dt_draw= new DataTable();
        dt_draw.Columns.Add("data_x", typeof(String));
        foreach (String s in series_name)
        {
            dt_draw.Columns.Add(s, typeof(double));
            dt_draw.Columns.Add(s + "_tooltip", typeof(String));
            dt_draw.Columns.Add(s + "_url", typeof(String));
        }
        foreach (String x in Xdata)
        {
            DataRow r = dt_draw.NewRow();
            r[0] = x;
            for (int j = 1; j < dt_draw.Columns.Count; j++)
                r[j] = Double.NaN;
            dt_draw.Rows.Add(x);
        }
        for (int i = 0; i < dt_group.Rows.Count; i++) 
        {
            v_list.Add(double.Parse(dt_group.Rows[i][tp].ToString()));
            int r_idx = Array.IndexOf(Xdata, dt_group.Rows[i]["report_time"].ToString());
            String col = dt_group.Rows[i]["label_x"].ToString();
            dt_draw.Rows[r_idx][col] = dt_group.Rows[i][tp].ToString();
            dt_draw.Rows[r_idx][col + "_tooltip"] = dt_group.Rows[i]["tooltip"].ToString();
            dt_draw.Rows[r_idx][col + "_url"] = dt_group.Rows[i]["url"].ToString();
        }

        double[] v = v_list.ToArray();


        // 将DataTable转换成JSON
        var xData = dt_draw.AsEnumerable().Select(row => row.Field<string>("data_x")).ToList(); // 获取X轴数据

        // 生成系列数据
        var seriesData = new List<Dictionary<string, object>>();
        foreach (var column in series_name)
        {
            int index = Array.IndexOf(series_name.ToArray(), column);
            seriesData.Add(new Dictionary<string, object>
            {
                { "name", column },
                { "type", "scatter" },
                { "data", dt_draw.AsEnumerable().Select(row =>
                    row.IsNull(column) ? (double?)null : Convert.ToDouble(row[column])
                ).ToList() },
                { "tooltip", dt_draw.AsEnumerable().Select(row => row[column+"_tooltip"]).ToList() },
                { "url", dt_draw.AsEnumerable().Select(row => row[column+"_url"]).ToList() },
                { "itemStyle", new Dictionary<string, object>
                    {
                        { "color", ColorTranslator.ToHtml(color[index % color.Length])} //,
                        //{"borderColor", "red"},
                        //{"borderWidth", 2}

                    }
                }
            });
        }

       
        double y_USL = double.NaN;
        double y_UCL = double.NaN;
        
        try
        {
            y_USL = double.Parse(dt.Rows[0]["USL"].ToString());
        }
        catch { }
        
        try
        {
            y_UCL = double.Parse(dt.Rows[0]["UCL"].ToString());
        }
        catch { }



        double y_LSL = double.NaN;
        double y_LCL = double.NaN;

        try
        {
            y_LSL = double.Parse(dt.Rows[0]["LSL"].ToString());
        }
        catch { }
        try
        {
            y_LCL = double.Parse(dt.Rows[0]["LCL"].ToString());
        }
        catch { }

        double v_max = v.Max();
        double v_min = v.Min();

        double y_upper = double.NaN;
        double y_lower = double.NaN;
        if (spec)
        {
            y_upper = Math.Max(v_max, y_USL);
            if (double.IsNaN(y_upper))
                y_upper = Math.Max(v_max, y_UCL);
            if (double.IsNaN(y_upper))
                y_upper = v_max;

            y_lower = Math.Min(v_min, y_LSL);
            if (double.IsNaN(y_lower))
                y_lower = Math.Min(v_min, y_LCL);
            if (double.IsNaN(y_upper))
                y_lower = v_min;
        }
        y_upper += (y_upper - y_lower) * 0.2;
        y_lower -= (y_upper - y_lower) * 0.2;
        y_upper = double.Parse(y_upper.ToString("0.000"));
        y_lower = double.Parse(y_lower.ToString("0.000"));


        String chartid = Guid.NewGuid().ToString();

        String title = item + " " + tp.Replace("value_", "").ToUpper();
        if (eqp != "")
            title = eqp + " " + title;

        var jsonData = new
        {
            titlestr = title,
            chartid = chartid,
            legends = series_name,
            xData = xData,
            series = seriesData,
            usl = y_USL,
            ucl = y_UCL,
            lsl = y_LSL,
            lcl = y_LCL,
            upper = y_upper,
            lower = y_lower

        };


        //plcHolder.Controls.Add(addlabel("<div id=\"" + chartid + "\" style=\"width: 600px; height: 450px;\"></div>"));

        control_result += "<td><div id=\"" + chartid + "\" style=\"width: 600px; height: 450px;\"></div>" + "</td>";

        ClientScript.RegisterStartupScript(this.GetType(), "updateChart_" + chartid, "showChart('" + JsonConvert.SerializeObject(jsonData) + "');", true);


        //boxplot
        DataTable dt_group_boxplot = new DataTable();
        dt_group_boxplot.Columns.Add("report_time", typeof(string));
        dt_group_boxplot.Columns.Add("series", typeof(string));
        dt_group_boxplot.Columns.Add("value_str", typeof(string));

        if (rb_query_type.SelectedValue != "Sheet")
        {
            var result = from row in dt.AsEnumerable()
                         group row by new
                         {
                             report_time = row.Field<string>("report_time"),
                             label_x = row.Field<string>("label_x")

                         } into g
                         select new
                         {
                             report_time = g.Key.report_time,
                             label_x = g.Key.label_x,
                             value = ComputeAverage(g.Select(r => r.Field<string>("rawdata")))
                         };

            // 創建一個新的 DataTable
            foreach (var it in result)
            {
                dt_group_boxplot.Rows.Add(it.report_time, it.label_x, it.value);
            }
        }
        else
        {
            foreach (DataRow r in dt.Rows)
                dt_group_boxplot.Rows.Add(r["report_time"].ToString(), r["label_x"].ToString(), r["rawdata"].ToString());
        }

        var boxPlotData = GenerateBoxPlotData(dt_group_boxplot);
        var xAxisData = boxPlotData.Select(x => x.ReportTime).Distinct().ToList(); // 获取唯一的时间点
        var legends = boxPlotData.Select(x => x.Series).Distinct().OrderBy(series => series).ToList(); // 获取唯一的图例
        var seriesData_boxplot = new List<object>();
        int colorCount = color.Length;
        foreach (var legend in legends)
        {
            var seriesBoxPlot = xAxisData.Select(time => {
                var boxItem = boxPlotData.FirstOrDefault(x => x.Series == legend && x.ReportTime == time);

                if (boxItem != null)
                    return boxItem.BoxPlotValues;
                else
                    return new double[] { };
            }).ToArray();

            var seriesEntry = new
            {
                name = legend,
                type = "boxplot",
                data = seriesBoxPlot.Length > 0 ? seriesBoxPlot.ToArray() : new object[] { },
                itemStyle = new
                {
                    color = ColorTranslator.ToHtml(color[legends.IndexOf(legend) % colorCount])
                }
            };
            seriesData_boxplot.Add(seriesEntry);
        }

        chartid = Guid.NewGuid().ToString();
        var jsonData_boxplot = new
        {
            chartid = chartid,
            seriesData = seriesData_boxplot,
            legends = legends,
            xAxisData = xAxisData,
            titlestr = title,
            usl = y_USL,
            ucl = y_UCL,
            lsl = y_LSL,
            lcl = y_LCL,
            upper = y_upper,
            lower = y_lower
        };

        control_result += "<td><div id=\"" + chartid + "\" style=\"width: 600px; height: 450px;\"></div>" + "</td>";
        control_result += "</tr></table>";

        plcHolder.Controls.Add(addlabel(control_result));
        ClientScript.RegisterStartupScript(this.GetType(), "updateChart_" + chartid, "showBoxplot('" + JsonConvert.SerializeObject(jsonData_boxplot) + "');", true);



    }

    static string ComputeAverage(IEnumerable<string> values)
    {
        // 假設每個值都是以','分隔的浮點數字串
        var numbers = new List<List<double>>();

        foreach (var value in values)
        {
            var nums = value.Split(',').Select(double.Parse).ToList();
            numbers.Add(nums);
        }

        int count = numbers[0].Count;
        int bypass = 0;
        var sums = new double[count];

        // 累計每一列的總和
        foreach (var number in numbers)
        {
            if (number.Count != count)
            {
                bypass += 1;
                continue;
            }

            for (int i = 0; i < count; i++)
                sums[i] += number[i];
        }

        /*
        for (int i = 0; i < count; i++)
        {
            foreach (var number in numbers)
            {
                sums[i] += number[i];
            }
        }
        */

        // 計算平均值
        var averages = sums.Select(s => s / (numbers.Count - bypass)).ToArray();

        // 以','分隔返回
        return string.Join(",", averages);
    }

    public Label addlabel(String t)
    {
        Label lb = new Label();
        lb.Text = t;
        return lb;
    }

    public DataTable get_mysql_data(String sql)
    {
        DataTable DT = new DataTable();

        try
        {
            MySqlConnection conn = new MySqlConnection(connString);
            conn.Open();
            MySqlDataAdapter DA = new MySqlDataAdapter(sql, conn);
            DA.Fill(DT);
            conn.Close();
        }
        catch(Exception e)
        {
            Response.Write(e.Message);
            DT = new DataTable();
        }
        return DT;

    }


    protected void bt_query_Click(object sender, EventArgs e)
    {
        getdata();
    }

    protected void bt_rawdata_Click(object sender, EventArgs e)
    {
        String sql = "";
        sql += " select ";
        sql += " DATE_FORMAT(a.report_time,'%Y/%m/%d %H:%i:%s') as report_time, a.chart_id, a.item_type, a.product_code, kpc.line_id, kpc.tool_id, a.layer, a.sheet_id, a.spc_spec_ver, a.user_spec_ver, value_max, value_min, value_avg, value_std, ";
        sql += " bm.logoff_time as bm_logoff_time, ifnull(concat(bm.line_id, ''),'Nan') as bm_line_id, bm.tool_id as bm_tool_id,bm.unit_id as bm_unit_id, ";
        sql += " r.logoff_time as r_logoff_time, ifnull(concat(r.line_id, ''), 'Nan') as r_line_id, r.tool_id as r_tool_id,r.unit_id as r_unit_id, ";
        sql += " g.logoff_time as g_logoff_time, ifnull(concat(g.line_id, ''), 'Nan') as g_line_id, g.tool_id as g_tool_id,g.unit_id as g_unit_id, ";
        sql += " b.logoff_time as b_logoff_time, ifnull(concat(b.line_id, ''), 'Nan') as b_line_id, b.tool_id as b_tool_id,b.unit_id as b_unit_id, ";
        sql += " ps.logoff_time as ps_logoff_time, ifnull(concat(ps.line_id, ''), 'Nan') as ps_line_id, ps.tool_id as ps_tool_id,ps.unit_id as ps_unit_id, ";
        sql += " oc.logoff_time as oc_logoff_time, ifnull(concat(oc.line_id, ''), 'Nan') as oc_line_id, oc.tool_id as oc_tool_id,oc.unit_id as oc_unit_id, ";
        sql += " ito.logoff_time as ito_logoff_time, ifnull(concat(ito.line_id, ''), 'Nan') as ito_line_id, ito.tool_id as ito_tool_id,ito.unit_id as ito_unit_id ";
        if (cb_spec.Checked)
        {
            sql += ", spectype.spec_valuetype, ";
            sql += " spec.spec_type, ";
            sql += " spec.spec_ver, ";
            sql += " spec.usl, ";
            sql += " spec.ucl, ";
            sql += " spec.cl, ";
            sql += " spec.lcl, ";
            sql += " spec.lsl ";
        }
        sql += " from ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.spc_data ";
        sql += " 	where 1=1 ";
        sql += " 	and report_time >= '" + tb_starttime.Text + " 07:30:00' ";
        sql += " 	and report_time <= '" + DateTime.Parse(tb_endtime.Text).AddDays(1).ToString("yyyy/MM/dd 07:30:00") + "' ";
        sql += " 	and layer = '" + list_layer.SelectedValue + "' ";

        String prd = "";
        for (int i = 0; i < list_product.Items.Count; i++)
        {
            if (list_product.Items[i].Selected)
                prd += "'" + list_product.Items[i].Text + "',";
        }
        prd = prd.Trim(',');
        if (prd != "") 
            sql += " 	and chart_id_product in (" + prd + ") ";


        if (list_chart.SelectedValue != "ALL")
            sql += " and item_type = '" + list_chart.SelectedValue + "' ";

        sql += " ) a ";

        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += " ) kpc ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = kpc.glass_id ";
        sql += " and a.layer = kpc.op ";
        sql += " and a.report_time > kpc.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'BM' ";
        sql += " ) bm ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = bm.glass_id ";
        sql += " and a.report_time > bm.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'R' ";
        sql += " ) r ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = r.glass_id ";
        sql += " and a.report_time > r.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'G' ";
        sql += " ) g ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = g.glass_id ";
        sql += " and a.report_time > g.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'B' ";
        sql += " ) b ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = b.glass_id ";
        sql += " and a.report_time > b.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'PS' ";
        sql += " ) ps ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = ps.glass_id ";
        sql += " and a.report_time > ps.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'OC' ";
        sql += " ) oc ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = oc.glass_id ";
        sql += " and a.report_time > oc.logoff_time ";
        sql += " left join ";
        sql += " ( ";
        sql += " 	SELECT * FROM l7bcf_spc.kpc_data ";
        sql += "     where op = 'ITO' ";
        sql += " ) ito ";
        sql += " on 1=1 ";
        sql += " and a.sheet_id = ito.glass_id ";
        sql += " and a.report_time > ito.logoff_time ";

        if (cb_spec.Checked)
        {
            sql += " left join ";
            sql += " (  ";
            sql += " select 'AVG' as spec_valuetype union select 'MAX' union select 'MIN'  ";
            sql += " ) spectype ";
            sql += " on 1=1 ";
            sql += " left join ";
            sql += " ( ";
            sql += " select  ";
            sql += "     `chart_id`,  ";
            sql += "     case when user_spec_ver <> 0 then 'user' else 'spc' end as `spec_type`, ";
            sql += "     case when user_spec_ver <> 0 then user_spec_ver else spc_spec_ver end as `spec_ver`, ";
            sql += "     spec_valuetype, ";
            sql += "     usl,ucl,cl,lcl,lsl ";
            sql += "     from ";
            sql += "     ( ";
            sql += "         SELECT ";
            sql += "         ROW_NUMBER() OVER ( PARTITION BY chart_id, spec_valuetype   ";
            sql += "                       ORDER BY   ";
            sql += "                         user_spec_ver DESC, spc_spec_ver DESC ";
            sql += "                         ) as rn ";
            sql += "          , t.* ";
            sql += "          FROM l7bcf_spc.spc_spec t ";
            sql += "     ) t ";
            sql += "     where t.rn = 1 ";
            sql += " )  spec ";
            sql += " on a.chart_id = spec.chart_id and spectype.spec_valuetype = spec.spec_valuetype ";
        }
        //Response.Write(sql);

        DataTable dt = get_mysql_data(sql);
        ExportDataTable(dt);
    }

    public void ExportDataTable(DataTable dt, String fil_name = "CF_SPC_Data")
    {

        //DataTable为要导出的数据表
        DataGrid dg = new DataGrid();
        dg.DataSource = dt;
        dg.DataBind();

        //如果文件名称有中文，指定编码
        string fileName = HttpUtility.UrlEncode(fil_name, Encoding.UTF8).ToString();


        //设置编码格式
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.Charset = "UTF-8";// "UTF-8"或者"GB2312"
        HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";//text/csv
        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.UTF8;
        HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment;filename=" + fileName + ".xls");
        //导出excel
        System.IO.StringWriter oSW = new System.IO.StringWriter();
        HtmlTextWriter oHW = new HtmlTextWriter(oSW);
        dg.RenderControl(oHW);



        //输出时加上"<meta http-equiv=\"content-type\" content=\"application/ms-excel; charset=UTF-8\"/>"解决编码问题

        //返回浏览器，
        HttpContext.Current.Response.Write("<meta http-equiv=\"content-type\" content=\"application/ms-excel; charset=UTF-8\"/>" + oSW.ToString());
        HttpContext.Current.Response.End();
    }


    protected void GridView1_RowCreated(Object sender, GridViewRowEventArgs e)
    {
        DataRowView drv = (DataRowView)e.Row.DataItem;

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            try
            {
                String report_time = drv["report_time"].ToString();
                String sheet_id = drv["sheet_id"].ToString();
                String chart_id = drv["chart_id"].ToString();


                string urlToOpen = "judge.aspx?report_time=" + report_time + "&chart_id=" + chart_id + "&sheet_id=" + sheet_id;


                String temp = "<img src=\"http://tw100040017.corpnet.auo.com/L7B/CF_INT/icon/edit.png\" class=\"clickable-image\" onclick=\"OpenWin('" + urlToOpen + "','800','750');\" />";


                ((Label)(e.Row.FindControl("g_judge"))).Text = temp;
            }
            catch { }
        }

    }


}