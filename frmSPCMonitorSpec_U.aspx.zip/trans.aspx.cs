﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class L7B_CF_SPC_trans : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 檢查URL是否包含item_type參數
        if (!String.IsNullOrEmpty(Request.QueryString["item_type"]))
        {
            String itemType = Request.QueryString["item_type"];
            String layer = Request.QueryString["layer"];
            String chart = Request.QueryString["chart"];
                
            String report_time = "";
            if (!String.IsNullOrEmpty(Request.QueryString["report_time"]))
                report_time = Request.QueryString["report_time"];

            String start_time = "";
            if (!String.IsNullOrEmpty(Request.QueryString["start_time"]))
                start_time = Request.QueryString["start_time"];
            String end_time = "";
            if (!String.IsNullOrEmpty(Request.QueryString["end_time"]))
                end_time = Request.QueryString["end_time"];

            if (report_time.Length - report_time.Replace("/", "").Length == 1)
            {
                start_time = DateTime.Now.ToString("yyyy/") + report_time;
                end_time = DateTime.Now.ToString("yyyy/") + report_time;
            }
            else if (report_time.Contains("W"))
            {
                string weekString = report_time; // 假設是第 39 週
                int year = int.Parse(DateTime.Now.ToString("yyyy")); // 你需要提供的年份
                int weekNumber = int.Parse(weekString.Substring(2)); // 提取週數

                // 計算開始日期
                var jan1 = new DateTime(year, 1, 1);
                var firstDayOfWeek = jan1.AddDays(-(int)jan1.DayOfWeek + (int)DayOfWeek.Monday); // 獲得該年第一個星期一的日期

                var startDate = firstDayOfWeek.AddDays((weekNumber - 1) * 7); // 計算第 N 周的開始日期
                var endDate = startDate.AddDays(6); // 結束日期是開始日期加 6 天
                start_time = DateTime.Parse(startDate.ToString()).ToString("yyyy/MM/dd");
                end_time = DateTime.Parse(endDate.ToString()).ToString("yyyy/MM/dd");
            }

            String sheet_id = "";
            if (!String.IsNullOrEmpty(Request.QueryString["sheet_id"]))
                sheet_id = Request.QueryString["sheet_id"];

            String arg = "?chart=" + chart + "&layer=" + layer + "&report_time=" + report_time + "&sheet_id=" + sheet_id + "&item_type=" + itemType;
            if (start_time != "")
                arg = "?chart=" + chart + "&layer=" + layer + "&start_time=" + start_time + "&end_time=" + end_time + "&item_type=" + itemType;


            String redirectUrl = "";
            if (itemType.ToUpper().Contains("OL"))
                redirectUrl = "OL_main.aspx";
            else if (itemType.ToUpper().Contains("TP"))
                redirectUrl = "CF_TTP_main.aspx";
            else if (itemType.ToUpper().Contains("THK"))
                redirectUrl = "CF_THK.aspx";
            else if (itemType.ToUpper().Contains("CD"))
                redirectUrl = "CD_main.aspx";
            else if ((itemType.ToUpper().Contains("PSH")) || (itemType.ToUpper().Contains("DX_"))|| (itemType.ToUpper().Contains("DY_")))
                redirectUrl = "CF_PSH.aspx";


            
            if (redirectUrl != "")
                Response.Redirect("http://tw100040017.corpnet.auo.com/L7B/CF_MQC/" + redirectUrl + arg, true);


            //String redirectUrl = "https://www.example.com/?item_type=" + itemType;
            //Response.Redirect(redirectUrl, true);
        }
    }
}