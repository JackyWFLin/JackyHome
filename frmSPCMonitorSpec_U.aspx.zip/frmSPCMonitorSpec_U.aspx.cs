﻿//+@20160829 加上雙邊條件(裕民)
//+@20170221 product code 預設改為 T550QVR10；增加X參數 (裕民)
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
//================================
using MySql.Data.MySqlClient;
using System.Web.Configuration;
using System.Globalization;
using System.Collections.Generic; 

public partial class ENG_frmSPCMonitorSpec_Q : System.Web.UI.Page
{
    String[] layer_ = { "BM", "R", "G", "B", "PS", "ITO", "OC"};
    static String connString = "Database=l7bcf_spc;Data Source=tw100043811;Port=3307;User Id=l7b_commit;Password=l7b$commit;CharSet=utf8;SslMode=None;allowPublicKeyRetrieval=true";
    String[] admin_user = {"1907167", "1006100", "1007361", "1202422", "1210063", "2112055", "0527063", "1008499" };

    protected void Page_Load(object sender, EventArgs e)
    {

        if ((Session["Logined"] == null) || (Session["Logined"].ToString() != "1"))
        {
            String S_Url = HttpUtility.UrlEncode(Request.Url.AbsoluteUri);

            Response.Redirect("http://tw100040017.corpnet.auo.com/L7B/User_Login/Login_7B.aspx?url=" + S_Url);
        }

        if (!IsPostBack)
        {
            if (Array.IndexOf(admin_user, Session["UserID"]) >= 0)
            {
                btnSave.Visible = true;
                gvSpec.Columns[0].Visible = true;
            }
            else
            {
                btnSave.Visible = false;
                gvSpec.Columns[0].Visible = false;
            }
            GetModelToDrp();
            GetLayerToDrp();
            GetitemToDrp();

            //+@20170221 預設改為 T550QVR10
            //drpQModel.SelectedIndex = drpQModel.Items.IndexOf(drpQModel.Items.FindByText("POA-T550QVR10"));

            //+@20131225
            //lnkbShowTHKSpec.OnClientClick = "var w=window.open('frmTHKSpec_U.aspx','_blank','resizable=yes,width=825,height=900,scrollbars=yes');w.location.reload();w.focus();";

            lblMsg.Text = "";
            BindGvSpec(false);
            divGv.Visible = true;
        }
    }


    private void GetLayerToDrp()
    {
        drpQLayer.Items.Clear();
        drpQLayer.Items.Add("ALL");
        foreach (String l in layer_)
            drpQLayer.Items.Add(l);
    }


    /// <summary>
    /// 
    /// </summary>
    private void GetModelToDrp()
    {
        string strSQL = @" SELECT distinct substring_index(chart_id,'/',1) as model FROM l7bcf_spc.spc_spec
                         order by chart_id ";



        DataTable dt = get_mysql_data(strSQL);

        drpQModel.Items.Clear();
        drpQModel.Items.Add("ALL");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            drpQModel.Items.Add(dt.Rows[i][0].ToString());
        }
    }


    private void GetitemToDrp()
    {
        string strSQL = @" SELECT distinct item_type FROM l7bcf_spc.spc_spec
                         order by item_type ";



        DataTable dt = get_mysql_data(strSQL);

        drpItem.Items.Clear();
        drpItem.Items.Add("ALL");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            drpItem.Items.Add(dt.Rows[i][0].ToString());
        }
    }
    public DataTable get_mysql_data(String sql)
    {
        DataTable DT = new DataTable();
        try
        {
            MySqlConnection conn = new MySqlConnection(connString);
            conn.Open();
            MySqlDataAdapter DA = new MySqlDataAdapter(sql, conn);
            DA.Fill(DT);
            conn.Close();
        }
        catch (Exception e)
        {
            Response.Write(e.Message);
            DT = new DataTable();
        }
        return DT;

    }


    private void BindGvSpec(Boolean button = false)
    {
        String sql = "";
        sql += " select * from ( ";
        sql += " select ";
        sql += " replace(replace(replace(substring_index(substring_index(spcspec.chart_id,'/',2),'/',-1),'10',''),'20',''),'30','') as layer, ";
        
        sql += " case when userspec.chart_id is null then spcspec.item_type else userspec.item_type end as item_type, ";
        sql += " case when userspec.chart_id is null then spcspec.chart_id else userspec.chart_id end as chart_id, ";
        sql += " case when userspec.chart_id is null then spcspec.line_id else userspec.line_id end as line_id, ";
        sql += " case when userspec.chart_id is null then spcspec.meas_point else userspec.meas_point end as meas_point, ";
        sql += " case when userspec.chart_id is null then spcspec.spec_valuetype else userspec.spec_valuetype end as spec_valuetype, ";
        sql += " case when userspec.chart_id is null then spcspec.LSL else userspec.LSL end as LSL, ";
        sql += " case when userspec.chart_id is null then spcspec.LCL else userspec.LCL end as LCL, ";
        sql += " case when userspec.chart_id is null then spcspec.CL else userspec.CL end as CL, ";
        sql += " case when userspec.chart_id is null then spcspec.UCL else userspec.UCL end as UCL, ";
        sql += " case when userspec.chart_id is null then spcspec.USL else userspec.USL end as USL, ";
        sql += " case when userspec.chart_id is null then spcspec.auto_block else userspec.auto_block end as auto_block, ";
        sql += " case when userspec.chart_id is null then spcspec.block_tool else userspec.block_tool end as block_tool, ";
        sql += " case when userspec.chart_id is null then 'spc' else 'user' end as `spec_type`,  ";
        sql += " case when userspec.chart_id is null then 0 else userspec.user_spec_ver end as `spec_ver`, ";
        sql += " case when userspec.chart_id is null then spcspec.view_chart else userspec.view_chart end as `view_chart`, ";
        sql += " case when userspec.chart_id is null then 'sys' else userspec.update_man end as `update_man`, ";
        sql += " case when userspec.chart_id is null then DATE_FORMAT(spcspec.update_time, '%Y/%m/%d %H:%i:%s') else DATE_FORMAT(userspec.update_time, '%Y/%m/%d %H:%i:%s') end as `update_time`, ";
        sql += " case when userspec.chart_id is null then spcspec.chip_info else userspec.chip_info end as `chip_info` ";
        sql += " from ";
        sql += " ( ";
        sql += "     select * from ";
        sql += "     ( ";
        sql += "     SELECT ROW_NUMBER() OVER ( PARTITION BY chart_id ORDER BY spc_spec_ver DESC ) as rn , t.*  ";
        sql += "     FROM l7bcf_spc.spc_spec t  ";
        sql += "     where user_spec_ver = 0 ";
        sql += "     ) t ";
        sql += "     where t.rn = 1 ";
        sql += " ) spcspec ";
        sql += " left join ";
        sql += " ( ";
        sql += "     select * from  ";
        sql += "     (  ";
        sql += "         SELECT ROW_NUMBER() OVER ( PARTITION BY chart_id, spec_valuetype, line_id ORDER by user_spec_ver DESC ) as rn , t.*  ";
        sql += "         FROM l7bcf_spc.spc_spec t  ";
        sql += "         where spc_spec_ver = 0 ";
        sql += "     ) t ";
        sql += "     where t.rn = 1 ";
        sql += " ) userspec ";
        sql += " on spcspec.chart_id = userspec.chart_id ";
        sql += " ) t ";
        sql += " where 1=1 ";
        if (button)
        {
            if (drpQLayer.SelectedItem.Text != "ALL")
                sql += " and replace(replace(replace(substring_index(substring_index(chart_id,'/',2),'/',-1),'10',''),'20',''),'30','') = '" + drpQLayer.SelectedItem.Text + "' ";
            if (drpQModel.SelectedItem.Text != "ALL")
                sql += " and substring_index(chart_id,'/',1) = '" + drpQModel.SelectedItem.Text + "' ";
            if (drpItem.SelectedItem.Text != "ALL")
            {
                sql += " and ( item_type = '" + drpItem.SelectedItem.Text + "' ";
                sql += " or substring_index(chart_id,'/',-1) like '%" + drpItem.SelectedItem.Text + "%') ";
            }
        }
        else
        {
            if (String.IsNullOrEmpty(Request.QueryString["chart_id"]))
            {

                if (drpQLayer.SelectedItem.Text != "ALL")
                    sql += " and replace(replace(replace(substring_index(substring_index(chart_id,'/',2),'/',-1),'10',''),'20',''),'30','') = '" + drpQLayer.SelectedItem.Text + "' ";
                if (drpQModel.SelectedItem.Text != "ALL")
                    sql += " and substring_index(chart_id,'/',1) = '" + drpQModel.SelectedItem.Text + "' ";
                if (drpItem.SelectedItem.Text != "ALL")
                    sql += " and item_type = '" + drpItem.SelectedItem.Text + "' ";
            }
            else
            {
                sql += " and replace(replace(replace(substring_index(substring_index(chart_id,'/',2),'/',-1),'10',''),'20',''),'30','') = '" + Request.QueryString["layer"] + "' ";
                sql += " and chart_id = '" + Request.QueryString["chart_id"] + "' ";
                sql += " and line_id = '" + Request.QueryString["line_id"] + "' ";

            }
        }
        if (cb_view.Checked) 
            sql += " and view_chart='Y' ";
        sql += " order by substring_index(substring_index(chart_id,'/',2),'/',-1), item_type,chart_id ";
        //Response.Write(sql);
        DataTable dt = get_mysql_data(sql);
        gvSpec.DataSource = dt;
        gvSpec.DataBind();
    }

   


    protected void btnSave_Click(object sender, EventArgs e)
    {
        Boolean real = saveData_Real();
        
        if (real)
        {
            Boolean hist = saveData_Hist();
            if (hist)
            {
                Response.Write("<script language='javascript'>alert('Edit is successful.');</script>");
                btnQuery_Click(null, null);
                return;
            }
        }
        Response.Write("<script language='javascript'>alert('Edit is fail.');</script>");

    }

    public Boolean saveData_Real()
    {
        //組SQL語法
        string username = Session["uac_name"].ToString();
        //string username = "test";


        String sql = "";
        sql += @" replace INTO `l7bcf_spc`.`spc_spec_real`
                  (`line_id`,`chart_id`,`userspec`,`spec_valuetype`,
                  `USL`,`UCL`,`CL`,`LCL`,`LSL`,`meas_point`,`item_type`,`auto_block`,`block_tool`,`view_chart`,`update_man`,`chip_info`) VALUES ";

        Boolean writein = false;
        for (int i = 0; i < gvSpec.Rows.Count; i++)
        {
            GridViewRow gvRow = gvSpec.Rows[i];
            String Layer = ((Label)gvRow.FindControl("lblLayer")).Text;

            String Line = ((TextBox)gvRow.FindControl("tb_Line")).Text;
            String Line_old = ((Label)gvRow.FindControl("lblLine")).Text;

            String ChartID = ((Label)gvRow.FindControl("lblChartID")).Text;
            String meas_point = ((Label)gvRow.FindControl("lblmeas_point")).Text;
            String user_spec_ver = (int.Parse(((Label)gvRow.FindControl("lbluser_spec_ver")).Text) + 1).ToString();


            String item_type_old = ((Label)gvRow.FindControl("lblitem_type")).Text;
            String item_type = ((TextBox)gvRow.FindControl("tb_item_type")).Text;

            String spec_valuetype_old = ((Label)gvRow.FindControl("lblvalue_type")).Text;
            String spec_valuetype = ((RadioButtonList)gvRow.FindControl("rb_value_type")).SelectedValue;

            String LSL_old = ((Label)gvRow.FindControl("lbLSL")).Text;
            String LSL = ((TextBox)gvRow.FindControl("txtLSL")).Text;

            String LCL_old = ((Label)gvRow.FindControl("lbLCL")).Text;
            String LCL = ((TextBox)gvRow.FindControl("txtLCL")).Text;

            String CL_old = ((Label)gvRow.FindControl("lbCL")).Text;
            String CL = ((TextBox)gvRow.FindControl("txtCL")).Text;

            String UCL_old = ((Label)gvRow.FindControl("lbUCL")).Text;
            String UCL = ((TextBox)gvRow.FindControl("txtUCL")).Text;

            String USL_old = ((Label)gvRow.FindControl("lbUSL")).Text;
            String USL = ((TextBox)gvRow.FindControl("txtUSL")).Text;


            String autoblock_old = ((Label)gvRow.FindControl("lblautoblock")).Text;
            String autoblock = "N";
            String blocktool_old = ((Label)gvRow.FindControl("lb_blocktool")).Text;
            String blocktool = "";

            String view_old = ((Label)gvRow.FindControl("lblviewchart")).Text;
            String view = "N";

            if (((CheckBox)gvRow.FindControl("cb_auto_block")).Checked)
            {
                autoblock = "Y";
                blocktool = ((TextBox)gvRow.FindControl("tb_blocktool")).Text;
            }
            if (((CheckBox)gvRow.FindControl("cb_view")).Checked)
            {
                view = "Y";

            }

            String chip_info_old = ((Label)gvRow.FindControl("lb_chip_info")).Text;
            String chip_info = ((TextBox)gvRow.FindControl("tb_chip_info")).Text;
            if ((chip_info != "") && (chip_info.Length - chip_info.Replace(",", "").Length + 1 != int.Parse(meas_point))) 
            {
                Response.Write("<script language='javascript'>alert('chip資訊數量與量測點數不符!');</script>");
                return false;
            }


            if (
                Line_old == Line && spec_valuetype_old == spec_valuetype
                && LSL_old == LSL && LCL_old == LCL && CL_old == CL && UCL_old == UCL && USL_old == USL
                && autoblock_old == autoblock && autoblock_old == autoblock && autoblock_old == autoblock && view_old == view
                && item_type_old == item_type
                && chip_info_old == chip_info
                )
                continue;
            sql += " ( ";
            sql += " '" + Line.ToUpper() + "',";
            sql += " '" + ChartID + "',";
            sql += " 'Y',";
            sql += " '" + spec_valuetype + "',";
            if (USL == "")
                sql += "null,";
            else
                sql += " '" + USL + "',";
            if (UCL == "")
                sql += "null,";
            else
                sql += " '" + UCL + "',";
            if (CL == "")
                sql += "null,";
            else
                sql += " '" + CL + "',";
            if (LCL == "")
                sql += "null,";
            else
                sql += " '" + LCL + "',";
            if (LSL == "")
                sql += "null,";
            else
                sql += " '" + LSL + "',";
            sql += " '" + meas_point + "',";
            sql += " '" + item_type + "',";
            sql += " '" + autoblock + "',";

            if (blocktool == "")
                sql += "null,";
            else
                sql += " '" + blocktool.ToUpper() + "',";
            sql += " '" + view + "',";
            sql += " '" + username + "',";
            sql += " '" + chip_info + "' ";
            sql += " ),";
            writein = true;


        }

        if (!writein)
            return false;

        int ee = 0;
        try
        {
            //Response.Write(sql.Trim(','));
            MySqlConnection conn = new MySqlConnection(connString);
            MySqlCommand cmd = new MySqlCommand(sql.Trim(','), conn);
            conn.Open();
            ee = cmd.ExecuteNonQuery();
            conn.Close();

        }
        catch (Exception ex)
        {
            ee = -1;
        }
        
        if ((ee >= 0) || (ee == -100))
        {
            return true;
        }
        else
        {
            return false;
        }
    }


    public Boolean saveData_Hist()
    {
        //組SQL語法
        string username = Session["uac_name"].ToString();
        //string username = "test";


        String sql = "";
        sql += @" replace INTO `l7bcf_spc`.`spc_spec`
                  (`line_id`,`chart_id`,`spc_spec_ver`,`user_spec_ver`,`spec_valuetype`,
                  `USL`,`UCL`,`CL`,`LCL`,`LSL`,`meas_point`,`item_type`,`auto_block`,`block_tool`,`view_chart`,`update_man`,`chip_info`) VALUES ";


        for (int i = 0; i < gvSpec.Rows.Count; i++)
        {
            GridViewRow gvRow = gvSpec.Rows[i];
            String Layer = ((Label)gvRow.FindControl("lblLayer")).Text;

            String Line = ((TextBox)gvRow.FindControl("tb_Line")).Text;
            String Line_old = ((Label)gvRow.FindControl("lblLine")).Text;

            String ChartID = ((Label)gvRow.FindControl("lblChartID")).Text;
            String meas_point = ((Label)gvRow.FindControl("lblmeas_point")).Text;
            String user_spec_ver = (int.Parse(((Label)gvRow.FindControl("lbluser_spec_ver")).Text) + 1).ToString();


            String item_type_old = ((Label)gvRow.FindControl("lblitem_type")).Text;
            String item_type = ((TextBox)gvRow.FindControl("tb_item_type")).Text;

            String spec_valuetype_old = ((Label)gvRow.FindControl("lblvalue_type")).Text;
            String spec_valuetype = ((RadioButtonList)gvRow.FindControl("rb_value_type")).SelectedValue;

            String LSL_old = ((Label)gvRow.FindControl("lbLSL")).Text;
            String LSL = ((TextBox)gvRow.FindControl("txtLSL")).Text;

            String LCL_old = ((Label)gvRow.FindControl("lbLCL")).Text;
            String LCL = ((TextBox)gvRow.FindControl("txtLCL")).Text;

            String CL_old = ((Label)gvRow.FindControl("lbCL")).Text;
            String CL = ((TextBox)gvRow.FindControl("txtCL")).Text;

            String UCL_old = ((Label)gvRow.FindControl("lbUCL")).Text;
            String UCL = ((TextBox)gvRow.FindControl("txtUCL")).Text;

            String USL_old = ((Label)gvRow.FindControl("lbUSL")).Text;
            String USL = ((TextBox)gvRow.FindControl("txtUSL")).Text;


            String autoblock_old = ((Label)gvRow.FindControl("lblautoblock")).Text;
            String autoblock = "N";
            String blocktool_old = ((Label)gvRow.FindControl("lb_blocktool")).Text;
            String blocktool = "";

            String view_old = ((Label)gvRow.FindControl("lblviewchart")).Text;
            String view = "N";

            if (((CheckBox)gvRow.FindControl("cb_auto_block")).Checked)
            {
                autoblock = "Y";
                blocktool = ((TextBox)gvRow.FindControl("tb_blocktool")).Text;
            }
            if (((CheckBox)gvRow.FindControl("cb_view")).Checked)
            {
                view = "Y";

            }

            String chip_info_old = ((Label)gvRow.FindControl("lb_chip_info")).Text;
            String chip_info = ((TextBox)gvRow.FindControl("tb_chip_info")).Text;

            if (
                Line_old == Line && spec_valuetype_old == spec_valuetype
                && LSL_old == LSL && LCL_old == LCL && CL_old == CL && UCL_old == UCL && USL_old == USL
                && autoblock_old == autoblock && autoblock_old == autoblock && autoblock_old == autoblock && view_old == view
                && item_type_old == item_type
                && chip_info_old == chip_info
                )
                continue;
            sql += " ( ";
            sql += " '" + Line.ToUpper() + "',";
            sql += " '" + ChartID + "',";
            sql += " '0',";
            sql += " '" + user_spec_ver + "',";
            sql += " '" + spec_valuetype + "',";
            if (USL == "")
                sql += "null,";
            else
                sql += " '" + USL + "',";
            if (UCL == "")
                sql += "null,";
            else
                sql += " '" + UCL + "',";
            if (CL == "")
                sql += "null,";
            else
                sql += " '" + CL + "',";
            if (LCL == "")
                sql += "null,";
            else
                sql += " '" + LCL + "',";
            if (LSL == "")
                sql += "null,";
            else
                sql += " '" + LSL + "',";
            sql += " '" + meas_point + "',";
            sql += " '" + item_type + "',";
            sql += " '" + autoblock + "',";

            if (blocktool == "")
                sql += "null,";
            else
                sql += " '" + blocktool.ToUpper() + "',";
            sql += " '" + view + "',";
            sql += " '" + username + "',";
            sql += " '" + chip_info + "' ";
            sql += " ),";



        }

        int ee = 0;
        MySqlConnection conn = new MySqlConnection(connString);
        MySqlCommand cmd = new MySqlCommand(sql.Trim(','), conn);
        conn.Open();
        ee = cmd.ExecuteNonQuery();
        conn.Close();

        /*
        try
        {
            //Response.Write(sql.Trim(','));
            MySqlConnection conn = new MySqlConnection(connString);
            MySqlCommand cmd = new MySqlCommand(sql.Trim(','), conn);
            conn.Open();
            ee = cmd.ExecuteNonQuery();
            conn.Close();

        }
        catch (Exception ex)
        {
            ee = -1;
        }
        */
        if ((ee >= 0) || (ee == -100))
        {
            return true;
        }
        else
        {
            return false;
        }
    }


    public Boolean delete_data(int idx)
    {


        String sql = "";
        sql += " delete from l7bcf_spc.spc_spec where 1=1 ";
        sql += " and chart_id = '" + ((Label)(gvSpec.Rows[idx].FindControl("lblChartID"))).Text + "' ";
        sql += " and line_id = '" + ((Label)(gvSpec.Rows[idx].FindControl("lblLine"))).Text + "' ";
        sql += " and spec_valuetype = '"+ ((Label)(gvSpec.Rows[idx].FindControl("lblvalue_type"))).Text + "' ";
        sql += " and user_spec_ver = '"+ ((Label)(gvSpec.Rows[idx].FindControl("lbluser_spec_ver"))).Text + "' ";



        //Response.Write(sql);
        int e = 0;
        try
        {
            MySqlConnection conn = new MySqlConnection(connString);
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            conn.Open();
            e = cmd.ExecuteNonQuery();
            conn.Close();
        }
        catch (Exception ex)
        {
            e = -1;
        }

        if ((e >= 0) || (e == -100))
        {
            Response.Write("<script language='javascript'>alert('Edit is successful.');</script>");
            return true;
        }
        else
        {
            Response.Write("<script language='javascript'>alert('Edit is fail.');</script>");
            return false;
        }

    }

    protected void GridView1_RowCreated(Object sender, GridViewRowEventArgs e)
    {

        DataRowView drv = (DataRowView)e.Row.DataItem;

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (((Label)(e.Row.FindControl("lblautoblock"))).Text == "Y")
            {
                ((CheckBox)(e.Row.FindControl("cb_auto_block"))).Checked = true;
            }
            else
            {
                ((CheckBox)(e.Row.FindControl("cb_auto_block"))).Checked = false;
            }

            if (((Label)(e.Row.FindControl("lblviewchart"))).Text == "Y")
            {
                ((CheckBox)(e.Row.FindControl("cb_view"))).Checked = true;
            }
            else
            {
                ((CheckBox)(e.Row.FindControl("cb_view"))).Checked = false;
            }
            ((RadioButtonList)(e.Row.FindControl("rb_value_type"))).SelectedIndex = ((RadioButtonList)(e.Row.FindControl("rb_value_type"))).Items.IndexOf(((RadioButtonList)(e.Row.FindControl("rb_value_type"))).Items.FindByValue(((Label)(e.Row.FindControl("lblvalue_type"))).Text));
            ((ImageButton)(e.Row.FindControl("bt_delete"))).Attributes["onclick"] = "return confirm('確定刪除資料嗎?');";
        }

    }

    protected void btnQuery_Click(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        BindGvSpec(true);
        divGv.Visible = true;
    }



    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        

        if (e.CommandName == "del_record")
        {
            int index = ((GridViewRow)((ImageButton)e.CommandSource).NamingContainer).RowIndex;
            if (delete_data(index))
            {
                btnQuery_Click(null, null);
            }
        }
        else if (e.CommandName == "spc_default")
        {
            int index = ((GridViewRow)((Button)e.CommandSource).NamingContainer).RowIndex;
            DataTable dt = getSPCdefault(((Label)(gvSpec.Rows[index].FindControl("lblChartID"))).Text);
            if (dt.Rows.Count > 0)
            {
                ((TextBox)(gvSpec.Rows[index].FindControl("txtLSL"))).Text = dt.Rows[0]["lsl"].ToString();
                ((TextBox)(gvSpec.Rows[index].FindControl("txtLCL"))).Text = dt.Rows[0]["lcl"].ToString();
                ((TextBox)(gvSpec.Rows[index].FindControl("txtCL"))).Text = dt.Rows[0]["cl"].ToString();
                ((TextBox)(gvSpec.Rows[index].FindControl("txtUCL"))).Text = dt.Rows[0]["ucl"].ToString();
                ((TextBox)(gvSpec.Rows[index].FindControl("txtUSL"))).Text = dt.Rows[0]["usl"].ToString();
            }

        }

    }
    public DataTable getSPCdefault(String chart_id)
    {
        String sql = "";
        sql += "  SELECT ";
        sql += "  usl,ucl,cl,lcl,lsl,spc_spec_ver ";
        sql += "  FROM l7bcf_spc.spc_spec t   ";
        sql += "  where user_spec_ver = 0  ";
        sql += "  and chart_id = '" + chart_id + "' ";
        sql += "  order by spc_spec_ver desc ";
        return get_mysql_data(sql);

    }
}
