﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web;
using System.Text;
using System.Data.OleDb;
using System.Drawing;

public partial class CF_SPC_Default : System.Web.UI.Page
{
    static String connString = "Database=l7bcf_spc;Data Source=tw100043811;Port=3307;User Id=l7b_commit;Password=l7b$commit;CharSet=utf8;SslMode=None;allowPublicKeyRetrieval=true";

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack) //第一次開網頁
        {
            string strDate = "";

            if (string.IsNullOrEmpty(strDate))
                strDate = DateTime.Now.AddMinutes(-450).ToString("yyyy/MM/dd");
            txtQDate.Text = strDate;
            btnQuery_Click(null, null);

        }
    }

    protected void btnQuery_Click(object sender, EventArgs e)
    {

        string strQTimeS = txtQDate.Text + " 07:30";
        string strQTimeE = DateTime.Parse(strQTimeS).AddDays(1).ToString("yyyy/MM/dd HH:mm");
        lblTimeS.Text = strQTimeS;
        lblTimeE.Text = strQTimeE;

        DataTable dt = GetSPCData(DateTime.Parse(txtQDate.Text));
        DataTable dt_specAll = GetSpecAll(DateTime.Parse(txtQDate.Text));
        DataTable dt_run = getProcModel(strQTimeS + ":00", strQTimeE + ":00");

        DataTable dt_new = new DataTable();
        DataTable dt_item = new DataTable();

        checkDT(dt, dt_run, dt_specAll, out dt_new, out dt_item);
        //GridView1.DataSource = dt_new;
        //GridView1.DataBind();

        //String[] item_list = dt_new.AsEnumerable().Select(row => row.Field<string>("item_type")).Distinct().ToArray();
        Boolean title = true;
        foreach (DataRow item_ in dt_item.Rows)
        {

            DataTable dt_temp = dt_new.Select("item_type = '" + item_["item_type"].ToString() + "' ").CopyToDataTable();
            Label l = new Label();
            l.Text = draw_table(dt_temp, item_["item_type"].ToString());
            if (l.Text == "")
                continue;

            var div = new HtmlGenericControl("div");
            div.ID = item_["item_type"].ToString();
            div.InnerText = "";
            PlaceHolder_table.Controls.Add(div);

            if (title)
            {
                List<HyperLink> links = new List<HyperLink>();
                for (int i = 0; i < dt_item.Rows.Count; i++)
                {
                    HyperLink link = new HyperLink();
                    link.Text = "☆" + dt_item.Rows[i]["item_type"].ToString() + "&nbsp;";
                    link.Font.Size = 12;
                    link.Font.Bold = true;
                    if (dt_item.Rows[i]["ng_judge"].ToString() == "0")
                        link.ForeColor = Color.Blue;
                    else
                        link.ForeColor = Color.Red;

                    link.Attributes["href"] = "#" + dt_item.Rows[i]["item_type"].ToString();
                    link.Attributes["class"] = "scroll-link";
                    links.Add(link);

                }
                int n = 0;

                foreach (HyperLink v in links.ToArray())
                {
                    n += v.Text.Length;
                    PlaceHolder_table.Controls.Add(v);
                    PlaceHolder_table.Controls.Add(addlabel("&nbsp;"));
                    if (n > 130)
                    {
                        PlaceHolder_table.Controls.Add(addlabel("<br>"));
                        n = 0;
                    }
                }
                PlaceHolder_table.Controls.Add(addlabel("<br>"));
                title = false;
            }


            
            PlaceHolder_table.Controls.Add(l);
            PlaceHolder_table.Controls.Add(addlabel("<br>"));
        }

        lblLastUpdated.Text = "資料最後更新：" + get_lastdataTime();
    }

    public void checkDT(DataTable dt, DataTable dt_run, DataTable dt_specAll, out DataTable dt_new, out DataTable dt_item)
    {
        //dt_item = null;

        dt_new = dt.Clone();

        for (int i = 0; i < dt_run.Rows.Count; i++)
        {
            String line_id = dt_run.Rows[i]["line_id"].ToString();
            String model_no = dt_run.Rows[i]["model_no"].ToString();
            String op = dt_run.Rows[i]["op"].ToString();


            String filter = "";
            filter += "line_id ='" + dt_run.Rows[i]["line_id"].ToString() + "' ";
            filter += "and layer = '" + dt_run.Rows[i]["op"].ToString() + "' ";
            filter += "and product = '" + dt_run.Rows[i]["model_no"].ToString() + "' ";

            DataRow[] dr_list = dt_specAll.Select(filter);
            for (int j = 0; j < dr_list.Length; j++)
            {
                filter = "";
                filter += "chart_id ='" + dr_list[j]["chart_id"].ToString() + "' ";
                filter += "and layer = '" + dr_list[j]["layer"].ToString() + "' ";
                filter += "and model = '" + dr_list[j]["model"].ToString() + "' ";
                filter += "and line_id = '" + dr_list[j]["line_id"].ToString() + "' ";
                filter += "and item_type = '" + dr_list[j]["item_type"].ToString() + "' ";
                filter += "and spec_valuetype = '" + dr_list[j]["spec_valuetype"].ToString() + "' ";

                DataRow[] dr_meas_list = dt.Select(filter);
                DataRow dr_insert = dr_list[j];
                if (dr_meas_list.Length > 0)
                    dr_insert = dr_meas_list[0];



                String ng_count_str = dr_insert["ng_count_str"].ToString();
                String day_str = dr_insert["day_str"].ToString();
                String hour_str = dr_insert["hour_str"].ToString();

                String[] ng_count_list = ng_count_str.Split(',');
                String[] day_list = day_str.Split(',');
                String[] hour_list = hour_str.Split(',');
                int TimeSpec = 0;
                DateTime checkTime = DateTime.Now;

                if (DateTime.Parse(dt_run.Rows[i]["min_report_time"].ToString()).ToString("HH") == "07")
                {
                    TimeSpec = 8;
                    if (dr_insert["meas_time_max"].ToString() != "")
                        checkTime = DateTime.Parse(dr_insert["meas_time_max"].ToString());
                    else
                        checkTime = DateTime.Parse(dt_run.Rows[i]["min_report_time"].ToString());
                }
                else
                {
                    dr_insert["starttime"] = dt_run.Rows[i]["min_report_time"].ToString();

                    if (dr_insert["meas_time_max"].ToString() != "")
                    {
                        TimeSpec = 8;
                        checkTime = DateTime.Parse(dr_insert["meas_time_max"].ToString());
                    }
                    else
                    {
                        TimeSpec = 4;
                        checkTime = DateTime.Parse(dt_run.Rows[i]["min_report_time"].ToString());
                    }
                }
                if (TimeSpec != 0)
                {
                    if ((DateTime.Now - checkTime).TotalHours > TimeSpec)
                        dr_insert["ng_check"] = 1;
                }
                dr_insert["ng_count_str"] = "";
                dr_insert["day_str"] = "";
                dr_insert["hour_str"] = "";

                for (int n = ng_count_list.Length - 6; n < ng_count_list.Length; n++)
                {
                    dr_insert["ng_count_str"] = dr_insert["ng_count_str"].ToString() + ng_count_list[n] + ",";
                    dr_insert["day_str"] = dr_insert["day_str"].ToString() + day_list[n] + ",";
                    dr_insert["hour_str"] = dr_insert["hour_str"].ToString() + hour_list[n] + ",";
                }

                dr_insert["ng_count_str"] = dr_insert["ng_count_str"].ToString().Trim(',');
                dr_insert["day_str"] = dr_insert["day_str"].ToString().Trim(',');
                dr_insert["hour_str"] = dr_insert["hour_str"].ToString().Trim(',');

                dt_new.ImportRow(dr_insert);


            }
        }

        //GridView1.DataSource = dt_new;
        //GridView1.DataBind();

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            String filter = "";
            filter += "chart_id ='" + dt.Rows[i]["chart_id"].ToString() + "' ";
            filter += "and layer = '" + dt.Rows[i]["layer"].ToString() + "' ";
            filter += "and model = '" + dt.Rows[i]["model"].ToString() + "' ";
            filter += "and line_id = '" + dt.Rows[i]["line_id"].ToString() + "' ";
            filter += "and item_type = '" + dt.Rows[i]["item_type"].ToString() + "' ";
            filter += "and spec_valuetype = '" + dt.Rows[i]["spec_valuetype"].ToString() + "' ";

            String ng_count_str = dt.Rows[i]["ng_count_str"].ToString();
            String day_str = dt.Rows[i]["day_str"].ToString();
            String hour_str = dt.Rows[i]["hour_str"].ToString();
            DataRow[] dr_list = dt_new.Select(filter);
            if ((dr_list.Length == 0) && (ng_count_str.Substring(ng_count_str.Length - 17) != "-1,-1,-1,-1,-1,-1"))
            {
                String[] ng_count_list = ng_count_str.Split(',');
                String[] day_list = day_str.Split(',');
                String[] hour_list = hour_str.Split(',');
                dt.Rows[i]["ng_count_str"] = "";
                dt.Rows[i]["day_str"] = "";
                dt.Rows[i]["hour_str"] = "";
                for (int n = ng_count_list.Length - 6; n < ng_count_list.Length; n++)
                {
                    dt.Rows[i]["ng_count_str"] = dt.Rows[i]["ng_count_str"].ToString() + ng_count_list[n] + ",";
                    dt.Rows[i]["day_str"] = dt.Rows[i]["day_str"].ToString() + day_list[n] + ",";
                    dt.Rows[i]["hour_str"] = dt.Rows[i]["hour_str"].ToString() + hour_list[n] + ",";
                }

                dt.Rows[i]["ng_count_str"] = dt.Rows[i]["ng_count_str"].ToString().Trim(',');
                dt.Rows[i]["day_str"] = dt.Rows[i]["day_str"].ToString().Trim(',');
                dt.Rows[i]["hour_str"] = dt.Rows[i]["hour_str"].ToString().Trim(',');
                dt_new.ImportRow(dt.Rows[i]);
            }
        }
        // 使用 DataView 來排序 DataTable
        DataView sortedView = new DataView(dt_new);
        sortedView.Sort = "layer_order ASC, line_order ASC, model ASC"; // 依照 Name 升冪排序, ID 降冪排序
        dt_new = sortedView.ToTable();


        var groupedData = from row in dt_new.AsEnumerable()
                          group row by new
                          {
                              item_type = row.Field<string>("item_type"),
                              layer = row.Field<string>("layer"),
                              line_id = row.Field<string>("line_id"),
                              product = row.Field<string>("product")
                          } into grouped
                          select new
                          {
                              item_type = grouped.Key.item_type,
                              layer = grouped.Key.layer,
                              line_id = grouped.Key.line_id,
                              product = grouped.Key.product,
                              ng_judge = grouped.Min(row => row.Field<Int64>("ng_check"))
                          };

        //找每個item_type的狀況
        DataTable dt_model_ng = new DataTable();
        dt_model_ng.Columns.Add("item_type", typeof(string));
        dt_model_ng.Columns.Add("layer", typeof(string));
        dt_model_ng.Columns.Add("line_id", typeof(string));
        dt_model_ng.Columns.Add("product", typeof(string));
        dt_model_ng.Columns.Add("ng_judge", typeof(int));
        foreach (var groupedRow in groupedData)
        {
            dt_model_ng.Rows.Add(groupedRow.item_type, groupedRow.layer, groupedRow.line_id, groupedRow.product, groupedRow.ng_judge);
        }

        dt_item = new DataTable();
        dt_item.Columns.Add("item_type", typeof(string));
        dt_item.Columns.Add("ng_judge", typeof(int));

        var groupedData2 = from row in dt_model_ng.AsEnumerable()
                           group row by new
                           {
                               item_type = row.Field<string>("item_type"),
                           } into grouped
                           select new
                           {
                               item_type = grouped.Key.item_type,
                               ng_judge = grouped.Max(row => row.Field<int>("ng_judge"))
                           };
        foreach (var groupedRow in groupedData2.OrderBy(data => data.item_type))
        {
            dt_item.Rows.Add(groupedRow.item_type, groupedRow.ng_judge);
        }


        for (int i = 0; i < dt_new.Rows.Count; i++)
        {
            String item_type = dt_new.Rows[i]["item_type"].ToString();
            String layer = dt_new.Rows[i]["layer"].ToString();
            String line_id = dt_new.Rows[i]["line_id"].ToString();
            String product = dt_new.Rows[i]["product"].ToString();


            var filteredRows = dt_model_ng.AsEnumerable()
                .Where(row => row.Field<string>("item_type") == item_type
                && row.Field<string>("layer") == layer
                && row.Field<string>("line_id") == line_id
                && row.Field<string>("product") == product
                ).ToArray();

            // 若要將結果轉換為 DataRow[]
            DataRow[] result = filteredRows.ToArray();

            dt_new.Rows[i]["ng_check"] = 0;
            if (result.Length > 0)
            {
                dt_new.Rows[i]["ng_check"] = int.Parse(result[0]["ng_judge"].ToString());
            }
        }

        //GridView1.DataSource = dt_new;
        //GridView1.DataBind();

    }

    public Label addlabel(String t)
    {
        Label lb = new Label();
        lb.Text = t;
        return lb;
    }


    public DataTable GetSPCData(DateTime endtime)
    {
        String sql = "";
        sql = @"
                    select   
                    chart_id,item_type,spec_valuetype,line_id,layer,model,substr(model,1,9) product,   
                    GROUP_CONCAT(daystr order by daystr asc,timegroup asc separator ',') as day_str,   
                    GROUP_CONCAT(hour_diff order by daystr asc,timegroup asc separator ',') as hour_str,   
                    GROUP_CONCAT(ifnull(ng_count,-1) order by daystr asc,timegroup asc separator ',') as ng_count_str, 
                    GROUP_CONCAT(ifnull(meas_time,'') order by daystr asc,timegroup asc separator ',') as meas_time_str,   
                    max(meas_time) as meas_time_max, 
                    '' as starttime, 
                    0 as ng_check, 
                    CASE layer when  'BM' THEN 0   
                    WHEN 'R' THEN 1   
                    WHEN 'G' THEN 2   
                    WHEN 'B' THEN 3   
                    WHEN 'PS' THEN 4   
                    WHEN 'ITO' THEN 5   
                    else 10   
                    END as layer_order , 
                    CASE line_id when '' THEN -1   
                    when 'FDM10' THEN 0   
                    WHEN 'FDR10' THEN 1   
                    WHEN 'FDG10' THEN 2   
                    WHEN 'FDB10' THEN 3   
                    WHEN 'FDS10' THEN 4   
                    WHEN 'FDM20' THEN 5   
                    WHEN 'FDR20' THEN 6   
                    WHEN 'FDS20' THEN 7   
                    WHEN 'FDM30' THEN 8   
                    ELSE 10 END as line_order 

                    from  
                    ( 
                    select  
                    chart_id,  
                    item_type,  
                    spec_valuetype,  
                    line_id,  
                    layer,  
                    model,  
                    timegroup,  
                    max(ng_count) as ng_count, 
                    hour_diff, 
                    daystr, 
                    max(meas_time) as meas_time 
                    from 
                    ( 
  	                select  
  	                a.chart_id,  
  	                a.item_type,  
  	                a.spec_valuetype,  
  	                a.line_id,  
  	                a.layer,  
  	                a.model,  
  	                t.timegroup,  
  	                case when a.timegroup = t.timegroup and a.daystr = d1.daystr then ng_count else null end as ng_count,  
  	                (t.timegroup * 4 + 8) % 24 AS hour_diff,  
  	                d1.daystr,  
  	                case when a.timegroup = t.timegroup and a.daystr = d1.daystr then meas_time else null end as meas_time  
  	                from  
  	                (  
  		                select      
  		                    chart_id,  
  		                    item_type,  
  		                    spec_valuetype,  
  		                    line_id,  
  		                    layer,  
  		                    model,  
  		                    timegroup,  
  		                    ifnull(sum(ng_count),-1) as ng_count,  
  		                    daystr,  
  		                    max(t.report_time) as meas_time  
  		                    from  
  		                (  
  			                select   
  				                    a.chart_id,    
  				                    a.item_type,    
  				                    a.spec_valuetype,    
  				                    a.line_id,    
  				                    replace(replace(replace(substring_index(substring_index(a.chart_id,'/',2),'/',-1),'10',''),'20',''),'30','') as layer,    
  				                    substring_index(a.chart_id,'/',1) as model,    
  				                    case when a.spec_valuetype = 'AVG' and ( b.value_avg < a.LCL or b.value_avg > a.UCL ) then 1
  				                    when a.spec_valuetype = 'MAX' and ( b.value_max < a.LCL or b.value_max > a.UCL ) then 1
  				                    when a.spec_valuetype = 'MIN' and ( b.value_min < a.LCL or b.value_min > a.UCL ) then 1
  				                    when b.value_avg is null then null else 0 end as ng_count,  
  				                    DATE_FORMAT(date_sub(b.report_time, interval 450 minute), '%Y%m%d') as daystr,   
  				                    floor(TIMESTAMPDIFF(minute, DATE_FORMAT(date_sub(b.report_time, interval 450 minute), '%Y-%m-%d 07:30:00'), b.report_time) / 60 / 4) as timegroup,  
  				                    b.report_time   
  				                FROM   
  				                (  
  					                select * from    
  					                    (    
  						                    select    
  						                    case when userspec.chart_id is null then spcspec.chart_id else userspec.chart_id end as chart_id,    
  						                    case when userspec.chart_id is null then spcspec.line_id else userspec.line_id end as line_id,    
  						                    case when userspec.chart_id is null then spcspec.spec_valuetype else userspec.spec_valuetype end as spec_valuetype,    
  						                    case when userspec.chart_id is null then spcspec.LSL else userspec.LSL end as LSL,    
    
  						                    case when userspec.chart_id is null and spcspec.LCL is null then spcspec.LSL   
  						                    when userspec.chart_id is null then spcspec.LCL    
  						                    when userspec.LCL is null then userspec.LSL   
  						                    else userspec.LCL end as LCL,     
    
  						                    case when userspec.chart_id is null then spcspec.CL else userspec.CL end as CL,   
    
  						                    case when userspec.chart_id is null and spcspec.UCL is null then spcspec.USL    
  						                    when userspec.chart_id is null then spcspec.UCL    
  						                    when userspec.UCL is null then userspec.USL   
  						                    else userspec.UCL end as UCL,   
    
  						                    case when userspec.chart_id is null then spcspec.USL else userspec.USL end as USL,    
  						                    case when userspec.chart_id is null then spcspec.auto_block else userspec.auto_block end as auto_block,    
  						                    case when userspec.chart_id is null then spcspec.block_tool else userspec.block_tool end as block_tool,    
  						                    case when userspec.chart_id is null then 'spc' else 'user' end as `spec_type`,     
  						                    case when userspec.chart_id is null then spcspec.spc_spec_ver else userspec.user_spec_ver end as `spec_ver`,    
  						                    case when userspec.chart_id is null then spcspec.view_chart else userspec.view_chart end as `view_chart`,    
  						                    case when userspec.chart_id is null then spcspec.item_type else userspec.item_type end as `item_type`    
  						                    from    
  						                    (    
  							                    select * from    
  							                    (    
  							                    SELECT ROW_NUMBER() OVER ( PARTITION BY chart_id ORDER BY spc_spec_ver DESC ) as rn , t.*     
  							                    FROM l7bcf_spc.spc_spec t     
  							                    where user_spec_ver = 0    
  							                    ) t    
  							                    where t.rn = 1    
  						                    ) spcspec    
  						                    left join    
  						                    (    
  							                    select * from     
  							                    (     
  								                    SELECT ROW_NUMBER() OVER ( PARTITION BY chart_id, spec_valuetype, line_id ORDER by user_spec_ver DESC ) as rn , t.*     
  								                    FROM l7bcf_spc.spc_spec t     
  								                    where spc_spec_ver = 0    
  							                    ) t    
  							                    where t.rn = 1    
  						                    ) userspec    
  						                    on spcspec.chart_id = userspec.chart_id    
  					                    ) t    
  					                    where t.view_chart = 'Y'    
  				                ) a  
  				                inner join l7bcf_spc.spc_data b  
  				                on a.chart_id = b.chart_id and (a.line_id = '' or a.line_id = b.line_id)   
  				                where 1=1  
                ";
        sql += " 				and b.report_time >= '" + endtime.AddDays(-1).ToString("yyyy/MM/dd 07:30:00") + "' ";
        sql += " 				and b.report_time < '" + endtime.AddDays(1).ToString("yyyy/MM/dd 07:30:00") + "' ";
        sql += "  		) t      ";
        sql += "  		group by chart_id,item_type,spec_valuetype,line_id,layer,model,timegroup,daystr   ";
        sql += "  	) a  ";
        sql += "  	join  ( select 0 as timegroup union select 1 union select 2 union select 3 union select 4 union select 5  ) t  ";
        sql += " 	join ( select '" + endtime.AddDays(-1).ToString("yyyyMMdd") + "' as daystr union select '" + endtime.ToString("yyyyMMdd") + "' ) d1 ";
        sql += @"
                 ) tt 
                 group by   
                 chart_id,  
                 item_type,  
                 spec_valuetype,  
                 line_id,  
                 layer,  
                 model,  
                 timegroup,  
                 hour_diff, 
                 daystr 
                 ) tt 
                 group by chart_id,item_type,spec_valuetype,line_id,layer,model   
                  ORDER BY (CASE layer when  'BM' THEN 0   
                  WHEN 'R' THEN 1   
                  WHEN 'G' THEN 2   
                  WHEN 'B' THEN 3   
                  WHEN 'PS' THEN 4   
                  WHEN 'ITO' THEN 5   
                  else 10   
                  END),    
                  (CASE line_id when '' THEN -1   
                  when 'FDM10' THEN 0   
                  WHEN 'FDR10' THEN 1   
                  WHEN 'FDG10' THEN 2   
                  WHEN 'FDB10' THEN 3   
                  WHEN 'FDS10' THEN 4   
                  WHEN 'FDM20' THEN 5   
                  WHEN 'FDR20' THEN 6   
                  WHEN 'FDS20' THEN 7   
                  WHEN 'FDM30' THEN 8   
                  ELSE 10 END),   
                  model   
                ";



        //Response.Write(sql.Replace("\n","<br>"));
        DataTable dt = get_mysql_data(sql);

        //GridView1.DataSource = dt;
        //GridView1.DataBind();

        return dt;
    }

    public DataTable GetSpecAll(DateTime endtime)
    {
        String sql = "";
        sql += " select   ";
        sql += "  chart_id,item_type,spec_valuetype,line_id,layer,model,substr(model,1,9) product,   ";
        sql += "  GROUP_CONCAT(daystr order by daystr asc,timegroup asc separator ',') as day_str,   ";
        sql += "  GROUP_CONCAT(hour_diff order by daystr asc,timegroup asc separator ',') as hour_str,   ";
        sql += "  GROUP_CONCAT(ifnull(ng_count,-1) order by daystr asc,timegroup asc separator ',') as ng_count_str, ";
        sql += "  GROUP_CONCAT(ifnull(meas_time,'') order by daystr asc,timegroup asc separator ',') as meas_time_str,   ";
        sql += "  max(meas_time) as meas_time_max, ";
        sql += "  '' as starttime, ";
        sql += "  0 as ng_check, ";
        sql += " CASE layer when  'BM' THEN 0   ";
        sql += " WHEN 'R' THEN 1   ";
        sql += " WHEN 'G' THEN 2   ";
        sql += " WHEN 'B' THEN 3   ";
        sql += " WHEN 'PS' THEN 4   ";
        sql += " WHEN 'ITO' THEN 5   ";
        sql += " else 10   ";
        sql += " END as layer_order , ";
        sql += " CASE line_id when '' THEN -1   ";
        sql += " when 'FDM10' THEN 0   ";
        sql += " WHEN 'FDR10' THEN 1   ";
        sql += " WHEN 'FDG10' THEN 2   ";
        sql += " WHEN 'FDB10' THEN 3   ";
        sql += " WHEN 'FDS10' THEN 4   ";
        sql += " WHEN 'FDM20' THEN 5   ";
        sql += " WHEN 'FDR20' THEN 6   ";
        sql += " WHEN 'FDS20' THEN 7   ";
        sql += " WHEN 'FDM30' THEN 8   ";
        sql += " ELSE 10 END as line_order ";
        sql += "  from ";
        sql += " ( ";
        sql += " 	select ";
        sql += " 	 a.chart_id,   ";
        sql += " 	 a.item_type,   ";
        sql += " 	 a.spec_valuetype,   ";
        sql += " 	 a.line_id,   ";
        sql += " 	 replace(replace(replace(substring_index(substring_index(a.chart_id,'/',2),'/',-1),'10',''),'20',''),'30','') as layer,   ";
        sql += " 	 substring_index(a.chart_id,'/',1) as model,   ";
        sql += " 	 ng_count, ";
        sql += " 	 daystr, ";
        sql += "      (t.timegroup * 4 + 8) % 24 AS hour_diff, ";
        sql += "      timegroup, ";
        sql += " 	 null as meas_time  ";
        sql += " 	from ";
        sql += " 	( ";
        sql += " 		select * from   ";
        sql += " 		 (   ";
        sql += " 			 select   ";
        sql += " 			 case when userspec.chart_id is null then spcspec.chart_id else userspec.chart_id end as chart_id,   ";
        sql += " 			 case when userspec.chart_id is null then spcspec.line_id else userspec.line_id end as line_id,   ";
        sql += " 			 case when userspec.chart_id is null then spcspec.spec_valuetype else userspec.spec_valuetype end as spec_valuetype,   ";
        sql += " 			 case when userspec.chart_id is null then spcspec.LSL else userspec.LSL end as LSL,   ";
        sql += "  ";
        sql += " 			 case when userspec.chart_id is null and spcspec.LCL is null then spcspec.LSL  ";
        sql += " 			 when userspec.chart_id is null then spcspec.LCL   ";
        sql += " 			 when userspec.LCL is null then userspec.LSL  ";
        sql += " 			 else userspec.LCL end as LCL,    ";
        sql += "  ";
        sql += " 			 case when userspec.chart_id is null then spcspec.CL else userspec.CL end as CL,  ";
        sql += "  ";
        sql += " 			 case when userspec.chart_id is null and spcspec.UCL is null then spcspec.USL   ";
        sql += " 			 when userspec.chart_id is null then spcspec.UCL   ";
        sql += " 			 when userspec.UCL is null then userspec.USL  ";
        sql += " 			 else userspec.UCL end as UCL,  ";
        sql += "  ";
        sql += " 			 case when userspec.chart_id is null then spcspec.USL else userspec.USL end as USL,   ";
        sql += " 			 case when userspec.chart_id is null then spcspec.auto_block else userspec.auto_block end as auto_block,   ";
        sql += " 			 case when userspec.chart_id is null then spcspec.block_tool else userspec.block_tool end as block_tool,   ";
        sql += " 			 case when userspec.chart_id is null then 'spc' else 'user' end as `spec_type`,    ";
        sql += " 			 case when userspec.chart_id is null then spcspec.spc_spec_ver else userspec.user_spec_ver end as `spec_ver`,   ";
        sql += " 			 case when userspec.chart_id is null then spcspec.view_chart else userspec.view_chart end as `view_chart`,   ";
        sql += " 			 case when userspec.chart_id is null then spcspec.item_type else userspec.item_type end as `item_type`   ";
        sql += " 			 from   ";
        sql += " 			 (   ";
        sql += " 				 select * from   ";
        sql += " 				 (   ";
        sql += " 				 SELECT ROW_NUMBER() OVER ( PARTITION BY chart_id ORDER BY spc_spec_ver DESC ) as rn , t.*    ";
        sql += " 				 FROM l7bcf_spc.spc_spec t    ";
        sql += " 				 where user_spec_ver = 0   ";
        sql += " 				 ) t   ";
        sql += " 				 where t.rn = 1   ";
        sql += " 			 ) spcspec   ";
        sql += " 			 left join   ";
        sql += " 			 (   ";
        sql += " 				 select * from    ";
        sql += " 				 (    ";
        sql += " 					 SELECT ROW_NUMBER() OVER ( PARTITION BY chart_id, spec_valuetype, line_id ORDER by user_spec_ver DESC ) as rn , t.*    ";
        sql += " 					 FROM l7bcf_spc.spc_spec t    ";
        sql += " 					 where spc_spec_ver = 0   ";
        sql += " 				 ) t   ";
        sql += " 				 where t.rn = 1   ";
        sql += " 			 ) userspec   ";
        sql += " 			 on spcspec.chart_id = userspec.chart_id   ";
        sql += " 		 ) t   ";
        sql += " 		 where t.view_chart = 'Y'   ";
        sql += " 	) a ";
        sql += " 	join  ( select 0 as timegroup union select 1 union select 2 union select 3 union select 4 union select 5  ) t ";
        sql += " 	join ( select '" + endtime.AddDays(-1).ToString("yyyyMMdd") + "' as daystr union select '" + endtime.ToString("yyyyMMdd") + "' ) d1 ";
        sql += " 	join ( select null as ng_count ) ng ";
        sql += " ) tt ";
        sql += " group by chart_id,item_type,spec_valuetype,line_id,layer,model   ";

        //Response.Write(sql);
        DataTable dt = get_mysql_data(sql);

        //GridView1.DataSource = dt;
        //GridView1.DataBind();

        return dt;
    }


    public String get_lastdataTime()
    {
        String sql = "SELECT DATE_FORMAT(update_time, '%Y/%m/%d %H:%i:%s') as update_time FROM l7bcf_spc.spc_data order by report_time desc limit 1";
        DataTable dt = get_mysql_data(sql);
        String t = "No DATA!";
        if (dt.Rows.Count > 0)
            t = dt.Rows[0][0].ToString();
        return t;

    }

    public DataTable get_mysql_data(String sql)
    {
        DataTable DT = new DataTable();
        for (int i = 0; i < 5; i++)
        {
            try
            {
                MySqlConnection conn = new MySqlConnection(connString);
              
                conn.Open();
                MySqlDataAdapter DA = new MySqlDataAdapter(sql, conn);
                DA.Fill(DT);
                conn.Close();
                break;
            }
            catch
            {
                Console.WriteLine("TIME OUT");
            }
        }
        return DT;

    }

    public String draw_table(DataTable dt, String title)
    {
        String result = "";



        result += "<table style=\"border:1px solid #777777;\" align='center'>";
        String[] cols_str = { "監控參數", "LAYER", "LINE", "MODEL", "種類", "08", "12", "16", "20", "00", "04", "NewLine" };
        String[] cols_size = { "120", "80", "100", "200", "70", "50", "50", "50", "50", "50", "50", "60" };
        result += "<tr style=\"border:1px solid #777777;\" align='center' valign='middle' bgcolor='#003366'>";
        for (int i = 0; i < cols_str.Length; i++)
        {
            result += "<td style=\"width:" + cols_size[i] + "px;border:1px solid #777777;\" align='center'>";
            result += "<font color='white' size=\"2\" style='font-weight:bold;'>";
            result += cols_str[i];
            result += "</font>";
            result += "</td>";
        }
        result += "</tr>";

        Boolean haveData = false;
        Boolean haveNg_table = false;

        //rows
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            String color = "black";
            if (dt.Rows[i]["ng_check"].ToString() != "0")
            {
                color = "red";
            }
            else if (cb_noData.Checked )//&& !cb_outspec.Checked)
            {
                continue;
            }
            haveData = true;

            Boolean haveNg_row = false;

            String result_temp = "";

            result_temp += "<tr style=\"border:1px solid #777777;\" align='center'>";
            result_temp += "<td align='center'><font size=\"2\" color='" + color + "' style='font-weight:bold;'>" + dt.Rows[i]["item_type"].ToString() + "</font></td>";
            result_temp += "<td align='center'><font size=\"2\" color='" + color + "' style='font-weight:bold;'>" + dt.Rows[i]["layer"].ToString() + "</font></td>";
            result_temp += "<td align='center'><font size=\"2\" color='" + color + "' style='font-weight:bold;'>" + dt.Rows[i]["line_id"].ToString() + "</font></td>";

            String spec_url = "frmSPCMonitorSpec_U.aspx?";
            spec_url += "chart_id=" + dt.Rows[i]["chart_id"].ToString();
            spec_url += "&layer=" + dt.Rows[i]["layer"].ToString();
            spec_url += "&line_id=" + dt.Rows[i]["line_id"].ToString();
            result_temp += "<td><a href=\"" + spec_url + "\" target=\"_blank\" style=\"text-decoration:none;\"><font size=\"2\" color='" + color + "' style='font-weight:bold;'>" + dt.Rows[i]["model"].ToString() + "</font></a></td>";

            result_temp += "<td align='center'><font size=\"2\" style='font-weight:bold;'>" + dt.Rows[i]["spec_valuetype"].ToString() + "</font></td>";

            foreach (String ng in dt.Rows[i]["ng_count_str"].ToString().Split(','))
            {
                String temp = "";
                temp += "<a href=\"history.aspx?query=1&product=" + dt.Rows[i]["model"].ToString()+"&layer="+ dt.Rows[i]["layer"].ToString() + "&report_time="+ txtQDate.Text+"&item_type="+ dt.Rows[i]["item_type"].ToString() + "\" target=\"_blank\">";
                if (int.Parse(ng) == 0)
                    temp += "<img src=\"images/green.png\" width=\"18\" height=\"18\" alt=\"img\">";
                else if (int.Parse(ng) > 0)
                {
                    temp += "<img src=\"images/red.png\" width=\"18\" height=\"18\" alt=\"img\">";
                    haveNg_row = true;
                }
                temp += "</a>";


                result_temp += "<td align='center'><font size=\"2\" style='font-weight:bold;'>" + temp + "</font></td>";

            }
            if (dt.Rows[i]["starttime"].ToString() != "")
                result_temp += "<td align='center' title = '" + dt.Rows[i]["starttime"].ToString() + "'><font size=\"2\" color='" + color + "' style='font-weight:bold;'>V</font></td>";
            //result_temp += "<td align='center'><font size=\"2\" color='" + color + "' style='font-weight:bold;'>" + dt.Rows[i]["starttime"].ToString() + "</font></td>";
            else
                result_temp += "<td align='center'><font size=\"2\" color='" + color + "' style='font-weight:bold;'>" + dt.Rows[i]["starttime"].ToString() + "</font></td>";

            result_temp += "</tr>";

            if (!cb_ngonly.Checked) 
                result += result_temp;
            else
            {
                if (haveNg_row)
                {
                    result += result_temp;
                    haveNg_table = true;
                }
            }

        }
        result += "</table>";

        if (!haveData)
            return "";
        if ((!haveNg_table) && (cb_ngonly.Checked))
            return "";

        return result;
    }



    protected void btnExport_Click(object sender, EventArgs e)
    {
        getspec();
    }

    public void getspec()
    {
        String sql = "";
        sql += " select * from ( ";
        sql += " select ";
        sql += " replace(replace(replace(substring_index(substring_index(spcspec.chart_id,'/',2),'/',-1),'10',''),'20',''),'30','') as layer, ";

        sql += " case when userspec.chart_id is null then spcspec.item_type else userspec.item_type end as item_type, ";
        sql += " case when userspec.chart_id is null then spcspec.chart_id else userspec.chart_id end as chart_id, ";
        sql += " case when userspec.chart_id is null then spcspec.line_id else userspec.line_id end as line_id, ";
        sql += " case when userspec.chart_id is null then spcspec.meas_point else userspec.meas_point end as meas_point, ";
        sql += " case when userspec.chart_id is null then spcspec.spec_valuetype else userspec.spec_valuetype end as spec_valuetype, ";
        sql += " case when userspec.chart_id is null then spcspec.LSL else userspec.LSL end as LSL, ";
        sql += " case when userspec.chart_id is null then spcspec.LCL else userspec.LCL end as LCL, ";
        sql += " case when userspec.chart_id is null then spcspec.CL else userspec.CL end as CL, ";
        sql += " case when userspec.chart_id is null then spcspec.UCL else userspec.UCL end as UCL, ";
        sql += " case when userspec.chart_id is null then spcspec.USL else userspec.USL end as USL, ";
        sql += " case when userspec.chart_id is null then spcspec.auto_block else userspec.auto_block end as auto_block, ";
        sql += " case when userspec.chart_id is null then spcspec.block_tool else userspec.block_tool end as block_tool, ";
        sql += " case when userspec.chart_id is null then 'spc' else 'user' end as `spec_type`,  ";
        sql += " case when userspec.chart_id is null then 0 else userspec.user_spec_ver end as `spec_ver`, ";
        sql += " case when userspec.chart_id is null then spcspec.view_chart else userspec.view_chart end as `view_chart`, ";
        sql += " case when userspec.chart_id is null then 'sys' else userspec.update_man end as `update_man`, ";
        sql += " case when userspec.chart_id is null then DATE_FORMAT(spcspec.update_time, '%Y/%m/%d %H:%i:%s') else DATE_FORMAT(userspec.update_time, '%Y/%m/%d %H:%i:%s') end as `update_time` ";
        sql += " from ";
        sql += " ( ";
        sql += "     select * from ";
        sql += "     ( ";
        sql += "     SELECT ROW_NUMBER() OVER ( PARTITION BY chart_id ORDER BY spc_spec_ver DESC ) as rn , t.*  ";
        sql += "     FROM l7bcf_spc.spc_spec t  ";
        sql += "     where user_spec_ver = 0 ";
        sql += "     ) t ";
        sql += "     where t.rn = 1 ";
        sql += " ) spcspec ";
        sql += " left join ";
        sql += " ( ";
        sql += "     select * from  ";
        sql += "     (  ";
        sql += "         SELECT ROW_NUMBER() OVER ( PARTITION BY chart_id, spec_valuetype, line_id ORDER by user_spec_ver DESC ) as rn , t.*  ";
        sql += "         FROM l7bcf_spc.spc_spec t  ";
        sql += "         where spc_spec_ver = 0 ";
        sql += "     ) t ";
        sql += "     where t.rn = 1 ";
        sql += " ) userspec ";
        sql += " on spcspec.chart_id = userspec.chart_id ";
        sql += " ) t ";
        sql += " where 1=1 ";
        sql += " order by substring_index(substring_index(chart_id,'/',2),'/',-1), item_type,chart_id ";
        DataTable dt = get_mysql_data(sql);
        ExportDataTable(dt);
    }
    public void ExportDataTable(DataTable dt, String fil_name = "SPECDATA")
    {

        //DataTable为要导出的数据表
        DataGrid dg = new DataGrid();
        dg.DataSource = dt;
        dg.DataBind();

        //如果文件名称有中文，指定编码
        string fileName = HttpUtility.UrlEncode(fil_name, Encoding.UTF8).ToString();


        //设置编码格式
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.Charset = "UTF-8";// "UTF-8"或者"GB2312"
        HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";//text/csv
        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.UTF8;
        HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment;filename=" + fileName + ".xls");
        //导出excel
        System.IO.StringWriter oSW = new System.IO.StringWriter();
        HtmlTextWriter oHW = new HtmlTextWriter(oSW);
        dg.RenderControl(oHW);



        //输出时加上"<meta http-equiv=\"content-type\" content=\"application/ms-excel; charset=UTF-8\"/>"解决编码问题

        //返回浏览器，
        HttpContext.Current.Response.Write("<meta http-equiv=\"content-type\" content=\"application/ms-excel; charset=UTF-8\"/>" + oSW.ToString());
        HttpContext.Current.Response.End();
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        //避免「型別 xxx 的控制項 xxx 必須置於有 runat=server 的表單標記之中。」的問題
    }

    public DataTable getProcModel(String start_time, String end_Time)
    {
        String sql = "";

        sql += " select b.* from ";
        sql += " ( ";
        sql += "   select      ";
        sql += "     line_id,substr(model_no,1,9) as model_no,      ";
        sql += "     operation_id as op      ";
        sql += "   from      ";
        sql += "   (      ";
        sql += "     select ";
        sql += "     line_id, model_no, operation_id, report_time, ";
        sql += "     row_number() over(partition by line_id,operation_id order by report_time desc) rn ";
        sql += "     from cfspch.h_raw_kpc t ";
        sql += "     where 1=1 ";
        sql += "     and report_time >= to_date('" + start_time + "', 'YYYY/MM/DD HH24:MI:SS')  ";
        sql += "     and report_time < to_date('" + end_Time + "', 'YYYY/MM/DD HH24:MI:SS')  ";
        sql += "     and operation_id in ('BM','R','G','B','ITO','PS','polish','OC') ";
        sql += "     and mes_id = 'INLINE' ";
        sql += "     and line_id is not null ";
        sql += "   ) t      ";
        sql += "   where t.rn = 1 ";
        sql += "   order by operation_id, line_id ";
        sql += " ) a ";
        sql += " left join ";
        sql += " ( ";
        sql += "     select line_id,substr(model_no,1,9) as model_no, operation_id as op, ";
        sql += "     to_char(min(report_time), 'YYYY/MM/DD HH24:MI:SS') as min_report_time, ";
        sql += "     to_char(max(report_time), 'YYYY/MM/DD HH24:MI:SS') as max_report_time ";
        sql += "     from cfspch.h_raw_kpc t ";
        sql += "     where 1=1 ";
        sql += "     and report_time >= to_date('" + start_time + "', 'YYYY/MM/DD HH24:MI:SS')  ";
        sql += "     and report_time < to_date('" + end_Time + "', 'YYYY/MM/DD HH24:MI:SS')  ";
        sql += "     and operation_id in ('BM','R','G','B','ITO','PS','polish','OC') ";
        sql += "     and mes_id = 'INLINE' ";
        sql += "     and line_id is not null ";
        sql += "     group by line_id,substr(model_no,1,9),operation_id ";
        sql += " ) b ";
        sql += " on a.line_id = b.line_id and a.model_no = b.model_no and a.op = b.op ";
        //Response.Write(sql);
        
        return GetDTL7B(sql, 0);
    }

    public DataTable GetDTL7B(String SQL, int type = 2)
    {
        String Conn_Str = "Provider=MSDAORA;User ID=l7bint_ap;Data Source=TCSPCH_7BHMTS;Password=l7bint$ap";
        if (type == 0)
            Conn_Str = "Provider=MSDAORA;User ID=l7bint_ap;Data Source=C7BH_SHA;Password=l7bint$ap";
        else if (type == 1)
            Conn_Str = "Provider=MSDAORA;User ID=l7bint_ap;Data Source=L7BH;Password=l7bint$ap";




        try
        {
            OleDbConnection Conn = new OleDbConnection(Conn_Str);
            OleDbCommand Cmd = new OleDbCommand();
            Cmd.CommandText = SQL;
            Cmd.Connection = Conn;
            Conn.Open();
            OleDbDataAdapter ad = new OleDbDataAdapter(Cmd);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            Conn.Close();
            Conn.Dispose();
            return dt;
        }
        catch
        {
            return new DataTable();
        }
    }
}