﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web;
using System.Text;
using System.Data.OleDb;
using System.Drawing;

public partial class CF_SPC_Default : System.Web.UI.Page
{
    static String connString = "Database=l7bcf_spc;Data Source=tw100043811;Port=3307;User Id=l7b_commit;Password=l7b$commit;CharSet=utf8;SslMode=None;allowPublicKeyRetrieval=true";

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack) //第一次開網頁
        {
            //string strDate = "";

            //if (string.IsNullOrEmpty(strDate))
            //    strDate = DateTime.Now.AddMinutes(-450).ToString("yyyy/MM/dd");
            //txtQDate.Text = strDate;
            //btnQuery_Click(null, null);
            GetSPCData();
        }
    }

    protected void GridView1_RowCreated(Object sender, GridViewRowEventArgs e)
    {
        DataRowView drv = (DataRowView)e.Row.DataItem;

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            
            //try
            //{
            /*
                String chart_id = ((Label)(e.Row.FindControl("g_chart_id"))).Text;
                String layer = ((Label)(e.Row.FindControl("g_layer"))).Text;
                String item_type = ((Label)(e.Row.FindControl("g_item_type"))).Text;
                String product = chart_id.Split('/')[0];


                String temp = "";
                temp += "<a href=\"history.aspx?query=1&product=" + product + 
                    "&layer=" + layer + 
                    "&report_time=" + DateTime.Now.AddHours(-7.5).ToString("yyyy/MM/dd") + 
                    "&item_type=" + item_type + "\" target=\"_blank\">";
                temp += ((Label)(e.Row.FindControl("g_chart_id"))).Text;
                temp += "</a>";
                ((Label)(e.Row.FindControl("g_chart_id"))).Text = temp;
            */
                

            //}
            //catch { }
            
        }

    }

    public DataTable GetSPCData()
    {
        String sql = "";
        sql = @"
                    select
	                    DATE_FORMAT(run_start_time,'%Y-%m-%d %H:%i:%s') `run_start_time`,
	                    DATE_FORMAT(run_end_time,'%Y-%m-%d %H:%i:%s') `run_end_time`,
	                    DATE_FORMAT(meas_time_last,'%Y-%m-%d %H:%i:%s') `meas_time_last`,
	                    `line_id`,
	                    `chart_id`,
	                    `product`,
	                    `item_type`,
	                    `layer`,
	                    `new_line`,
	                    `ng_count`,
	                    `block_tool`,
	                    `block_reason`,
	                    DATE_FORMAT(b.update_time,'%Y-%m-%d %H:%i:%s') `update_time`
                    from
	                    (select max(update_time) update_time FROM l7bcf_spc.spc_toolblock_check) a
                    left join
	                    l7bcf_spc.spc_toolblock_check b
                    on a.update_time - interval 10 minute < b.update_time
                ";



        //Response.Write(sql.Replace("\n","<br>"));
        DataTable dt = get_mysql_data(sql);
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            if (i == 0)
                lb_update_time.Text = dt.Rows[i]["update_time"].ToString();
            String chart_id = dt.Rows[i]["chart_id"].ToString();
            String layer = dt.Rows[i]["layer"].ToString();
            String item_type = dt.Rows[i]["item_type"].ToString();
            String product = chart_id.Split('/')[0];

            String temp = "";
            temp += "<a href=\"history.aspx?query=1&product=" + product +
                "&layer=" + layer +
                "&report_time=" + DateTime.Now.AddHours(-7.5).ToString("yyyy/MM/dd") +
                "&item_type=" + item_type + "\" target=\"_blank\">";
            temp += chart_id;
            temp += "</a>";
            dt.Rows[i]["chart_id"] = temp;


        }



        GridView1.DataSource = dt;
        GridView1.DataBind();

        return dt;
    }

    public String get_lastdataTime()
    {
        String sql = "SELECT DATE_FORMAT(update_time, '%Y/%m/%d %H:%i:%s') as update_time FROM l7bcf_spc.spc_data order by report_time desc limit 1";
        DataTable dt = get_mysql_data(sql);
        String t = "No DATA!";
        if (dt.Rows.Count > 0)
            t = dt.Rows[0][0].ToString();
        return t;

    }

    public DataTable get_mysql_data(String sql)
    {
        DataTable DT = new DataTable();
        for (int i = 0; i < 5; i++)
        {
            try
            {
                MySqlConnection conn = new MySqlConnection(connString);
              
                conn.Open();
                MySqlDataAdapter DA = new MySqlDataAdapter(sql, conn);
                DA.Fill(DT);
                conn.Close();
                break;
            }
            catch
            {
                Console.WriteLine("TIME OUT");
            }
        }
        return DT;

    }

  

    public DataTable GetDTL7B(String SQL, int type = 2)
    {
        String Conn_Str = "Provider=MSDAORA;User ID=l7bint_ap;Data Source=TCSPCH_7BHMTS;Password=l7bint$ap";
        if (type == 0)
            Conn_Str = "Provider=MSDAORA;User ID=l7bint_ap;Data Source=C7BH_SHA;Password=l7bint$ap";
        else if (type == 1)
            Conn_Str = "Provider=MSDAORA;User ID=l7bint_ap;Data Source=L7BH;Password=l7bint$ap";




        try
        {
            OleDbConnection Conn = new OleDbConnection(Conn_Str);
            OleDbCommand Cmd = new OleDbCommand();
            Cmd.CommandText = SQL;
            Cmd.Connection = Conn;
            Conn.Open();
            OleDbDataAdapter ad = new OleDbDataAdapter(Cmd);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            Conn.Close();
            Conn.Dispose();
            return dt;
        }
        catch
        {
            return new DataTable();
        }
    }
}