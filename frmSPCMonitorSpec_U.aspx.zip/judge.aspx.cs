﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class web : System.Web.UI.Page
{
    static String connString = "Database=mqc;Data Source=tw100043811;Port=3307;User Id=l7b_commit;Password=l7b$commit;CharSet=utf8;SslMode=None;allowPublicKeyRetrieval=true";

    protected void Page_Load(object sender, EventArgs e)
    {
        if ((Session["Logined"] == null) || (Session["Logined"].ToString() != "1"))
        {
            String S_Url = Request.Url.AbsoluteUri;
            Session["S_url"] = S_Url;
            Response.Redirect("http://tw100040017.corpnet.auo.com/L7B/User_Login/Login.aspx?url=" + S_Url);
        }

        if (!IsPostBack)
        {
            query_data();
        }

    }

    public void query_data()
    {
       

        String sql = "";
        sql += " select ";
        sql += " DATE_FORMAT(report_time,'%Y/%m/%d %H:%i:%s') as report_time, ";
        sql += " chart_id, ";
        sql += " sheet_id, ";
        sql += " item_type, ";
        sql += " rawdata_ids, ";
        sql += " rawdata, ";
        sql += " `exclude`, ";
        sql += " judge_man, ";
        sql += " judge_note ";
        sql += " FROM l7bcf_spc.spc_data t ";
        sql += " where 1=1 ";
        sql += " and report_time = '" + Request.QueryString["report_time"] + "' ";
        sql += " and sheet_id = '" + Request.QueryString["sheet_id"] + "' ";
        sql += " and chart_id = '" + Request.QueryString["chart_id"] + "' ";


        DataTable dt = CONN_MYSQL(sql);
        if (dt.Rows.Count > 0)
        {
            lb_chart.Text = dt.Rows[0]["chart_id"].ToString();
            lb_sheetID.Text = dt.Rows[0]["sheet_id"].ToString();
            lb_reporttime.Text = dt.Rows[0]["report_time"].ToString();

            rb_exclude.SelectedIndex = rb_exclude.Items.IndexOf(rb_exclude.Items.FindByValue(dt.Rows[0]["exclude"].ToString()));            
            tb_note.Text = dt.Rows[0]["judge_note"].ToString();
            lb_updateman.Text = dt.Rows[0]["judge_man"].ToString();

            XValues.Value = dt.Rows[0]["rawdata_ids"].ToString();
            YValues.Value = dt.Rows[0]["rawdata"].ToString();
            chartid.Value = dt.Rows[0]["chart_id"].ToString();

        }

    }


    static DataTable CONN_MYSQL(String SQL)
    {
        MySqlConnection conn = new MySqlConnection(connString);
        conn.Open();
        MySqlDataAdapter DA = new MySqlDataAdapter(SQL, conn);
        DataTable DT = new DataTable();
        DA.Fill(DT);
        conn.Close();
        conn.Dispose();
        return DT;
    }

    protected void bt_submit_Click(object sender, EventArgs e)
    {
        
        int i = -1;

        i = update_data();
        if (i >= 0)
        {
            query_data();
            flash_windows();

        }
        else if (i != -100)
            Response.Write("<script language='javascript'>alert('Update is fail.');</script>");

    }

    public int update_data()
    {

        int e = 0;
        String sql = "";
        sql += " update l7bcf_spc.spc_data ";
        sql += " set `exclude` = '" + rb_exclude.SelectedValue + "', ";
        sql += " judge_note = '" + tb_note.Text + "', ";
        sql += " judge_man = '" + Session["uac_name"].ToString() + "' ";
        sql += " where 1=1 ";
        sql += " and report_time = '" + Request.QueryString["report_time"] + "' ";
        sql += " and sheet_id = '" + Request.QueryString["sheet_id"] + "' ";
        sql += " and chart_id = '" + Request.QueryString["chart_id"] + "' ";


        Response.Write(sql);

        try
        {
            MySqlConnection conn = new MySqlConnection(connString);
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            conn.Open();
            e = cmd.ExecuteNonQuery();
            conn.Close();
        }
        catch (Exception ex)
        {
            e = -1;
        }
        return e;
    }

    public void flash_windows()
    {
        Session["reflash"] = "1";
        Response.Write("<script language='javascript'>opener.location.reload(true);window.close();</script>");
    }


    protected void bt_save_Click(object sender, EventArgs e)
    {
        int i = -1;

        i = update_data();
        if (i >= 0)
        {
            //Response.Write("<script language='javascript'>alert('Update is successful.');</script>");
            query_data();
            flash_windows();

        }
        else if (i != -100)
            Response.Write("<script language='javascript'>alert('Update is fail.');</script>");
    }
}