import requests
import pandas as pd
import numpy as np
import os
import json
import cv2
import time

proxies = {"http":"http://10.97.86.109:8080"}

def Get_SQL_data(url, connstr, sql):
    json_data = {"connstr": connstr, "sql": sql}
    headers = {"Content-Type": "application/json"}
    
    try:
        response = requests.post(url=url,
                                 headers=headers,
                                 data=json.dumps(json_data),
                                 proxies=proxies)
        if response.status_code == 200:
            return response.text
    except:
        print("ERROR",url)
        pass
        
    response = requests.post(url=url.replace("tw100043343.corpnet.auo.com","tw100043812.corpnet.auo.com:9080").replace("10.96.152.76","10.96.152.227:9080"),
                             headers=headers,
                             data=json.dumps(json_data),
                             proxies=proxies)
    if response.status_code == 200:
        return response.text
    return None
   
def EXEC_SQL_data(url, connstr, sql):
    json_data = {"connstr": connstr, "sql": sql}
    headers = {"Content-Type": "application/json"}
    
    try:
        response = requests.post(url=url,
                                 headers=headers,
                                 data=json.dumps(json_data),
                                 proxies=proxies)
        if response.status_code == 200:
            return response.text
    except:
        print("ERROR",url)
        pass
        
    response = requests.post(url=url.replace("tw100043343.corpnet.auo.com","tw100043812.corpnet.auo.com:9080").replace("10.96.152.76","10.96.152.227:9080"),
                             headers=headers,
                             data=json.dumps(json_data),
                             proxies=proxies)
    if response.status_code == 200:
        return response.text
    return None
      

def request_url(url, timeout, count):
    get = False
    r = ''
    while count >= 0:

        try:
            r = requests.get(url, proxies=proxies, timeout=timeout)
            get = True
            break
        except:
            pass
    return get, r
    
def MatchTemp(img, img_temp):
    res = cv2.matchTemplate(img, img_temp, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
    return max_val, max_loc

    
def write_log(path, txt):
    fp = open(path, "a+")
    fp.write(txt)
    fp.close()
    

def readfile(file_path, file_name):
    
    
    if os.path.exists(file_path + file_name):
        df = check_pastdata(file_path + file_name)
        return df
    else:
        df = pd.DataFrame(columns=['test_date', 'logoff_date', 'line_id', 'product_code', 'eqp_id', 'op', 'cst_id', 'sheet_id', 'x', 'y', 'img_name', 'ok_score'])
        return df

    
    
def savefile(file_path,file_name,df,idx,data_limit):
    if not os.path.exists(file_path):
        os.makedirs(file_path)

    if os.path.exists(file_path + file_name):
        Record_File = check_pastdata(file_path + file_name)        
        Record_File = Record_File.append(df, ignore_index=True)
        Record_File = Record_File.drop_duplicates(subset = idx, keep='last')

        row_start = 0;
        
        if ( len(Record_File) >= data_limit ):
            row_start = len(Record_File) - data_limit
            
        #�O�d�̫� N �����
        Record_File = Record_File[row_start::]

        #���X�����Ϊ� CSV                
        Record_File.to_csv(file_path + file_name,index=False)
    else:
        df = df.drop_duplicates(subset = idx, keep='last')
        df.to_csv(file_path + file_name,index=False)
        
def check_pastdata(path):
    try:
        df_tmp = pd.read_csv(path)
        return df_tmp
    except:
        df_tmp = pd.read_csv(path, sep="\t")
        cols = df_tmp.columns[0].split(',')
        column_count = len(cols)

        check_record = []
        for i in df_tmp.index:
            r = df_tmp.iloc[i][0].split(',')
            if (len(r) == column_count):
                check_record.append(r)
        df_tmp = pd.DataFrame(check_record, columns=cols)
        df_tmp.to_csv(path,index=False)
        return df_tmp

