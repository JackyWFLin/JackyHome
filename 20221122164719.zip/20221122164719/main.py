
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import os
import requests
import re
from io import BytesIO
import json
import cv2
from datetime import datetime
from collections import Counter
from util.util import *
import time
import signal


# In[2]:
##########PID Control###############
PID_FILE = 'pid_main.txt'
pid = os.getpid()

if os.path.exists(PID_FILE):
    with open(PID_FILE, 'r') as f:
        try:
            last_pid = int(f.read().strip())
            os.kill(last_pid, 0)
            print(f"Terminating previous process {last_pid}")
            os.kill(last_pid, signal.SIGTERM)
            time.sleep(1)
        except ProcessLookupError:
            print(f"No running process with PID {last_pid}")
        except Exception as e:
            print(f"Error while trying to terminate process: {e}")

with open(PID_FILE, 'w') as f:
    f.write(str(pid))

#####################################
    
project = "AOI_Square_gray"
project_url = "http://10.96.152.227:9080/WEB_API/mysql/api/Upload_Healthy?project_id=20230922113335&status=0&port=3312"
project_url2 = "http://10.96.152.37/WEB_API/mysql/api/Upload_Healthy?project_id=20230922113335&status=0&port=3312"

project_url3 = "http://10.96.152.227:9080/WEB_API/mysql/api/Upload_Healthy?project_id=20241107154023&status=0&port=3312"
project_url4 = "http://10.96.152.37/WEB_API/mysql/api/Upload_Healthy?project_id=20241107154023&status=0&port=3312"


# In[3]:


mysql_url = 'http://10.96.152.227:9080/WEB_API/mysql/api/select'
mysql_connstr = "Database=l7b_imt;Data Source=tw100043811;Port=3307;User Id=l7b_commit;Password=l7b$commit;CharSet=utf8;SslMode=None;allowPublicKeyRetrieval=true"
ods_url = 'http://10.96.152.227:9080/WEB_API/mysql/api/selectODBC'

ods_connstr = 'Provider=MSDAORA;User ID=l7bint_ap;Data Source=C7BH_SHA;Password=l7bint$ap'
output_path = "D:\\AI_Project\\IMT\\20230821152605"
result_path = output_path + "\\image_judge"
raw_path = output_path + "\\image"
if not os.path.exists(result_path):
    os.makedirs(result_path)
if not os.path.exists(raw_path):
    os.makedirs(raw_path)


# In[13]:


def GetSheet():    
    print("start","GetSheet")
    sql = ""
    sql += " SELECT "
    sql += " group_concat(distinct value1) as product, "
    sql += " value2 as layer, "
    sql += " value5 as tool_id "
    sql += " FROM l7bcf_int.imt_config  "
    sql += " where value_type = '" + project + "' "
    sql += " group by value2,value5 "
    r_txt = Get_SQL_data(mysql_url, mysql_connstr, sql)
    df_config = pd.read_json(r_txt)

    
    product_str = ""
    op_str = ""
    eqp_id_str = ""
    if len(df_config) >= 0:
        product_str = ','.join(['\'' + i + '\'' for i in df_config["product"][0].split(',')])
        op_str = ','.join(['\'' + i + '\'' for i in df_config["layer"][0].split(',')])
        eqp_id_str = ','.join(['\'' + i + '\'' for i in df_config["tool_id"][0].split(',')])
    
    sql = ""
    
    sql += " select  "
    sql += "   TO_CHAR(a.testing_date, 'YYYY/MM/DD HH24:MI:SS') as test_date,  "
    sql += "   TO_CHAR(a.testing_date, 'YYYY/MM/DD HH24:MI:SS') as logoff_date,  "
    sql += "   kpc.line_id,  "
    sql += "   a.product, "
    sql += "   a.eqp_id, "
    sql += "   a.op, "
    sql += "   '' as cst_id, "
    sql += "   a.glass_id "
    sql += "   from "
    sql += " ( "
    sql += "    select "
    sql += "         max(b.testing_date) as testing_date, "
    sql += "         b.eqp_id, "
    sql += "         substr(b.model_no,0,9) product, "
    sql += "         b.op, "
    sql += "         b.glass_id "
    sql += "       from "
    sql += "    ( "
    sql += "     select b.glass_id,b.eqp_id,b.op from "
    sql += "     ( "
    sql += "         select  "
    sql += "           distinct(t.sheet_id) as sheet_id "
    sql += "           from cfspch.h_raw_kpc t "
    sql += "           where 1=1 "
    sql += "           and report_time >= sysdate - 1/24 "
    sql += "           and tool_id in ('FDMOVN10','FDMOVN20') "
    sql += "           and operation_id = 'BM' "
    sql += "           and dc_item_group = '0000' "
    sql += "           and t.item_value008 <> '0' "
    sql += "       union "
    sql += "         select  "
    sql += "           glass_id as sheet_id from cfppth.m_gls_oper t "
    sql += "         where 1=1 "
    sql += "         and t.logoff_date >= sysdate - 1/24 "
    sql += "         and op = 'BM' "
    sql += "     ) a "
    sql += "     inner join "
    sql += "     ( "
    sql += "       select "
    sql += "         glass_id,eqp_id,op "
    sql += "         from cfppth.m_aoi_deft t "
    sql += "       where 1=1   "
    sql += "     and substr(model_no,0,9) in (" + product_str + ") "
    sql += "     and eqp_id in (" + eqp_id_str + ") "
    sql += "     and op in (" + op_str + ") "
    sql += "     ) b "
    sql += "     on a.sheet_id = b.glass_id "
    sql += "     group by b.glass_id,b.eqp_id,b.op "
    sql += "   ) a "
    sql += "   inner join "
    sql += "   ( "
    sql += "     select * from cfppth.m_aoi_deft t "
    sql += "   ) b "
    sql += "   on 1=1 "
    sql += "   and a.glass_id = b.glass_id "
    sql += "   and a.eqp_id = b.eqp_id "
    sql += "   and a.op = b.op "
    sql += "   group by b.eqp_id, substr(b.model_no,0,9), b.op, b.glass_id "
    sql += " ) a "
    sql += " left join "
    sql += " ( "
    sql += "    select report_time,sheet_id,line_id || '-' || substr(tool_id,4) as line_id from cfspch.h_raw_kpc t "
    sql += "    where 1=1 "
    sql += "    and tool_id in ('FDMMPA10','FDMMPA20') "
    sql += "    and operation_id = 'BM' "
    sql += "    and dc_item_group = '0000' "
    sql += " ) kpc "
    sql += " on a.glass_id = kpc.sheet_id "
    r_txt = Get_SQL_data(ods_url, ods_connstr, sql)
    print("Done","GetSheet")
    df_sheet = pd.read_json(r_txt)
    return df_sheet


# In[14]:


def GetPOSConfig():
    
    print("start","GetPOSConfig")
    sql = ""
    sql += " SELECT "
    sql += " value1 as product, "
    sql += " value2 as op, "
    sql += " value3 as x, "
    sql += " value4 as y, "
    sql += " 1 as x_scale, "
    sql += " 1 as y_scale "
    #sql += " case when length(value3) < 7 then 100 else 1 end as x_scale, "
    #sql += " case when length(value4) < 7 then 100 else 1 end as y_scale "
    sql += " FROM l7bcf_int.imt_config  "
    sql += " where value_type = '" + project + "' "
    sql += "  "
    r_txt = Get_SQL_data(mysql_url, mysql_connstr, sql)
    df_config = pd.read_json(r_txt)
    print("Done","GetPOSConfig")
    return df_config


# In[15]:
def CheckFileList(img_info):
    img_info_new = []
    
    file_times = []
    for f in img_info:
        file_path = f[-1]
        if os.path.isfile(f[-1]):
            modified_time = os.path.getmtime(file_path)
            file_times.append((f, modified_time))
    sorted_file_times = sorted(file_times, key=lambda x: x[1], reverse=True)
    
    if sorted_file_times:
        latest_time = sorted_file_times[0][1]
    else:
        return []
        
    recent_files = []
    for file_info, modified_time in sorted_file_times:
        if latest_time - modified_time <= 600:
            recent_files.append(file_info)
               
        
        
    return recent_files


def GetIMGInfo():
    dt_config = GetPOSConfig()
    image_file_path = r"\\fcfle001\Image" + "\\"
    dt_sheet = GetSheet()
    
    df_record = readfile(result_path + '//', "record.csv")
    sheet_id_set = set(df_record['sheet_id'].values)
    

    img_info = []
    for i in dt_sheet.index:
        product = dt_sheet.iloc[i]["PRODUCT"]
        cst_id = dt_sheet.iloc[i]["CST_ID"]
        sheet_id = dt_sheet.iloc[i]["GLASS_ID"]
        test_date = str(dt_sheet.iloc[i]["TEST_DATE"])
        logoff_date = str(dt_sheet.iloc[i]["LOGOFF_DATE"])
        eqp_id = str(dt_sheet.iloc[i]["EQP_ID"])
        layer = dt_sheet.iloc[i]["OP"]
        line_id = dt_sheet.iloc[i]["LINE_ID"]

        image_path = image_file_path + layer + "\\" + sheet_id[-1] + "\\" + sheet_id + "\\"
        print(image_path)
        if not os.path.exists(image_path):
            continue
            
        if sheet_id in sheet_id_set:
            continue

        #get all img file name
        #print(image_path)
        #aoi_info_list = []
        try:
            aoi_info_list = [i for i in os.listdir(image_path) if i[0] == 'G' and '.JPG' in i.upper()]
        except:
            #path = result_path + "/" + test_date[0:10].replace('/','') + "/"
            #print(path)
            #write_log(path + 'log.txt', '[' + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ']' + 'aoi image path not exist: ' + image_path + '\n')
            continue
            
        img_info_temp = []
        for fname in aoi_info_list:
            file_name = fname.split('.')[0].split('_')
            img_seq = int(file_name[1])
            x = int(file_name[3])
            y = int(file_name[4])
            
            '''
            dt_filter = dt_config[(dt_config["product"] == product)
                                  & (dt_config["op"].str.contains(layer)) &
                                  (dt_config["x"] * dt_config["x_scale"] > x - dt_config["x_scale"] * 2000) &
                                  (dt_config["x"] * dt_config["x_scale"] < x + dt_config["x_scale"] * 2000)
                                  & (dt_config["y"] * dt_config["y_scale"] > y - dt_config["y_scale"] * 2000) &
                                  (dt_config["y"] * dt_config["y_scale"] < y + dt_config["y_scale"] * 2000)]
            '''
            dt_filter = dt_config[(dt_config["product"] == product)
                                  & (dt_config["op"].str.contains(layer)) &
                                  (dt_config["x"] > x - 2000) &
                                  (dt_config["x"] < x + 2000)
                                  & (dt_config["y"] > y - 2000) &
                                  (dt_config["y"] < y + 2000)]
                                  
            
            if len(dt_filter) > 0:
                img_info_temp.append([test_date, logoff_date, line_id, product, eqp_id, layer, cst_id, sheet_id, str(x), str(y), image_path + fname])
        try:
            img_info_temp = CheckFileList(img_info_temp)
            if len(img_info_temp) > 0:
                img_info = img_info + img_info_temp
        except:
            try:
                path = result_path + "/" + eqp_id + "/" + test_date[0:10].replace('/','') + "/"
                write_log(path + 'log.txt', '[' + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ']' + 'CheckFileList ERROR: ' + image_path + '\n')
            except:
                pass
            continue
    return img_info


# In[16]:


def FindTemplate(img_raw, cfg, op):
    
    img = img_raw.copy()
    #img = cv2.blur(img, (5, 5), 2)
    match_score = 0
    temp_loc = []
    idx = -1
    
    for i in range(len(cfg[op]['pattern'])):
        img_temp_ = cfg[op]['pattern'][i]['image']        
        match_score_, temp_loc_ = MatchTemp(img, img_temp_)
        if match_score_ > match_score:
            match_score = match_score_
            temp_loc = temp_loc_
            img_temp = img_temp_
            idx = i
    return match_score, temp_loc, idx


# In[17]:


def readimg(path, url=False):

    print(path)
    img_raw = None
    if url:
        get, r = request_url(path, 2, 3)
        if get:
            arr = np.asarray(bytearray(r.content), dtype=np.uint8)
            img_raw = cv2.imdecode(arr, -1)
    else:
        img_raw = cv2.imread(path)
    return img_raw


# In[18]:


img_info = GetIMGInfo()
print("total img:" , len(img_info))


# In[19]:


# init config template

with open("config/config.json") as f:
    cfg = json.load(f)
    
for k in cfg.keys():
    for i in range(len(cfg[k]['pattern'])):
        #print(cfg[k]['pattern'][i]['file_name'])
        img = cv2.imread(cfg[k]['pattern'][i]['file_name'])
        cfg[k]['pattern'][i]['image'] = img
        cfg[k]['pattern'][i]['shape'] = img.shape
        
kernel = np.ones((2, 2), np.uint8)
scale = 3


# In[20]:


result = []

for info in img_info:
    
    product = info[3]
    op = info[5]
    img_path = info[10]
    eqp_id = info[4]
    
    raw_path_ = raw_path + "\\" + eqp_id + "\\" + info[0][0:10].replace('/','')
    result_path_ = result_path + "\\" + eqp_id + "\\" + info[0][0:10].replace('/','')
    
    if not os.path.exists(result_path_):
        os.makedirs(result_path_)
    if not os.path.exists(raw_path_):
        os.makedirs(raw_path_)
    
    #if os.path.isfile(raw_path_ + "/" + img_path.split('\\')[-1]):
    #    continue
        
    try:
        img_raw = readimg(img_path)
        cv2.imwrite(raw_path_ + "/" + img_path.split('\\')[-1], img_raw)


        img_rgb = img_raw.copy()
        image = img_raw.copy()    
        height, width = image.shape[:2]

        # defect image size < 100 skip!!
        #if width < 100:
        #    continue
        
        #取中心
        center_height = height // 2
        center_width = width // 2
        half_height = int(center_height * 1)
        half_width = int(center_width * 1)
        if product[0:3] == "T50":
            half_height = int(center_height * 0.6)
            half_width = int(center_width * 0.6)
        
        cropped_image = image[center_height - half_height:center_height + half_height,
                              center_width - half_width:center_width + half_width]
        img_rgb = img_rgb[center_height - half_height:center_height + half_height,
                              center_width - half_width:center_width + half_width]

        gray = cv2.cvtColor(cropped_image, cv2.COLOR_BGR2GRAY)
        
        if product[0:4] == 'M240':
            match_score, temp_loc, idx = FindTemplate(cropped_image, cfg, "DT")
        else:        
            match_score, temp_loc, idx = FindTemplate(cropped_image, cfg, "BM")
        
        
        ret2, th_otsu = cv2.threshold(gray, 0, 255,cv2.THRESH_BINARY + cv2.THRESH_OTSU)


        th_otsu = cv2.erode(th_otsu, kernel, iterations=1)
        th_otsu = cv2.dilate(th_otsu, kernel, iterations=1)    
        #cv2.imshow('th_otsu', cv2.resize(th_otsu, (int(th_otsu.shape[1] * scale),int(th_otsu.shape[0] * scale)), interpolation=cv2.INTER_AREA))

        cv2.floodFill(th_otsu, None, (0,0), 0);

        contours, hierarchy = cv2.findContours(th_otsu, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
        ok_score = match_score
        if (match_score > 0.55):
            temp_h, temp_w, _ = cfg["BM"]['pattern'][idx]['shape']
            img_rgb = cv2.rectangle(img_rgb, temp_loc, (temp_loc[0] + temp_w, temp_loc[1] + temp_h), (50, 255, 50), 1, cv2.LINE_AA)    
        
        #if ((len(contours) == 0) and (match_score > 0.65)) or (match_score > 0.7):
        #    temp_h, temp_w, _ = cfg["BM"]['pattern'][idx]['shape']
        #    img_rgb = cv2.rectangle(img_rgb, temp_loc, (temp_loc[0] + temp_w, temp_loc[1] + temp_h), (50, 255, 50), 1, cv2.LINE_AA)    
            
        #else if (len(contours)<3) and (len(contours)>0):
        #    ok_score = 1
        #    img_rgb = cv2.drawContours(img_rgb, contours, -1, (50, 255, 50), thickness=cv2.FILLED)
        


        #print(match_score, len(contours))


        #cv2.imshow('windows', cv2.resize(img_rgb, (int(img_rgb.shape[1] * scale),int(img_rgb.shape[0] * scale)), interpolation=cv2.INTER_AREA))
        #cv2.waitKey(0)

        info[10] = info[10].split('\\')[-1]
        result.append(info + [round(ok_score * 100, 2)])
        cv2.imwrite(result_path_ + "/" + img_path.split('\\')[-1], img_rgb)
        
    except Exception as e :        
        try:
            print("error")
            path = result_path + "/" + eqp_id + "/" + info[0][0:10].replace('/','') + "/"
            print(path)
            write_log(path + 'log.txt', '[' + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ']' + 'ERROR: ' + str(e) + '\n')
        except:
            pass
        
    #cv2.imshow('img_rgb', img_rgb)
    # 按下任意鍵則關閉所有視窗
    #cv2.waitKey(0)
    
#cv2.destroyAllWindows()


# In[21]:


df_record = pd.DataFrame(result, columns=['test_date', 'logoff_date', 'line_id', 'product_code', 'eqp_id', 'op', 'cst_id', 'sheet_id', 'x', 'y', 'img_name', 'ok_score'])
savefile(result_path + '//', "record.csv", df_record, ['test_date','eqp_id','op','img_name'], 60000)
if not (request_url(project_url, 2, 3)[0]):
    request_url(project_url.replace("10.96.152.76","10.96.152.227:9080"), 2, 3)
    
if not (request_url(project_url3, 2, 3)[0]):
    request_url(project_url3.replace("10.96.152.76","10.96.152.227:9080"), 2, 3)

    
if os.path.exists(PID_FILE):
    os.remove(PID_FILE)
    print(f"Removed PID file: {PID_FILE}")