#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import os
from io import BytesIO
import json
import cv2
import matplotlib.pyplot as plt
import signal
import sys
import logging


# In[4]:


image = cv2.imread('ADCVD100_0.jpg')


# 获取图像的形状
height, width, _ = image.shape

# 确定左半边区域
left_half = image[0:height, 0:width // 2]

# 获取左半边的形状
left_height, left_width, _ = left_half.shape

# 确定左半边的中心点
center_x = left_width // 2
center_x1 = int(center_x * 0.9)
center_x2 = int(center_x * 1.15)
center_y = left_height // 2
center_y1 = int(center_y * 0.9)
center_y2 = int(center_y * 1.15)

# 定义每个象限的区域
top_left = left_half[0:center_y1, 0:center_x1]

top_right = left_half[0:center_y1, center_x2:left_width]
top_right = cv2.flip(top_right, 1)

bottom_left = left_half[center_y2:left_height, 0:center_x1]
bottom_left = cv2.flip(bottom_left, 0)

bottom_right = left_half[center_y2:left_height, center_x2:left_width]
bottom_right = cv2.flip(bottom_right, -1)


#cv2.imshow('image', image)

# 显示切割结果
cv2.imshow('Top Left', top_left)
cv2.imshow('Top Right', top_right)
cv2.imshow('Bottom Left', bottom_left)
cv2.imshow('Bottom Right', bottom_right)

# 等待直到用户按下任意键
cv2.waitKey(0)
cv2.destroyAllWindows()


# In[5]:


def findGlassEdge(nums):
    total_sum = 0  
    count = 0      
    edge_start = -1
    edge_end = -1
    edge = False
    for index, num in enumerate(nums):
        if num > 240:
            continue
        
        if not edge:
            total_sum += num
            count += 1      

        if count > 0:  # 确保我们有添加过数字
            average = total_sum / count  # 计算当前平均值

            # 如果当前数字小于平均值 20，则停止
            if num < average - 30:
                edge = True
                if edge_start == -1:
                    edge_start = index
            elif edge:
                edge_end = index
                break
    return edge_start, edge_end
    


# In[6]:


def meas_target(nums, start_idx, end_idx):
    
    # 计算 start_idx - 10 到 start_idx - 3 的平均值
    
    sub_list = nums[start_idx - 10:start_idx - 3]
    average = sum(sub_list) / len(sub_list)  # 计算平均值
    
    
    consecutive_count = 0 
    
    # 从 end_idx 开始向后查找
    for index in range(end_idx, len(nums)):
        if nums[index] < (average - 30):
            consecutive_count += 1  # 满足条件的点数加 1
            if consecutive_count == 5:
                return index # 返回第一个满足条件的点的起始索引
        else:
            consecutive_count = 0  # 如果不满足条件，重置计数器
    return -1


# In[7]:


def drawline(image):
    y_position = 320  # 替换为你要分析的行
    image_with_line = image.copy()
    cv2.line(image_with_line, (0, y_position), (image.shape[1], y_position), (255, 0, 0), 2)
    
    
    image = cv2.cvtColor(image.copy(), cv2.COLOR_BGR2GRAY)
    #image = cv2.GaussianBlur(image, (5,5), 1)
    
    # 提取该行的灰度值
    row_values = image[y_position, :]
    
    
    # 计算窗口大小为 3 的移动平均数
    #window_size = 3
    #kernel = np.ones(window_size) / window_size
    #row_values = np.convolve(row_values, kernel, mode='same')
    
    edge_start, edge_end = findGlassEdge(row_values)
    target_end = meas_target(row_values, edge_start, edge_end)
    
    print(edge_start, edge_end)
    print(target_end)
    
    cv2.line(image_with_line, (edge_end, y_position), (image.shape[1], y_position), (255, 255, 0), 2)
    
    cv2.line(image_with_line, (edge_end, y_position), (target_end, y_position), (0, 255, 255), 2)
    
    
    
    # 创建一个并排的子图
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))

    # 绘制折线图
    ax1.set_title(f"Pixel Intensity Values of Row at Y = {y_position}")
    ax1.set_xlabel("Pixel Position")
    ax1.set_ylabel("Intensity Value")
    ax1.plot(row_values, color='blue', marker='o', markersize=2, linestyle='-')  # 使用折线图
    ax1.grid()
    ax1.set_xlim([0, image.shape[1]])  # 设置 x 轴范围
    ax1.set_ylim([0, 256])  # 设置 y 轴范围
    ax1.axhline(y=255, color='r', linestyle='--')  # 绘制水平线标记最大灰度值

    # 在右侧显示图像
    ax2.set_title("Image with Marked Row")
    ax2.imshow(image_with_line)
    ax2.axis('off')  # 不显示坐标轴

    # 调整布局
    plt.tight_layout()
    plt.show()

    # 显示带有红色线条的图像
    #cv2.imshow('Image with Marked Row', image_with_line)
    #cv2.waitKey(0)
    #cv2.destroyAllWindows()


# In[8]:


drawline(top_left.copy())
drawline(top_right.copy())
drawline(bottom_left.copy())
drawline(bottom_right.copy())


# In[23]:


pd_data


# In[ ]:




