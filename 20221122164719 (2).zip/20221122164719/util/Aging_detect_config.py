#!/usr/bin/env python
# coding: utf-8

# In[10]:


import cv2
import numpy as np
import os
import json
import math
import sys

        
class Aging_detect_config():
    def __init__(self, image, judge_type, obj_gray_spec = [], detect_roi = [], obj_list = [], detect_list = []):
        
        self.image = image
        self.judge_type = judge_type
        
        self.obj_gray_spec = obj_gray_spec
        self.detect_roi = detect_roi
        self.obj_list = obj_list
        
        self.kernel = np.ones((7, 7), np.uint8)
        self.obj_count = len(self.obj_list)
        self.imgsize = image.shape
        self.img_obj = np.zeros(self.imgsize[:-1], np.int64)
        
        self.detect_type = detect_list
        
        self.roi_img = np.zeros(self.imgsize[:-1], np.uint8)
        if len(detect_roi) != 0:
            self.roi_img = cv2.fillPoly(self.roi_img, [np.array(detect_roi)], 255)
        else:
            self.roi_img.fill(255)
        
    
    def Get_judge_image(self):
        
        result_txt = ""
        
        obj_gray_spec = self.obj_gray_spec
        img = self.image.copy()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        img_result = cv2.cvtColor(gray.copy(), cv2.COLOR_GRAY2BGR)
        
        gray_blur = cv2.blur(gray, (7, 7), 2)
        
        if len(self.detect_roi) == 0:
            gray_value = gray_blur.mean()
        else:
            gray_blur = cv2.bitwise_and(gray_blur, gray_blur, mask = self.roi_img)
            gray_value = gray_blur[self.roi_img == 255].mean()
            if len(obj_gray_spec) != 0:
                if (gray_value < obj_gray_spec[0] or gray_value > obj_gray_spec[1]):
                    result_txt += "Gray Judge : " + "NG" + "\n"
                else:
                    result_txt += "Gray Judge : " + "OK" + "\n"
        result_txt += "Gray Value : " + str(round(gray_value)) + "\n"
        
        ret2, th_otsu = cv2.threshold(gray_blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        th_otsu = cv2.erode(th_otsu, self.kernel, iterations=3)
        th_otsu = cv2.dilate(th_otsu, self.kernel, iterations=3)
        img_result = cv2.bitwise_and(img_result, img_result, mask = th_otsu)    
        
  
        if self.judge_type == "obj detect":
            
            img_result = self.Check_obj_info(img_result, th_otsu)
            
        if self.judge_type == "hsv detect":
            img = cv2.bitwise_and(img, img, mask = self.roi_img)
            img_result = self.Check_HSV_Info(img)
        
         
        for i, txt in enumerate(result_txt.split('\n')):
            img_result = cv2.putText(img_result, txt , (50, 80 + i * 40), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 100, 100), 4, cv2.LINE_AA)
        
        
        return img_result
        
        
            
            
    
    def Check_obj_info(self, img_result, th_otsu):
        # 分析每一個obj info      
        
        img_sheet = np.zeros(self.imgsize[:-1], np.uint8)
        img_sheet[th_otsu != 0] = 255

        for obj_config in self.obj_list:

            obj_no = obj_config["obj_no"]
            area_spec = obj_config['area_spec']
            width_spec = obj_config['width_spec']
            height_spec = obj_config['height_spec']
            
            if len(obj_config["roi_pox"])==0:
                break
                
            # ROI框中心點
            cent_x, cent_y = np.array(obj_config["roi_pox"]).mean(axis=0)

            roi_temp = np.zeros(self.imgsize[:-1], np.uint8)
            roi_temp = cv2.fillPoly(roi_temp, [np.array(obj_config["roi_pox"])], 255)
            img_obj = cv2.bitwise_and(img_sheet, img_sheet, mask = roi_temp)

            contours, hierarchy = cv2.findContours(img_obj, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)

            min_d = -1
            find_c = None
            find_c_area = 0

            for c in contours:
                x, y, w, h = cv2.boundingRect(c)
                area = cv2.contourArea(c)
                
                M = cv2.moments(c)
                if M['m00'] != 0:
                    cx = int(M['m10']/M['m00'])
                    cy = int(M['m01']/M['m00'])
                    d = math.sqrt((cx - cent_x)**2 + (cy - cent_y)**2)

                color = (0,255,0)
                if len(area_spec) > 0 and len(width_spec) > 0 and len(height_spec) > 0:
                    if (area >= area_spec[0]) and (
                        area <= area_spec[1]) and (
                        w >= width_spec[0]) and (
                        w <= width_spec[1]) and (
                        h >= height_spec[0]) and (
                        h <= height_spec[1]):
                        
                        color = (0,255,0)
                        
                        if ( min_d == -1 ) or ( d < min_d ):
                            min_d = d
                            find_c = c
                            find_c_area = area
                    else:
                        color = (0,0,255)
                
                
                img_result = cv2.drawContours(img_result, [c], -1, color, thickness=cv2.FILLED)
                img_result = cv2.putText(img_result, "area:" + str(round(area)), (x, y), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 0, 255), 2, cv2.LINE_AA)
                img_result = cv2.putText(img_result, "w:" + str(round(w)), (x, y + 40), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 0, 255), 2, cv2.LINE_AA)
                img_result = cv2.putText(img_result, "h:" + str(round(h)), (x, y + 80), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 0, 255), 2, cv2.LINE_AA)
                
        return img_result
            
            
    def Check_HSV_Info(self, img):
        #img_raw = []
    
        img_hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        
        for config_detect in self.detect_type:
            if len(config_detect['HSV_LOWER']) != 0 and len(config_detect['HSV_UPPER']) != 0:
                hsv_lower = np.array(config_detect['HSV_LOWER'])
                hsv_upper = np.array(config_detect['HSV_UPPER'])
                mask  = cv2.inRange(img_hsv, hsv_lower, hsv_upper)
                img = cv2.bitwise_and(img, img, mask = mask)
        
       
        return img
        


if __name__ == '__main__':
    path = sys.argv[2]
    config_path = sys.argv[3]
    obj = Aging_detect(path, config_path)
    obj.run()
    print("Done!")


# In[12]:

'''
path = "20230524/150032_ABCDEFG/1"
config_path = 'config/cam1_test.json'
obj = Aging_detect(path, config_path)
obj.run()
print("Done!")
'''

# In[ ]:




